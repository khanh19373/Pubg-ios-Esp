
#import "ImGuiDrawView.h"
#import "menuButtonConfig.h"
#import "SLConfig.h"
#import "PubgLoad.h"
#include "imgui.h"
#include "imgui_impl_metal.h"
#import <mach/mach.h>
#import <mach/mach_host.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#import <mach/mach.h>
#import <mach/mach_host.h>
#import <AVFoundation/AVFoundation.h>
#import "Icon.h"
#import "mahoa.h"


#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic,  weak) NSTimer *timer1;
@property (nonatomic,  weak) NSTimer *timer2;

@end

extern bool isAimvisual;
extern bool AR_language;
extern bool DrawPlayerLine;
extern bool antiblock;

float antiblockfl = 20;
UIButton *closeButton;
UIView * MainMnue;
UIView* Espview;
UIView* NoScopView;
UIView* AimbotView;
UIView* MemoryView;
UIView* Settingview;
UIButton *Munu1;
UIButton *Munu2;
UIButton *Munu3;
UIButton *Munu4;
UIButton *Munu5;//item profile
UIButton *Munu6;//aimbot profile
UIButton *Munu7;//open setting in browser
UIButton *Munu8;// v downlaod settings
UIButton *back;
UIButton *Exet;
UIButton *FIRE;
// esp
UILabel *EspLabel[10];
UIButton *EspButton[10];
UISlider * EspSliders[8];
UILabel *EspLabelSlider[14];
UILabel *AimLabel[7];
UISlider *AimSlidr[4];
float FovRadousVal = AimSlidr[0].value;
UILabel *name;
UIButton *nameBTN;
UILabel *box;
UIButton *boxBTN;
UILabel *Bone;
UIButton *BoneBTN;
UILabel *Wepaon;
UIButton *WepaonBTN;
UILabel *dis;
UIButton *disBTN;
UILabel *health;
UIButton *healthBTN;
UILabel *Arrow;
UIButton *ArrowBTN;
extern bool IsAirDrop;
extern int iAwareTexSiz;
extern int ThanhIpad;
extern bool iAwareText;
extern int EspTextSiz;
extern float EspBoxThik;
extern float EspSktonThik;
extern float bombomb;
extern float bombomb2;
extern int killmsgtest;
extern int value;
//no scope aimbot
UILabel *AutFirBuSizLabel1;
UILabel *AutFirBuSizLabel2;
UISlider *AutFirBuSiz;
//matreal esp
UILabel *AR;//Not active for button
UIButton *ARBTN;//Not active for button
UILabel *SMG;//Not active for button
UIButton *SMGBTN;//Not active for button
UILabel *Sniper;
UIButton *SniperBTN;
UILabel *Ammo;//Not active for button
UIButton *AmmoBTN;//Not active for button
UILabel *Other;
UIButton *OtherBTN;
UILabel *Vheicle;
UIButton *VheicleBTN;
UILabel *Vheiclebox;
UIButton *VheicleboxBTN;
UILabel *DrawLinwLabel;
UIButton *DrawLineBTN;
UILabel *Lootbox;
UIButton *LootboxBTN;
UILabel *GrendeWarring;
UIButton *GrendeWarringBTN;
//No scope aimbot
UILabel *NoScoLable[8];
UIButton * NoScoButt[2];
UISlider *NoScopSlider[3];
float TurnRate = NoScopSlider[0].value;
extern int Interval;
//Aimbot
UILabel *AimAssis;
UIButton *AimAssisBTN;
UILabel *IgroneBot;
UIButton *IgroneBotBTN;
UILabel *IgorneKnock;
UIButton *IgorneKnockBTN;
UILabel *IgoroneVis;
UIButton *IgoroneVisBTN;
UILabel *Aimfov;
UIButton *AimfovBTN;
UILabel *HiddenAimfov;
UIButton *HiddenAimfovBTN;
UILabel *FOV;
UISlider *FOVSLIDER;
UILabel *foVLAB;
UILabel *HeadShootLab;
UIButton *Head;
UILabel *ChestShootLab;
UIButton *Chest;
UILabel *AutofireLab;
UIButton *AutofireBTN;
UILabel *RootShootLab;
UIButton *Root;
UILabel *AUTOFIRESLiderLab;
UILabel *AUTOFIRE_SLiderLabInterval;
UISlider *AUTOFIRESLider;
UILabel *AUTOLab;
UILabel *AUTOLabInterval;
UISlider *HiddenFOV;
UISlider *TurnRateSlider;
UILabel *AimLabl[4];
UILabel *TurnRat[2];
//UIButton *AimBtn[2];
float HiddenFOVSliderVal;
float AimTurnRateSlidVal =  TurnRateSlider.value;
float NoScopeAimDisSliderVal = NoScopSlider[1].value;
float NoScopeFOVSliderVal = NoScopSlider[2].value;
//settings "Other"
UIButton *ar;
UIButton *en;
UILabel *lang;
UILabel *ResetGusetLab;
UILabel *BunnyHup;
UIButton *ResetGuset;
UIButton *BunnyHupButton;
extern bool IsAutofire ;
extern bool  IsNorecoil ;
extern bool  IsHitXPL ;
extern bool initkillmsgopen ;
extern bool initkillmsgcheck ;
extern bool DeadBox ;
extern bool Box ;
extern bool  INTAHIT;
static int xsuit = 0;
static int skinm4 = 0;
static int skinakm = 0;
static int skinscar = 0;
static int skinM762 = 0;
static int skinace32 = 0;
static int skinm16a4 = 0;
extern bool  IsNOcameras ;
extern bool IsFastBullet;
extern bool IsCrossHair;
extern bool test1;
extern bool  ipadview;
extern bool  ipadviewv2;
extern bool  Igronebot;
extern bool  IsbulletTrack;
extern bool  IsShoot;
extern bool  IsSCope;
extern bool  IsBothaim;
extern bool  IsAny;
extern bool  IsAimbot ;
extern bool  IsAimbotFov ;
extern bool  IsAimbotDis ;
extern bool  IsAimHead ;
extern bool  IsAimNeck ;
extern bool  IsAimRoot ;
extern bool  IsBone ;
extern bool  IsJump ;
extern bool  IsPlayerWEP ;
extern bool AUOTJUMPAN;
extern bool  IsFastshoot ;
extern bool  IsFastDrop ;
extern bool  IsNocamerashake ;
extern bool  IsVehcleEsp ;
extern bool  IsWarring ;
extern bool  Is3Dbox ;
extern bool  IsPLayerName ;
extern bool  ESPGAME ;
extern bool  IsPlayerHP ;
extern bool  IsFastKnock ;
extern bool  IsFastswim ;
extern bool  IsVehcle ;
extern bool  IsboxVechle ;
extern bool  IsCarHP ;
extern bool  IsCarFuel ;
extern bool  IsPostil ;
extern bool  IsSniper ;
extern bool  IsWeapon ;
extern bool  IsAmmo ;
extern bool  IsFov ;
extern bool IsSMG;
extern bool iSPLAYERDIS;
extern bool isAimKnocked;
extern bool IsAR;
extern bool IsShotgun;
extern bool IsGRWAR;
extern bool IsLootBox;
extern bool IsPlayerSP;
extern bool IsSilentAIM;
extern bool GODVIEWUUP;
extern bool GODVIEWFRONT;
extern bool GODVIEWLEFT;
extern bool ARWP ;
extern bool SMGWP ;
extern bool SNPWP ;
extern bool otherWP ;
extern bool AmmoWP ;
extern bool LIGHTMW ;
extern bool SHOTGUNWP ;
extern bool scopewp ;
extern bool POSTOLWP ;
extern bool ARMORWP ;
extern bool  AIMHEAD1 ;
extern bool  AIMNeck1 ;
extern bool  AIMcheat1 ;
extern bool  xsuitt;
extern bool bonn;



extern UISlider * Auto1;//autofire
extern UISlider * Auto1Interval;//autofire
extern UISlider * sliderrr;//aimpos
extern UISlider * Aimbot1;//fov
extern UISlider * aimspeed;//aimbot
extern CGSize AutoFireCircelSize;// CGSizeMake(w, h);
static ImGuiDrawView *extraInfo;
int MenuLocation; // main = 1 / second 2 / ...etc
CGPoint exitButLocation;
int YPostions = 20; // for frame size between labels in menu
UIColor *Green = [UIColor colorWithRed: 0.05 green: 0.70 blue: 0.03 alpha: 1.00];
UIColor *Red = [UIColor colorWithRed: 0.67 green: 0.00 blue: 0.01 alpha: 1.00];

extern bool thanhgiap1;
extern bool thanhgiap2;
extern bool thanhgiap3;
extern bool thanhgiap4;
extern bool thanhgiap5;
extern bool thanhgiap6;
extern bool thanhgiap7;
extern bool thanhgiap8;

extern bool skinm41;
extern bool skinm42;
extern bool skinm43;
extern bool skinm44;
extern bool skinm45;
extern bool skinm46;
extern bool skinm47;
extern bool skinm48;

extern bool honey1;
extern bool dbs1;
extern bool akm1;
extern bool akm2;
extern bool akm3;
extern bool akm4;
extern bool akm5;
extern bool akm6;
extern bool akm7;
extern bool akm8;
extern bool akm9;
extern bool akm10;
extern bool akm11;
extern bool akm12;

extern bool m7621;
extern bool m7622;
extern bool m7623;
extern bool m7624;
extern bool m7625;
extern bool m7626;
extern bool m7627;
extern bool m7628;

extern bool m161;
extern bool m162;
extern bool m163;
extern bool m164;
extern bool m165;
extern bool m166;
extern bool m167;
extern bool m168;

extern bool aug1;
extern bool aug2;
extern bool aug3;
extern bool aug4;
extern bool aug5;
extern bool aug6;
extern bool aug7;
extern bool aug8;

extern bool gloza1;
extern bool gloza2;
extern bool gloza3;
extern bool gloza4;
extern bool gloza5;
extern bool gloza6;
extern bool gloza7;
extern bool gloza8;

extern bool uzi1;
extern bool uzi2;
extern bool uzi3;
extern bool uzi4;
extern bool uzi5;
extern bool uzi6;
extern bool uzi7;
extern bool uzi8;

extern bool ump1;
extern bool ump2;
extern bool ump3;
extern bool ump4;
extern bool ump5;
extern bool ump6;
extern bool ump7;
extern bool ump8;

extern bool qbz1;
extern bool qbz2;
extern bool qbz3;
extern bool qbz4;
extern bool qbz5;
extern bool qbz6;
extern bool qbz7;
extern bool qbz8;

extern bool sks1;
extern bool sks2;
extern bool sks3;
extern bool sks4;
extern bool sks5;

extern bool slr1;
extern bool slr2;
extern bool slr3;
extern bool slr4;
extern bool slr5;

extern bool vss1;
extern bool vss2;
extern bool vss3;
extern bool vss4;
extern bool vss5;

extern bool mini1;
extern bool mini2;
extern bool mini3;
extern bool mini4;

extern bool mk141;
extern bool mk142;
extern bool mk143;
extern bool mk144;

extern bool k981;
extern bool k982;
extern bool k983;
extern bool k984;
extern bool k985;

extern bool m241;
extern bool m242;
extern bool m243;
extern bool m244;
extern bool m245;
extern bool m246;

extern bool awm1;
extern bool awm2;
extern bool awm3;
extern bool awm4;
extern bool awm5;

extern bool arm;

extern bool thomson1;
extern bool thomson2;
extern bool thomson3;
extern bool thomson4;

extern bool bizon1;
extern bool bizon2;

extern bool vectorr1;
extern bool vectorr2;
extern bool vectorr3;
extern bool vectorr4;
extern bool vectorr5;

extern bool s18971;
extern bool s18972;
extern bool s18973;
extern bool s18974;

extern bool sk12k1;

extern bool m2491;
extern bool m2492;
extern bool m2493;
extern bool m2494;
extern bool m2495;

extern bool dp281;
extern bool dp282;
extern bool dp283;
extern bool dp284;
extern bool dp285;

extern bool pan1;
extern bool pan2;
extern bool pan3;
extern bool pan4;
extern bool pan5;


#define iPhone8P ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)


@implementation ImGuiDrawView
NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];//for save defaults setting


BOOL kg=NO;
BOOL k1=NO;


bool isOpenOrClose =false;
bool MenDeal;

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}



- (void)loadView
{
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
}


- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    
}

ImVec4 to_vec5(float r, float g, float b, float a)
{
    return ImVec4(r / 255.0, g / 255.0, b / 255.0, a / 255.0);
    
}


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    if (!self.device) abort();
    
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();
    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;
    
    
    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
    
    
    ImGuiStyle* style = &ImGui::GetStyle();
    
    
    ImVec4 *colors = style->Colors;
    
    style->WindowTitleAlign = ImVec2(0.5,0.5);

       style->Alpha = 0.9f;
        style->WindowBorderSize = 0.0f;
        style->WindowTitleAlign = ImVec2(0.5, 0.5);
        style->WindowPadding = ImVec2(15, 15);
        style->WindowRounding = 5.0f;
        style->FramePadding = ImVec2(5, 5);
        style->FrameRounding = 4.0f;
        style->ItemSpacing = ImVec2(12, 8);
        style->ItemInnerSpacing = ImVec2(8, 6);
        style->IndentSpacing = 25.0f;
        style->ScrollbarSize = 15.0f;
        style->ScrollbarRounding = 9.0f;
        style->GrabMinSize = 5.0f;
        style->GrabRounding = 3.0f;
    
        style->Colors[ImGuiCol_Text] = ImVec4(0.80f, 0.80f, 0.83f, 1.00f);
        style->Colors[ImGuiCol_TextDisabled] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
        style->Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
     
        style->Colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
        style->Colors[ImGuiCol_Border] = ImVec4(0.80f, 0.80f, 0.83f, 0.88f);
        style->Colors[ImGuiCol_BorderShadow] = ImVec4(0.92f, 0.91f, 0.88f, 0.00f);
        style->Colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
        style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
        style->Colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(1.00f, 0.98f, 0.95f, 0.75f);
        style->Colors[ImGuiCol_TitleBgActive] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
        style->Colors[ImGuiCol_MenuBarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
        style->Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
        style->Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
    
        style->Colors[ImGuiCol_CheckMark] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
        style->Colors[ImGuiCol_SliderGrab] = ImVec4(0.80f, 0.80f, 0.83f, 0.31f);
        style->Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
        style->Colors[ImGuiCol_Button] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
        style->Colors[ImGuiCol_ButtonActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
        style->Colors[ImGuiCol_Header] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_HeaderHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
        style->Colors[ImGuiCol_HeaderActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
        style->Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        style->Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
        style->Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
        style->Colors[ImGuiCol_PlotLines] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
        style->Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
        style->Colors[ImGuiCol_PlotHistogram] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
        style->Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
        style->Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.25f, 1.00f, 0.00f, 0.43f);
        style->Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(1.00f, 0.98f, 0.95f, 0.73f);
    
    
    
    
    
    
    
    NSString *fontPath3 = @"/System/Library/Fonts/CoreAddition/Arial.ttf";
    io.Fonts->AddFontFromFileTTF(fontPath3.UTF8String, 55.f,NULL,io.Fonts->GetGlyphRangesVietnamese());
    ImFont *_iconFont;
    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 35.f, &icons_config, icons_ranges);
    
    _iconFont->FontSize = 5;
    ImGui_ImplMetal_Init(_device);
    
    
    
    
    return self;
}


static void thongbao(NSString *Title,NSString *Message) {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:Title message:Message preferredStyle:UIAlertControllerStyleAlert];
    
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:true completion:nil];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
    
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}




ImVec4 to_vec4(float r, float g, float b, float a)
{
    return ImVec4(r / 255.0, g / 255.0, b / 255.0, a / 255.0);
    
}
namespace Settings
{
    static int Tab = 5;
}

- (void)drawInMTKView:(MTKView*)view
{
    
    
    
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    
    
    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 65);
    
    
    //    if (iPhone8P){
    //        io.DisplayFramebufferScale = ImVec2(2.60, 2.60);
    //    }else{
    //        io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    //    }
    
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    
    
    
    
    
    
    
    if (MenDeal == true) {
        [self.view setUserInteractionEnabled:YES];
    } else if (MenDeal == false) {
        [self.view setUserInteractionEnabled:NO];
    }
    
    
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil)
    {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"ImGui Jane"];
        
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        
        ImFont* font = ImGui::GetFont();
        font->Scale = 16.f / font->FontSize;
        
        CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 600) / 2;
        CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 320) / 2;
        
        ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
//        ImGui::SetNextWindowSize(ImVec2(635, 360), ImGuiCond_FirstUseEver);
                ImGui::SetNextWindowSize(ImVec2(600, 300), ImGuiCond_FirstUseEver);
        
        
        static ImVec4 active = to_vec4(0.729f, 0.098f, 0.031f, 1.0f);
        static ImVec4 inactive = to_vec4(0.729f, 0.098f, 0.031f, 1.0f);
        
        
        
        
        if (MenDeal == true)
            
        {
            /*
            
            ImGui::Begin("ELPION PUBG MOBILE (3.0.1)", &MenDeal);
            
            ImGui::Separator();
            
            ImGui::PushStyleColor(ImGuiCol_Button, Settings::Tab == 1 ? active : inactive);
            if (ImGui::Button(ICON_FA_HOME" Mainpage", ImVec2(85, 30)))
                Settings::Tab = 1;
            
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, Settings::Tab == 2 ? active : inactive);
            if (ImGui::Button(ICON_FA_EYE" ESP", ImVec2(85, 30)))
                Settings::Tab = 2;
            
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, Settings::Tab == 3 ? active : inactive);
            if (ImGui::Button(ICON_FA_CROSSHAIRS" Aimbot", ImVec2(85, 30)))
                Settings::Tab = 3;
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, Settings::Tab == 4 ? active : inactive);
            if (ImGui::Button(ICON_FA_EDIT" Memory", ImVec2(85, 30)))
                Settings::Tab = 4;
            
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, Settings::Tab == 5 ? active : inactive);
            if (ImGui::Button(ICON_FA_COG" Settings", ImVec2(85, 30)))
                Settings::Tab = 5;
            
            
            ImGui::Separator();
            ImGui::PopStyleColor(5);
            
            
            {
                if (Settings::Tab == 1)
                {
                    //ImGui::SetCursorPos(ImVec2(10, 10));
                    ImGui::BeginChild("##1", ImVec2(400, 225), true, 0);
                    {
                        
                        
                        
                    }
                    
                    ImGui::EndChild();
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                }
                
                if (Settings::Tab == 2)
                {
                    //ImGui::SetCursorPos(ImVec2(10, 10));
                    ImGui::BeginChild("##2", ImVec2(400, 280), true, 0);
                    {
                        
                        ImGui::SetCursorPos(ImVec2(5, 5));
                        ImGui::BeginChild("###1", ImVec2(150, 265), true, 0);
                        {
                            if (ImGui::Button("Select ALL"))
                            {
                                
                                
                                
                            }
                            
                            ImGui::Checkbox(("PlayerGun"), &IsPlayerWEP);
                            ImGui::Checkbox(("Name"), &IsPLayerName);
                            ImGui::Checkbox(("Bone"), &IsBone);
                            ImGui::Checkbox(("Heath"), &IsPlayerHP);
                            ImGui::Checkbox(("Line"), &DrawPlayerLine);
                            ImGui::Checkbox(("Distance"), &iSPLAYERDIS);
                            ImGui::Checkbox(("Box 3D"), &Is3Dbox);
                            ImGui::Checkbox(("Item"), &IsAR);
                            ImGui::Checkbox(("LootBox"), &IsLootBox);
                            ImGui::Checkbox(("Vehicle"), &IsVehcle);
                            ImGui::Checkbox(("GrenadeWAR"), &IsGRWAR);
                            ImGui::Checkbox(("Arrow360"), &IsWarring);
                            ImGui::Checkbox(("AirDrop"), &IsAirDrop);
                            
                            
                            
                            
                            
                            
                            
                        }
                        ImGui::EndChild();
                        
                        ImGui::SetCursorPos(ImVec2(160, 5));
                        ImGui::BeginChild("###2", ImVec2(235, 265), true, 0);
                        {
                            if (ImGui::BeginTabBar("TEST")) {
                                if (ImGui::BeginTabItem("Player settings")) {
                                    ImGui::BeginChild("###");
                                    //ImGui::SetCursorPos(ImVec2(0, 5));
                                    ImGui::BeginChild("###12", ImVec2(889, 468), true, 0);
                                    {
                                        if (ImGui::BeginTabBar("JOKER INER")) {
                                            if (IsPLayerName) {
                                                if (ImGui::BeginTabItem("Player")) {
                                                    ImGui::Spacing();
                                                    ImGui::Text("Thickness");
                                                    
                                                    ImGui::SetNextItemWidth(ImGui::GetWindowContentRegionWidth() - 780.0f);
                                                    ImGui::SliderInt("####2345", &iAwareTexSiz, 20, 50);
                                                    ImGui::SameLine();
                                                    ImGui::Text("Aware Text");
                                                    //
                                                    
                                                    ImGui::SetNextItemWidth(ImGui::GetWindowContentRegionWidth() - 780.0f);
                                                    ImGui::SliderFloat("####2", &EspSktonThik, 1.5f, 7.0f);
                                                    ImGui::SameLine();
                                                    ImGui::Text("Bone");
                                                    //
                                                    ImGui::SetNextItemWidth(ImGui::GetWindowContentRegionWidth() - 780.0f);
                                                    ImGui::SliderFloat("####244", &EspBoxThik, 1.5f, 7.0f);
                                                    ImGui::SameLine();
                                                    ImGui::Text("Box");
                                                    
                                                    
                                                    ImGui::SetNextItemWidth(ImGui::GetWindowContentRegionWidth() - 780.0f);
                                                    ImGui::SliderInt("####24", &EspTextSiz, 5, 30);
                                                    ImGui::SameLine();
                                                    ImGui::Text("Text");
                                                    
                                                    
                                                    
                                                    ImGui::EndTabItem();
                                                }
                                            }
                                            ImGui::SameLine();
                                            if (IsBone) {
                                                if (ImGui::BeginTabItem("Color")) {
                                                    
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    ImGui::Spacing();
                                                    
                                                    ImGui::Text("Color mode");
                                                    
                                                    
                                                    ImGui::EndTabItem();
                                                    
                                                }
                                            }
                                            
                                            ImGui::SameLine();
                                            
                                            
                                            ImGui::SameLine();
                                             if (Setting::dots)
                                             {
                                             if (ImGui::BeginTabItem("Radar")) {
                                             
                                             
                                             ImGui::EndTabItem();
                                             }
                                             }
                                            
                                        }
                                        ImGui::EndTabBar();
                                        
                                        
                                    }
                                    ImGui::EndChild();
                                    
                                    ImGui::EndChild();
                                    ImGui::EndTabItem();
                                }
                                
                                if (IsVehcle)
                                {
                                    if (ImGui::BeginTabItem("Vehicle")) {
                                        
                                        ImGui::Checkbox(("Box"), &IsboxVechle);
                                        ImGui::Checkbox(("Car-HP"), &IsCarHP);
                                        ImGui::Checkbox(("Car-Fuel"), &IsCarFuel);
                                        
                                        ImGui::Text("Text size ");
                                        
                                        ImGui::EndTabItem();
                                    }
                                }
                                
                                //ImGui::SameLine();
                                if (IsAR)
                                {
                                    if (ImGui::BeginTabItem("Items")) {
                                        ImGui::BeginChild("###1");
                                        //ImGui::SetCursorPos(ImVec2(0, 5));
                                        //ImGui::BeginChild("###121", ImVec2(540, 468), true, 0);
                                        
                                        
                                        
                                        {
                                            if (ImGui::BeginTabBar("TEST INER1")) {
                                                
                                                
                                                
                                                if (ImGui::BeginTabItem("Weapon")) {
                                                    
                                                    
                                                    ImGui::BeginChild("###1211", ImVec2(889, 450), true, 0);
                                                    {
                                                        
                                                        
                                                        
                                                        ImGui::Checkbox(("AR"), &IsAR);
                                                        ImGui::SameLine();
                                                        ImGui::Checkbox(("SMG"), &IsSMG);
                                                        ImGui::Checkbox(("SR"), &IsSniper);
                                                        ImGui::SameLine();
                                                        ImGui::Checkbox(("Shotgun"), &IsShotgun);
                                                        ImGui::Checkbox(("Ammo"), &IsAmmo);
                                                        
                                                        
                                                    }
                                                    ImGui::EndChild();
                                                    
                                                    ImGui::EndTabItem();
                                                }
                                                
                                                //ImGui::SameLine();
                                                
                                                
                                                
                                                
                                                
                                            }
                                            ImGui::EndTabBar();
                                            
                                            
                                        }
                                        //ImGui::EndChild();
                                        
                                        ImGui::EndChild();
                                        ImGui::EndTabItem();
                                    }
                                    ImGui::SameLine();
                                    
                                }
                                ImGui::SameLine();
                                 if (ImGui::BeginTabItem("Teammate")) {
                                 
                                 
                                 
                                 ImGui::EndTabItem();
                                 }
                            }
                            ImGui::EndTabBar();
                            
                            
                        }
                        ImGui::EndChild();
                        
                    }
                    ImGui::EndChild();
                }
                
                
                if (Settings::Tab == 3)
                {
                    
                    //ImGui::SetCursorPos(ImVec2(10, 10));
                    ImGui::BeginChild("##2", ImVec2(400, 280), true, 0);
                    {
                        
                        ImGui::SetCursorPos(ImVec2(5, 5));
                        ImGui::BeginChild("###1", ImVec2(150, 265), true, 0);
                        {
                            ImGui::Checkbox("Aimbot", &IsAimbot);
             
                        }
                        ImGui::EndChild();
                        
                        ImGui::SetCursorPos(ImVec2(160, 5));
                        ImGui::BeginChild("###2", ImVec2(235, 265), true, 0);
                        {
                            if (ImGui::BeginTabBar("JOKER3")) {
                                
                                if (IsAimbot)
                                {
                                    if (ImGui::BeginTabItem("Aimbot")) {
                                        
                                        
                                        ImGui::Checkbox("Shoot", &IsShoot);
                                        ImGui::Checkbox("Scope", &IsSCope);
                                        ImGui::Checkbox("Aim Dis", &IsAimbotDis);
                                        ImGui::Checkbox("Fov", &IsFov);
                                        ImGui::Checkbox("Aimbot Fov", &IsAimbotFov);
                                        ImGui::Checkbox("AimKocked", &isAimKnocked);
                                        ImGui::Checkbox("Igrone Bot", &Igronebot);
                                        
                                        static int style_idx = 1;
                                        if (ImGui::Combo("##312", &style_idx, "Null\0Head\0Root\0Neck\0"))
                                        {
                                            switch (style_idx)
                                            {
                                                case 1:
                                                    IsAimHead =true;
                                                    
                                                    break;
                                                case 2:
                                                    
                                                    IsAimRoot =true;
                                                    
                                                    break;
                                                case 3:
                                                    IsAimNeck =true;
                                                    
                                                    
                                                    
                                            }
                                        }
                                        
                                        
                                        
                                        ImGui::EndTabItem();
                                    }
                                    
                                }
                                
                                
                            }
                            ImGui::EndTabBar();
                            
                            
                        }
                        ImGui::EndChild();
                        
                    }
                    ImGui::EndChild();
                }
                
                if (Settings::Tab == 4)
                {
                    //ImGui::SetCursorPos(ImVec2(10, 10));
                    ImGui::BeginChild("##2", ImVec2(400, 280), true, 0);
                    {
                        
                        ImGui::SetCursorPos(ImVec2(5, 5));
                        ImGui::BeginChild("###1", ImVec2(150, 265), true, 0);
                        {
                            
                            
                            
                            
                            
                            
                            //                                                        ImGui::Checkbox(("Fast Shoot (*)"), &IsFastshoot);
                            //                            ImGui::Checkbox(("Fast Drop (*)"), &IsFastDrop);
                            //                            ImGui::Checkbox(("Fast Bullet (*)"), &IsFastBullet);
                            //                            ImGui::Checkbox(("Fast Knock (*)"), &IsFastKnock);
                            // ImGui::Checkbox(("No Fog (*)"), &IsNocamerashake);
                            //                            ImGui::Checkbox(("Hit X"), &IsHitXPL);
                            //                            ImGui::Checkbox(("Cross Hair"), &IsCrossHair);
                            // ImGui::Checkbox(("No Recoil (*)"), &IsNorecoil);
                            // ImGui::Checkbox(("Jmup (*)"), &IsJump);
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        ImGui::EndChild();
                        
                        ImGui::SetCursorPos(ImVec2(160, 5));
                        ImGui::BeginChild("###2", ImVec2(235, 265), true, 0);
                        
                        {
                            
                            
                            
                            //                            if (IsFastshoot) {
                            //                                ImGui::SliderInt("Idsdssd", &.., 40.0f, 140.0f);}
                            
                            //                        }
                        
                            
                        }
                        ImGui::EndChild();
                    }
                    ImGui::EndChild();
                }
                    
                    if (Settings::Tab == 5)
                    {
                        //ImGui::SetCursorPos(ImVec2(10, 10));
                        ImGui::BeginChild("##5", ImVec2(400, 280), true, 0);
                        {
                            
                            ImGui::SetCursorPos(ImVec2(5, 5));
                            ImGui::BeginChild("###1", ImVec2(150, 265), true, 0);
                            {
                                ImGui::Text("COMING SOON");
                            }
                            ImGui::EndChild();
                            
                            ImGui::SetCursorPos(ImVec2(160, 5));
                            ImGui::BeginChild("###2", ImVec2(235, 265), true, 0);
                            {
                                
                                ImGui::Text("COMING SOON");
                                
                            }
                            
                            if (ImGui::Button("Reset Data"))
                            {
                                
                                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/Documents/ano_tmp",NSHomeDirectory()] error:nil];
                                
                                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/Documents",NSHomeDirectory()] error:nil];
                                
                                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/Library",NSHomeDirectory()] error:nil];
                                
                                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/tmp",NSHomeDirectory()] error:nil];
                                
                                
                                UIAlertController *WrongKey = [UIAlertController alertControllerWithTitle:@"Wait 5 seconds for Crash game after wipe Data Pubg 100% " message:nil  preferredStyle:UIAlertControllerStyleAlert];
                                
                                
                                
                                [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:WrongKey animated:true completion:nil];
                                
                                
                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                    
                                    exit(0);
                                    
                                });
                            }
                            
                            ImGui::EndChild();
                            
                        }
                        
                        ImGui::EndChild();
                    }
                    
                    
                    
                    
                    
                    
                    ImGui::End();
                }
                
            }
*/
            ImGui::Begin("GwH Cheat", &MenDeal );
                 {
                  ImGui::Columns(2);
                  ImGui::SetColumnOffset(1, 120);
               {

                if (ImGui::Button(ICON_FA_COG" NOTICE PANEL", ImVec2(110,60)))
                Settings::Tab = 1;

                if (ImGui::Button(ICON_FA_EYE" PLAYER PANEL", ImVec2(110,60)))
                Settings::Tab = 2;

                if (ImGui::Button(ICON_FA_CROSSHAIRS" AIMBOT PANEL", ImVec2(110,60)))
                Settings::Tab = 3;

                if (ImGui::Button(ICON_FA_GAMEPAD" ITEMS PANEL", ImVec2(110,60)))
                Settings::Tab = 4;

                }
                ImGui::NextColumn();

            //菜单1对应-公告
            if (Settings::Tab == 1) {

                ImGui::Spacing();

                //换行
                ImGui::BulletText("ENG : THIS IS A TRIAL VERSION FOR BUYING AND SELLING!!!");
                ImGui::BulletText("Copyright © 2023 Nicotine x VIE. All Rights Reserved.");


            //菜单2对应-绘制
            } else if (Settings::Tab == 2) {

                                        ImGui::Checkbox(("PlayerGun"), &IsPlayerWEP);
                                                ImGui::SameLine();
            ImGui::Checkbox(("Name"), &IsPLayerName);
                                        ImGui::Checkbox(("Bone"), &IsBone);
                                        ImGui::Checkbox(("Heath"), &IsPlayerHP);
                                                ImGui::SameLine();
            ImGui::Checkbox(("Line"), &DrawPlayerLine);
                                        ImGui::Checkbox(("Distance"), &iSPLAYERDIS);
                                        ImGui::Checkbox(("Box 3D"), &Is3Dbox);
                                                ImGui::SameLine();
            ImGui::Checkbox(("Item"), &IsAR);
                                        ImGui::Checkbox(("LootBox"), &IsLootBox);
                                                ImGui::SameLine();
            ImGui::Checkbox(("Vehicle"), &IsVehcle);
                                        ImGui::Checkbox(("GrenadeWAR"), &IsGRWAR);

            ImGui::Checkbox(("Arrow360"), &IsWarring);
                                                ImGui::SameLine();
            ImGui::Checkbox(("AirDrop"), &IsAirDrop);
                                                                 ImGui::SameLine();
            ImGui::Checkbox(("Kill Msg"), &initkillmsgcheck);
                ImGui::Checkbox(("DeadBox"), &DeadBox);
            if(initkillmsgcheck){
            ImGui::Spacing();
               ImGui::Text("M416 Skin ");
                static int style_idx = 1;
                if (ImGui::Combo("##312", &style_idx, "Null\0skin1\0skin2\0skin3\0"))
                {
                    switch (style_idx)
                    {
                        case 1:
                            skinm41 =true;
                            
                            break;
                        case 2:
                            
                            skinm42 =true;
                            
                            break;
                        case 3:
                            skinm43 =true;
                            
                    }
                    
                            
                    }
            }

            //菜单3对应-自瞄 子追
            } else if (Settings::Tab == 3) {

            ImGui::Checkbox("Shoot", &IsShoot);
                                                    ImGui::Checkbox("Scope", &IsSCope);
                                                    ImGui::Checkbox("Aim Dis", &IsAimbotDis);
                                                    ImGui::Checkbox("Fov", &IsFov);
                                                    ImGui::Checkbox("Aimbot Fov", &IsAimbotFov);
                                                    ImGui::Checkbox("AimKocked", &isAimKnocked);
                                                    ImGui::Checkbox("Igrone Bot", &Igronebot);
                                                    
                                                    static int style_idx = 1;
                                                    if (ImGui::Combo("##312", &style_idx, "Null\0Head\0Root\0Neck\0"))
                                                    {
                                                        switch (style_idx)
                                                        {
                                                            case 1:
                                                                IsAimHead =true;
                                                                
                                                                break;
                                                            case 2:
                                                                
                                                                IsAimRoot =true;
                                                                
                                                                break;
                                                            case 3:
                                                                IsAimNeck =true;

                                                        }
                                                                                                }
                                                        //菜单4对应-物质
                                                        } else if (Settings::Tab == 4) {
                                                            
                                                            
                                                            //换行
                                                            ImGui::Checkbox(("AR"), &IsAR);
                                                            ImGui::SameLine();
                                                            ImGui::Checkbox(("SMG"), &IsSMG);
                                                            ImGui::Checkbox(("SR"), &IsSniper);
                                                            ImGui::SameLine();
                                                            ImGui::Checkbox(("Shotgun"), &IsShotgun);
                                                            ImGui::Checkbox(("Ammo"), &IsAmmo);
                                                            
                                                            
                                                            ImGui::Checkbox(("Car-Box"), &IsboxVechle);
                                                            ImGui::Checkbox(("Car-HP"), &IsCarHP);
                                                            ImGui::Checkbox(("Car-Fuel"), &IsCarFuel);
                                                        }

                                                                }
                                                                ImGui::End();
                                                        }
                                                                
                                                                ImGui::Render();
                                                                ImDrawData* draw_data = ImGui::GetDrawData();
                                                                ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
                                                                
                                                                
                                                                [renderEncoder popDebugGroup];
                                                                [renderEncoder endEncoding];
                                                                
                                                                [commandBuffer presentDrawable:view.currentDrawable];
                                                                
                                                            }
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            [commandBuffer commit];
                                                            
                                                            
                                                            
                                                            
                                                        }




#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

@end
