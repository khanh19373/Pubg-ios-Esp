
#import "SDK.hpp"
#import "PubgLoad.h"
#import "ImGuiDrawView.h"
#import <CoreText/CoreText.h>
#import <UIKit/UIKit.h>
#import <stdio.h>
#import <mach-o/dyld.h>
#import <mach/vm_region.h>
#import <malloc/malloc.h>
#import <objc/runtime.h>
#import <mach/mach.h>
#include "string.h"
#import <sys/socket.h>
#import <Foundation/Foundation.h>
#import <mach/mach_traps.h>
#include <math.h>
#import "SDK.hpp"
#import <array>
#include "Tools.h"
#include <cstdint>
#include <string>
#include <iterator>
#include <iostream>
#include <algorithm>
#include <vector>
#include <array>
#include "json.hpp"
#include "UE4.h"
#import "XorStr.hpp"
#import "CountDownTDM.h"
#import "ImGuiDrawView.h"
#include <codecvt>
#include <locale>
#include "imgui.h"
#include "imgui_impl_metal.h"
#include "Vector2.hpp"
#include "Vector3.hpp"
#import "Icon.h"
#include <JRMemory/MemScan.h>

ImDrawList *imDrawList;

long l1 = 0xFF544;
long l2 = 0xFFFFF;

int stack_20;
NSString * val_1;
NSString * val_x2 ;
int sort = 1,sort_1 = 3;
long RAMADDRESS = 0x4332443;//0x4332443 + F = 0x4332452
bool stack_193 = NO;
bool initkillmsghook = NO;
bool cdmokkill = NO;
using namespace std;
using namespace SDK;
CountDownClass *CounterArray[20];
bool bonn = false;
using json = nlohmann::ordered_json;
std::map<std::string, u_long> Config;
std::map<int, bool> itemConfig;
float CenterX=0.0f;
float CenterY=0.0f;
nlohmann::json itemData;
bool DrawPlayerLine = true;
bool IsAutofire = false;
bool IsNorecoil = false;
bool INTAHIT =false;
bool IsNOcameras = false;
bool ipadview= false;
bool ipadviewv2= false;
bool Igronebot =false;
bool IsbulletTrack=false;
bool IsbulletTrackv2=false;
bool TrackingCar=false;
bool  AIMHEAD1 = false; //head
bool  AIMNeck1 = false; //root
bool  AIMcheat1 = false; //pelvis
bool iSPLAYERDIS =true;
bool IsShoot =false;
bool IsSCope = false;
bool IsBothaim =false;
bool IsAny=true;
bool IsAimbot = true;
bool IsAimbotFov = false;
bool IsAimbotDis = false;
bool IsAimHead =false; //head
bool IsAimNeck =false; //root
bool IsAimRoot =false; // pelvis
bool IsGRWAR =true;
bool thongtin =true;

FRotator g_aimRotation;
FVector Tarloc;
FVector headp;
FVector myloc;
bool IsFastBullet = false;
FRotator g_cartrack;
FVector g_trackaim ;
bool IsBone =true;
bool xsuitt =true;

bool IsJump =false;
bool fps60 =false;
bool fps90 =false;
bool fps120 =false;
bool IsPlayerWEP = false;
bool IsFastshoot = false;
bool IsFastDrop = false;
bool IsLootBox = true;
bool IsNocamerashake = false;
bool IsVehcleEsp = false;
bool IsWarring = true;
bool Is3Dbox =false;
bool IsPLayerName = true;
bool ESPGAME = true;
bool IsPlayerHP =true;
bool IsFastKnock = false;
bool IsFastswim = false;
bool IsVehcle = false;
bool IsboxVechle =false;
bool IsCarHP = false;
bool IsCarFuel =false;
bool IsPostil =false;
bool IsSniper = false;
bool IsWeapon =false;
bool IsAmmo =false;
bool IsFov =false;
bool IsHitXPL =false;
bool IsPlayerSP= false;
bool isAimvisual =false;
//
bool initkillmsgopen =false;
bool initkillmsgcheck =false;
bool concac123 =false;
bool effectm4 =false;
bool skinsung =false;
bool m4rs =false;
bool Box =false;
bool DeadBox =false;
bool trangphuc =false;

bool checkeffectm4 =false;
bool checkskinsung =false;
bool checkm4rs =true;
bool checktrangphuc =false;

bool IsCrossHair = false;
bool IsSMG =false;
bool IsAR =false;
bool IsITM =false;
bool IsShotgun = false;
bool TeleportCar = false;
bool IsSilentAIM= false;
bool GODVIEWUUP= false;
bool GODVIEWFRONT= false;
bool GODVIEWLEFT= false;
bool AUOTJUMPAN= false;
bool AR_language;//for languae support AR = True mean arabic or false mean not arabic
UISlider * Auto1;//autofire
UISlider * Auto1Interval;//autofire interval
UISlider * sliderrr;//aimpos
extern float TurnRate; //No scope turn rate - aim speed
extern float NoScopeAimDisSliderVal;
extern float HiddenFOVSliderVal;// with scope Filed of view slider value /NOT ACTIVE/
extern float NoScopeFOVSliderVal;//No scope FOV size slider value
//Slider_Sniper * Aimbot1;//fov
extern float FovRadousVal;
UISlider * aimspeed;//aimbot speed
CGSize AutoFireCircelSize;// CGSizeMake(w, h);
bool IsAirDrop = false;
int Interval = 1;
int counter;
int value = 0;
int iAwareTexSiz = 20;
bool iAwareText = true;
int EspTextSiz = 5;
float EspBoxThik = 1.5f;
float EspSktonThik = 1.5f;
float bombomb = 1.5f;
float bombomb2 = 1.5f;
int ThanhIpad = 80.0f;
int killmsgtest = 1000;
//UISlider * Aimbot2;
//aimbot bool
float g_disstance;
//LOOT ESP
#include <assert.h>
#define IM_ASSERT(_EXPR)assert(_EXPR)
#define kLogOpen 1
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height

//NSInteger val;
bool isAimKnocked = false;
bool IsValidAddress(kaddr addr) {
    return addr > 0x100000000 && addr < 0x2000000000;
}
uintptr_t UE4;
kaddr module= (unsigned long)_dyld_get_image_vmaddr_slide(0);
namespace Options
{
int boxtype = 1;
int healthbartype = 0;
int Nationtype = 2;
int DirectionLineSize = 70;
int VehicleDirectionLineSize = 100;
int offscreen_range = 40;
int max_distance_offscreen = 400;
int playersdistancessize = 600;
bool esp_Outline = true;
int distance_Radar = 150;
}
uintptr_t ProcessEvent_Offset,AimBullet_Offset,AimBullet_Offset2,SetControlRotation_Offset;
#define SLEEP_TIME 1000LL / 120LL
#define TORAD(x) ((x) * (M_PI / 180.f))
#define DefineHook(RET, NAME, ARGS) \
    RET(*Orig_##NAME)               \
    ARGS;                           \
    RET Hook_##NAME ARGS
int g_screenWidth ;
int g_screenHeight ;
int screenWidth ;
int screenHeight ;
int screenDensity = 0;
int getEspFramerate;
int SCOLOR;
int scc;
char extra[30];
float density = -1;
float gDistance;
int localFiring{0};
BOOL kaiguan1 = NO;
BOOL kaiguan2 = NO;
BOOL kaiguan3 = NO;
BOOL kaiguan4 = NO;
#define PI 3.14159265358979323846
#define SLEEP_TIME 1000LL / 120LL
#define __fastcall
bool ARWP = false;
bool SMGWP =false;
bool SNPWP = false;
bool otherWP =false;
bool AmmoWP =false;
bool LIGHTMW = false;
bool SHOTGUNWP = false;
bool scopewp = false;
bool POSTOLWP = false;

bool ARMORWP =false;
bool antiblock =false;
bool carskin =false;

bool skin11 =false;
bool skin22 =false;
bool skin33 =false;
bool skin44 =false;


class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;
public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {
    }
    void update() {
        m_fpscount++;
        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;
            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }
    unsigned int get() const {
        return m_fps;
    }
};
FPSCounter fps;



namespace allColors
{
    FLinearColor AliceBlue = { 0.941176534f, 0.972549081f, 1.000000000f, 1.000000000f };
    FLinearColor AntiqueWhite = { 0.980392218f, 0.921568692f, 0.843137324f, 1.000000000f };
    FLinearColor Aqua = { 0.000000000f, 1.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor Aquamarine = { 0.498039246f, 1.000000000f, 0.831372619f, 1.000000000f };
    FLinearColor Azure = { 0.941176534f, 1.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor Beige = { 0.960784376f, 0.960784376f, 0.862745166f, 1.000000000f };
    FLinearColor Bisque = { 1.000000000f, 0.894117713f, 0.768627524f, 1.000000000f };
    FLinearColor Black = { 0.000000000f, 0.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor BlanchedAlmond = { 1.000000000f, 0.921568692f, 0.803921640f, 1.000000000f };
    FLinearColor Blue = { 0.000000000f, 0.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor BlueViolet = { 0.541176498f, 0.168627456f, 0.886274576f, 1.000000000f };
    FLinearColor Brown = { 0.647058845f, 0.164705887f, 0.164705887f, 1.000000000f };
    FLinearColor BurlyWood = { 0.870588303f, 0.721568644f, 0.529411793f, 1.000000000f };
    FLinearColor CadetBlue = { 0.372549027f, 0.619607866f, 0.627451003f, 1.000000000f };
    FLinearColor Chartreuse = { 0.498039246f, 1.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor Chocolate = { 0.823529482f, 0.411764741f, 0.117647067f, 1.000000000f };
    FLinearColor Coral = { 1.000000000f, 0.498039246f, 0.313725501f, 1.000000000f };
    FLinearColor CornflowerBlue = { 0.392156899f, 0.584313750f, 0.929411829f, 1.000000000f };
    FLinearColor Cornsilk = { 1.000000000f, 0.972549081f, 0.862745166f, 1.000000000f };
    FLinearColor Crimson = { 0.862745166f, 0.078431375f, 0.235294133f, 1.000000000f };
    FLinearColor Cyan = { 0.000000000f, 1.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor DarkBlue = { 0.000000000f, 0.000000000f, 0.545098066f, 1.000000000f };
    FLinearColor DarkCyan = { 0.000000000f, 0.545098066f, 0.545098066f, 1.000000000f };
    FLinearColor DarkGoldenrod = { 0.721568644f, 0.525490224f, 0.043137256f, 1.000000000f };
    FLinearColor DarkGray = { 0.662745118f, 0.662745118f, 0.662745118f, 1.000000000f };
    FLinearColor DarkGreen = { 0.000000000f, 0.392156899f, 0.000000000f, 1.000000000f };
    FLinearColor DarkKhaki = { 0.741176486f, 0.717647076f, 0.419607878f, 1.000000000f };
    FLinearColor DarkMagenta = { 0.545098066f, 0.000000000f, 0.545098066f, 1.000000000f };
    FLinearColor DarkOliveGreen = { 0.333333343f, 0.419607878f, 0.184313729f, 1.000000000f };
    FLinearColor DarkOrange = { 1.000000000f, 0.549019635f, 0.000000000f, 1.000000000f };
    FLinearColor DarkOrchid = { 0.600000024f, 0.196078449f, 0.800000072f, 1.000000000f };
    FLinearColor DarkRed = { 0.545098066f, 0.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor DarkSalmon = { 0.913725555f, 0.588235319f, 0.478431404f, 1.000000000f };
    FLinearColor DarkSeaGreen = { 0.560784340f, 0.737254918f, 0.545098066f, 1.000000000f };
    FLinearColor DarkSlateBlue = { 0.282352954f, 0.239215702f, 0.545098066f, 1.000000000f };
    FLinearColor DarkSlateGray = { 0.184313729f, 0.309803933f, 0.309803933f, 1.000000000f };
    FLinearColor DarkTurquoise = { 0.000000000f, 0.807843208f, 0.819607913f, 1.000000000f };
    FLinearColor DarkViolet = { 0.580392182f, 0.000000000f, 0.827451050f, 1.000000000f };
    FLinearColor DeepPink = { 1.000000000f, 0.078431375f, 0.576470613f, 1.000000000f };
    FLinearColor DeepSkyBlue = { 0.000000000f, 0.749019623f, 1.000000000f, 1.000000000f };
    FLinearColor DimGray = { 0.411764741f, 0.411764741f, 0.411764741f, 1.000000000f };
    FLinearColor DodgerBlue = { 0.117647067f, 0.564705908f, 1.000000000f, 1.000000000f };
    FLinearColor Firebrick = { 0.698039234f, 0.133333340f, 0.133333340f, 1.000000000f };
    FLinearColor FloralWhite = { 1.000000000f, 0.980392218f, 0.941176534f, 1.000000000f };
    FLinearColor ForestGreen = { 0.133333340f, 0.545098066f, 0.133333340f, 1.000000000f };
    FLinearColor Fuchsia = { 1.000000000f, 0.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor Gainsboro = { 0.862745166f, 0.862745166f, 0.862745166f, 1.000000000f };
    FLinearColor GhostWhite = { 0.972549081f, 0.972549081f, 1.000000000f, 1.000000000f };
    FLinearColor Gold = { 1.000000000f, 0.843137324f, 0.000000000f, 1.000000000f };
    FLinearColor Goldenrod = { 0.854902029f, 0.647058845f, 0.125490203f, 1.000000000f };
    FLinearColor Gray = { 0.501960814f, 0.501960814f, 0.501960814f, 1.000000000f };
    FLinearColor Green = { 0.000000000f, 0.501960814f, 0.000000000f, 1.000000000f };
    FLinearColor GreenYellow = { 0.678431392f, 1.000000000f, 0.184313729f, 1.000000000f };
    FLinearColor Honeydew = { 0.941176534f, 1.000000000f, 0.941176534f, 1.000000000f };
    FLinearColor HotPink = { 1.000000000f, 0.411764741f, 0.705882370f, 1.000000000f };
    FLinearColor IndianRed = { 0.803921640f, 0.360784322f, 0.360784322f, 1.000000000f };
    FLinearColor Indigo = { 0.294117659f, 0.000000000f, 0.509803951f, 1.000000000f };
    FLinearColor Ivory = { 1.000000000f, 1.000000000f, 0.941176534f, 1.000000000f };
    FLinearColor Khaki = { 0.941176534f, 0.901960850f, 0.549019635f, 1.000000000f };
    FLinearColor Lavender = { 0.901960850f, 0.901960850f, 0.980392218f, 1.000000000f };
    FLinearColor LavenderBlush = { 1.000000000f, 0.941176534f, 0.960784376f, 1.000000000f };
    FLinearColor LawnGreen = { 0.486274540f, 0.988235354f, 0.000000000f, 1.000000000f };
    FLinearColor LemonChiffon = { 1.000000000f, 0.980392218f, 0.803921640f, 1.000000000f };
    FLinearColor LightBlue = { 0.678431392f, 0.847058892f, 0.901960850f, 1.000000000f };
    FLinearColor LightCoral = { 0.941176534f, 0.501960814f, 0.501960814f, 1.000000000f };
    FLinearColor LightCyan = { 0.878431439f, 1.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor LightGoldenrodYellow = { 0.980392218f, 0.980392218f, 0.823529482f, 1.000000000f };
    FLinearColor LightGreen = { 0.564705908f, 0.933333397f, 0.564705908f, 1.000000000f };
    FLinearColor LightGray = { 0.827451050f, 0.827451050f, 0.827451050f, 1.000000000f };
    FLinearColor LightPink = { 1.000000000f, 0.713725507f, 0.756862819f, 1.000000000f };
    FLinearColor LightSalmon = { 1.000000000f, 0.627451003f, 0.478431404f, 1.000000000f };
    FLinearColor LightSeaGreen = { 0.125490203f, 0.698039234f, 0.666666687f, 1.000000000f };
    FLinearColor LightSkyBlue = { 0.529411793f, 0.807843208f, 0.980392218f, 1.000000000f };
    FLinearColor LightSlateGray = { 0.466666698f, 0.533333361f, 0.600000024f, 1.000000000f };
    FLinearColor LightSteelBlue = { 0.690196097f, 0.768627524f, 0.870588303f, 1.000000000f };
    FLinearColor LightYellow = { 1.000000000f, 1.000000000f, 0.878431439f, 1.000000000f };
    FLinearColor Lime = { 0.000000000f, 1.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor LimeGreen = { 0.196078449f, 0.803921640f, 0.196078449f, 1.000000000f };
    FLinearColor Linen = { 0.980392218f, 0.941176534f, 0.901960850f, 1.000000000f };
    FLinearColor Magenta = { 1.000000000f, 0.000000000f, 1.000000000f, 1.000000000f };
    FLinearColor Maroon = { 0.501960814f, 0.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor MediumAquamarine = { 0.400000036f, 0.803921640f, 0.666666687f, 1.000000000f };
    FLinearColor MediumBlue = { 0.000000000f, 0.000000000f, 0.803921640f, 1.000000000f };
    FLinearColor MediumOrchid = { 0.729411781f, 0.333333343f, 0.827451050f, 1.000000000f };
    FLinearColor MediumPurple = { 0.576470613f, 0.439215720f, 0.858823597f, 1.000000000f };
    FLinearColor MediumSeaGreen = { 0.235294133f, 0.701960802f, 0.443137288f, 1.000000000f };
    FLinearColor MediumSlateBlue = { 0.482352972f, 0.407843173f, 0.933333397f, 1.000000000f };
    FLinearColor MediumSpringGreen = { 0.000000000f, 0.980392218f, 0.603921592f, 1.000000000f };
    FLinearColor MediumTurquoise = { 0.282352954f, 0.819607913f, 0.800000072f, 1.000000000f };
    FLinearColor MediumVioletRed = { 0.780392230f, 0.082352944f, 0.521568656f, 1.000000000f };
    FLinearColor MidnightBlue = { 0.098039225f, 0.098039225f, 0.439215720f, 1.000000000f };
    FLinearColor MintCream = { 0.960784376f, 1.000000000f, 0.980392218f, 1.000000000f };
    FLinearColor MistyRose = { 1.000000000f, 0.894117713f, 0.882353008f, 1.000000000f };
    FLinearColor Moccasin = { 1.000000000f, 0.894117713f, 0.709803939f, 1.000000000f };
    FLinearColor NavajoWhite = { 1.000000000f, 0.870588303f, 0.678431392f, 1.000000000f };
    FLinearColor Navy = { 0.000000000f, 0.000000000f, 0.501960814f, 1.000000000f };
    FLinearColor OldLace = { 0.992156923f, 0.960784376f, 0.901960850f, 1.000000000f };
    FLinearColor Olive = { 0.501960814f, 0.501960814f, 0.000000000f, 1.000000000f };
    FLinearColor OliveDrab = { 0.419607878f, 0.556862772f, 0.137254909f, 1.000000000f };
    FLinearColor Orange = { 1.000000000f, 0.647058845f, 0.000000000f, 1.000000000f };
    FLinearColor OrangeRed = { 1.000000000f, 0.270588249f, 0.000000000f, 1.000000000f };
    FLinearColor Orchid = { 0.854902029f, 0.439215720f, 0.839215755f, 1.000000000f };
    FLinearColor PaleGoldenrod = { 0.933333397f, 0.909803987f, 0.666666687f, 1.000000000f };
    FLinearColor PaleGreen = { 0.596078455f, 0.984313786f, 0.596078455f, 1.000000000f };
    FLinearColor PaleTurquoise = { 0.686274529f, 0.933333397f, 0.933333397f, 1.000000000f };
    FLinearColor PaleVioletRed = { 0.858823597f, 0.439215720f, 0.576470613f, 1.000000000f };
    FLinearColor PapayaWhip = { 1.000000000f, 0.937254965f, 0.835294187f, 1.000000000f };
    FLinearColor PeachPuff = { 1.000000000f, 0.854902029f, 0.725490212f, 1.000000000f };
    FLinearColor Peru = { 0.803921640f, 0.521568656f, 0.247058839f, 1.000000000f };
    FLinearColor Pink = { 1.000000000f, 0.752941251f, 0.796078503f, 1.000000000f };
    FLinearColor Plum = { 0.866666734f, 0.627451003f, 0.866666734f, 1.000000000f };
    FLinearColor PowderBlue = { 0.690196097f, 0.878431439f, 0.901960850f, 1.000000000f };
    FLinearColor Purple = { 0.501960814f, 0.000000000f, 0.501960814f, 1.000000000f };
    FLinearColor Red = { 1.000000000f, 0.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor RosyBrown = { 0.737254918f, 0.560784340f, 0.560784340f, 1.000000000f };
    FLinearColor RoyalBlue = { 0.254901975f, 0.411764741f, 0.882353008f, 1.000000000f };
    FLinearColor SaddleBrown = { 0.545098066f, 0.270588249f, 0.074509807f, 1.000000000f };
    FLinearColor Salmon = { 0.980392218f, 0.501960814f, 0.447058856f, 1.000000000f };
    FLinearColor SandyBrown = { 0.956862807f, 0.643137276f, 0.376470625f, 1.000000000f };
    FLinearColor SeaGreen = { 0.180392161f, 0.545098066f, 0.341176480f, 1.000000000f };
    FLinearColor SeaShell = { 1.000000000f, 0.960784376f, 0.933333397f, 1.000000000f };
    FLinearColor Sienna = { 0.627451003f, 0.321568638f, 0.176470593f, 1.000000000f };
    FLinearColor Silver = { 0.752941251f, 0.752941251f, 0.752941251f, 1.000000000f };
    FLinearColor SkyBlue = { 0.529411793f, 0.807843208f, 0.921568692f, 1.000000000f };
    FLinearColor SlateBlue = { 0.415686309f, 0.352941185f, 0.803921640f, 1.000000000f };
    FLinearColor SlateGray = { 0.439215720f, 0.501960814f, 0.564705908f, 1.000000000f };
    FLinearColor Snow = { 1.000000000f, 0.980392218f, 0.980392218f, 1.000000000f };
    FLinearColor SpringGreen = { 0.000000000f, 1.000000000f, 0.498039246f, 1.000000000f };
    FLinearColor SteelBlue = { 0.274509817f, 0.509803951f, 0.705882370f, 1.000000000f };
    FLinearColor Tan = { 0.823529482f, 0.705882370f, 0.549019635f, 1.000000000f };
    FLinearColor Teal = { 0.000000000f, 0.501960814f, 0.501960814f, 1.000000000f };
    FLinearColor Thistle = { 0.847058892f, 0.749019623f, 0.847058892f, 1.000000000f };
    FLinearColor Tomato = { 1.000000000f, 0.388235331f, 0.278431386f, 1.000000000f };
    FLinearColor Transparent = { 0.000000000f, 0.000000000f, 0.000000000f, 0.000000000f };
    FLinearColor Turquoise = { 0.250980407f, 0.878431439f, 0.815686345f, 1.000000000f };
    FLinearColor Violet = { 0.933333397f, 0.509803951f, 0.933333397f, 1.000000000f };
    FLinearColor Wheat = { 0.960784376f, 0.870588303f, 0.701960802f, 1.000000000f };
    FLinearColor White = { 1.000000000f, 1.000000000f, 1.0f, 1.000000000f };
    FLinearColor WhiteSmoke = { 0.960784376f, 0.960784376f, 0.960784376f, 1.000000000f };
    FLinearColor Yellow = { 1.000000000f, 1.000000000f, 0.000000000f, 1.000000000f };
    FLinearColor YellowGreen = { 0.603921592f, 0.803921640f, 0.196078449f, 1.000000000f };
};

namespace Active
{
inline int lastCarID = 0;
inline int lastCarID2 = 0;
inline int lastCarID3 = 0;
inline int newCarID = 0;
inline int newCarID2 = 0;
inline int newCarID3 = 0;
inline int newCarID4 = 0;

inline int bang = 0;
inline int lastbang = 0;
}




bool thanhgiap1 =false;bool thanhgiap2 =false;bool thanhgiap3 =false;bool thanhgiap4 =false;bool thanhgiap5 =false;bool thanhgiap6 =false;bool thanhgiap7 =false;bool thanhgiap8 =false;

bool skinm41 =false;bool skinm42 =false;bool skinm43 =false;
bool skinm44 =false;
bool skinm45 =false;
bool skinm46 =false;
bool skinm47 =false;
bool skinm48 =false;

bool honey1 =false;
bool dbs1 =false;
bool akm1 =false;
bool akm2 =false;
bool akm3 =false;
bool akm4 =false;
bool akm5 =false;
bool akm6 =false;
bool akm7 =false;
bool akm8 =false;
bool akm9 =false;
bool akm10 =false;
bool akm11 =false;
bool akm12 =false;

//
bool scarl1 =false;bool scarl2 =false;bool scarl3 =false;bool scarl4 =false;bool scarl5 =false;bool scarl6 =false;bool scarl7 =false;bool scarl8 =false;

bool m7621 =false;bool m7622 =false;bool m7623 =false;bool m7624 =false;bool m7625 =false;bool m7626 =false;bool m7627 =false;bool m7628 =false;

bool m161 =false;bool m162 =false;bool m163 =false;bool m164 =false;bool m165 =false;bool m166 =false;bool m167 =false;bool m168 =false;
//
bool ace1 =false;bool ace2 =false;bool ace3 =false;bool ace4 =false;bool ace5 =false;bool ace6 =false;bool ace7 =false;bool ace8 =false;

bool aug1 =false;bool aug2 =false;bool aug3 =false;bool aug4 =false;bool aug5 =false;bool aug6 =false;bool aug7 =false;bool aug8 =false;

bool gloza1 =false;bool gloza2 =false;bool gloza3 =false;bool gloza4 =false;bool gloza5 =false;bool gloza6 =false;bool gloza7 =false;bool gloza8 =false;

bool uzi1 =false;bool uzi2 =false;bool uzi3 =false;bool uzi4 =false;bool uzi5 =false;bool uzi6 =false;bool uzi7 =false;bool uzi8 =false;

bool ump1 =false;bool ump2 =false;bool ump3 =false;bool ump4 =false;bool ump5 =false;bool ump6 =false;bool ump7 =false;bool ump8 =false;

bool qbz1 =false;bool qbz2 =false;bool qbz3 =false;bool qbz4 =false;bool qbz5 =false;bool qbz6 =false;bool qbz7 =false;bool qbz8 =false;

bool sks1 =false;bool sks2 =false;bool sks3 =false;bool sks4 =false;bool sks5 =false;

bool slr1 =false;bool slr2 =false;bool slr3 =false;bool slr4 =false;bool slr5 =false;

bool vss1 =false;bool vss2 =false;bool vss3 =false;bool vss4 =false;bool vss5 =false;

bool mini1 =false;bool mini2 =false;bool mini3 =false;bool mini4 =false;

bool mk141 =false;bool mk142 =false;bool mk143 =false;bool mk144 =false;

bool k981 =false;bool k982 =false;bool k983 =false;bool k984 =false; bool k985 =false;

bool m241 =false;bool m242 =false;bool m243 =false;bool m244 =false; bool m245 =false; bool m246 =false;

bool awm1 =false;bool awm2 =false;bool awm3 =false;bool awm4 =false; bool awm5 =false;

bool arm =false;

bool thomson1 =false;bool thomson2 =false;bool thomson3 =false;bool thomson4 =false;

bool bizon1 =false;bool bizon2 =false;

bool vectorr1 =false;bool vectorr2 =false;bool vectorr3 =false;bool vectorr4 =false; bool vectorr5 =false;


bool s18971 =false;bool s18972 =false;bool s18973 =false;bool s18974 =false;

bool sk12k1 =false;



bool m2491 =false;bool m2492 =false;bool m2493 =false;bool m2494 =false; bool m2495 =false;

bool dp281 =false;bool dp282 =false;bool dp283 =false;bool dp284 =false; bool dp285 =false;

bool pan1 =false;bool pan2 =false;bool pan3 =false;bool pan4 =false; bool pan5 =false;




enum EAimTrigger {
    None = 0,
    Shooting = 1,
    Scoping = 2,
    Both = 3,
    Any = 4
};

@interface PubgLoad()
@property (nonatomic,  weak) NSTimer *timer;
@property (nonatomic,  assign) NSInteger aimcir;
@property (nonatomic,  assign) NSInteger rpr;
@end
BOOL BULLETIBOTNO =true;
BOOL BUlletvisabuilty =false;
//UIWindow *mainWindow;
static PubgLoad *extraInfo;
@implementation PubgLoad


+ (instancetype)cjDrawView
{
    return [[PubgLoad alloc] initWithFrame:[UIScreen mainScreen].bounds];
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
       
        _aimcir= 50;
        _rpr= 50;
        //NSInteger myInteger = 42;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rectChange:) name:@"AimRadiusNoti" object:nil];
        [
            [NSNotificationCenter defaultCenter] addObserverForName: @"AimRadiusNoti"
            object: nil
            queue: nil
            usingBlock: ^ (NSNotification * note) {
                
              
                
            }
        ];
    }
    return self;
}
- (void)rectChange:(NSNotification *)noti
{
    NSInteger val = [noti.object integerValue];
    _aimcir = val;
    _rpr = (int) val;
    _rpr = val;
}
NSString * autoaimdisvalue = [NSString stringWithFormat:@"%.1f" ,FovRadousVal];
int add() // circle radius size
{
    if(FovRadousVal==0){
        FovRadousVal = 230.0f;
    }
    return FovRadousVal;
}
float aimspeedsl()
{
    // return aimspeed.value;
    float val1 = 50;
    //return TurnRate;// aim speed from slider
    return val1;
}
int aimpos()
{
    float speedVal = 100;
    //return sliderrr.value;//maybe speed
    return speedVal;
}
int autodiss()
{
    return Auto1.value;
}
struct sRegion {
    uintptr_t start, end;
};
std::vector<sRegion> trapRegions;
bool isObjectPlayer(UObject *Object) {
    if (!Tools::IsPtrValid(Object)) {
        return false;
    }
    for (auto super = Object->ClassPrivate; Tools::IsPtrValid(super); super = (UClass *) super->SuperStruct) {
        if (super == ASTExtraPlayerCharacter::StaticClass()) {
            return true;
        }
    }
    return false;
}
string encryptDecrypt(string toEncrypt) {
    char key[3] = {'K', 'C', 'Q'}; //Any chars will work, in an array of any size
    string output = toEncrypt;
    for (int i = 0; i < toEncrypt.size(); i++)
        output[i] = toEncrypt[i] ^ key[i % (sizeof(key) / sizeof(char))];
    return output;
}
bool isObjectController(UObject *Object) {
    if (!Tools::IsPtrValid(Object)) {
        return false;
    }
    for (auto super = Object->ClassPrivate; Tools::IsPtrValid(super); super = (UClass *) super->SuperStruct) {
        if (super == ASTExtraPlayerController::StaticClass()) {
            return true;
        }
    }
    return false;
}


bool isObjectInvalid(UObject *obj) {
    if (!Tools::IsPtrValid(obj)) {
        return true;
    }

    if (!Tools::IsPtrValid(obj->ClassPrivate)) {
        return true;
    }

    if (obj->InternalIndex <= 0) {
        return true;
    }

    if (obj->NamePrivate.ComparisonIndex <= 0) {
        return true;
    }

    if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4) {
        return true;
    }

    if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t) obj) >= region.start && ((uintptr_t) obj) <= region.end; }) ||
        std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t) obj->ClassPrivate) >= region.start && ((uintptr_t) obj->ClassPrivate) <= region.end; })) {
        return true;
    }

    return false;
}
kaddr getRealOffset(kaddr offset){
    return (unsigned long)_dyld_get_image_vmaddr_slide(0)+offset;
}
long obbbbl() {
    return getRealOffset(0x108812CB0);//saudgl - UObject 2.7 GL //0x108F6E808vng //0x10907C788gl
};
UWorld *GEWorld;
int GWorldNum = 0;
TUObjectArray gobjects;
UWorld *GetFullWorld()
{
    if(GWorldNum == 0) {
        gobjects = UObject::GUObjectArray->ObjObjects;
        for (int i=0; i< gobjects.Num(); i++)
            if (auto obj = gobjects.GetByIndex(i)) {
                if(obj->IsA(UEngine::StaticClass())) {
                    auto GEngine = (UEngine *) obj;
                    if(GEngine) {
                        tslFont = GEngine->MediumFont;
                        robotoTinyFont = GEngine->MediumFont;
                        auto ViewPort = GEngine->GameViewport;
                        if (ViewPort)
                        {
                            GEWorld = ViewPort->World;
                            GWorldNum = i;
                            return ViewPort->World;
                        }
                    }
                }
            }
    }else {
        auto GEngine = (UEngine *) (gobjects.GetByIndex(GWorldNum));
        if(GEngine) {
            tslFont = GEngine->MediumFont;
            robotoTinyFont = GEngine->MediumFont;
            auto ViewPort = GEngine->GameViewport;
            if(ViewPort) {
                GEWorld = ViewPort->World;
                return ViewPort->World;
            }
        }
    }
    return 0;
}
//TNameEntryArray *GetGNames() {
//return (TNameEntryArray *) fast2();
//}
TNameEntryArray *GetGNames() {
    
    
    //exit
    return ((TNameEntryArray *(*)()) ((unsigned long)_dyld_get_image_vmaddr_slide(0) +0x103DCFB80)//saudgl GNmae entry // 2.7 GL
           
            )();
    
}

template <class T> void GetAllActors(std::vector<T*>& Actors) {
    UGameplayStatics* gGameplayStatics = (UGameplayStatics*)gGameplayStatics->StaticClass();
    auto GWorld = GetFullWorld();
    if (GWorld) {
        TArray<AActor*> Actors2;
        gGameplayStatics->GetAllActorsOfClass((UObject*)GWorld, T::StaticClass(), &Actors2);
        for (int i = 0; i < Actors2.Num(); i++) {
            Actors.push_back((T*)Actors2[i]);
        }
    }
}



FVector GetBoneLocationByName(ASTExtraPlayerCharacter *Actor, const char *BoneName) {
    return Actor->GetBonePos(BoneName, FVector());
}
bool WriteAddr(void *addr, void *buffer, size_t length) {
    unsigned long page_size = sysconf(_SC_PAGESIZE);
    unsigned long size = page_size * sizeof(kaddr);
    return mprotect((void *) ((kaddr) addr - ((kaddr) addr % page_size) - page_size), (size_t) size, PROT_EXEC | PROT_READ | PROT_WRITE) == 0 && memcpy(addr, buffer, length) != 0;
}
template<typename T>
void Write(kaddr addr, T value) {
    WriteAddr((void *) addr, &value, sizeof(T));
}

struct FLinearColor visCol;
ASTExtraPlayerCharacter *g_LocalPlayer;
ASTExtraPlayerController *g_PlayerController;
#define COLOR_BLACK FLinearColor(0, 0, 0, 1.f)
#define COLOR_WHITE FLinearColor(1.f, 1.f, 1.f, 1.f)
#define COLOR_RED   FLinearColor(1.f, 0, 0, 1.f)
#define COLOR_LIME  FLinearColor(0, 1.f, 0, 1.f)
#define COLOR_BLUE  FLinearColor(0, 0, 1.f, 1.f)
#define COLOR_YELLOW  FLinearColor(1, 1, 0.f, 1.f)
#define COLOR_AMMO  FLinearColor(2, 1, 2.f, 2.f)
#define COLOR_ar FLinearColor(1, 2, 1.f, 1.f)
#define COLOR_sn FLinearColor(1, 1, 2.f,2.f)
#define COLOR_sh FLinearColor(2, 2, 1.f,1.f)
#define COLOR_sm FLinearColor(0, 0, 1.f,1.f)
#define COLOR_oth FLinearColor(2, 2, 0.f,0.f)
#define COLOR_item FLinearColor(2, 0, 2.f,0.f)
#define COLOR_armor FLinearColor(1.5, 2.5, 2.f,0.f)
#define COLOR_sc FLinearColor(2.5, 3.5, 1.f,0.f)
#define COLOR_CAR   FLinearColor(1.f, 0.5f, 1.f, 1.f)
#define Whiteg  FLinearColor(247.f, 248.f, 248.f)
float RadianToDegree(float radian)
{
    return radian * (180 / M_PI);
}
float DegreeToRadian(float degree){

    return degree * (M_PI / 180);
}

FVector RadianToDegree(FVector radians)
{
    FVector degrees;
    degrees.X = radians.X * (180 / M_PI);
    degrees.Y = radians.Y * (180 / M_PI);
    degrees.Z = radians.Z * (180 / M_PI);
    return degrees;
}
FVector DegreeToRadian(FVector degrees)
{
    FVector radians;
    radians.X = degrees.X * (M_PI / 180);
    radians.Y = degrees.Y * (M_PI / 180);
    radians.Z = degrees.Z * (M_PI / 180);
    return radians;
}
void VectorAnglesRadar(FVector& forward, FVector& angles)
{
    if (forward.X == 0.f && forward.Y == 0.f)
    {
        angles.X = forward.Z > 0.f ? -90.f : 90.f;
        angles.Y = 0.f;
    }
    else
    {
        angles.X = RAD2DEG(atan2(-forward.Z, forward.Size()));
        angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
    }
    angles.Z = 0.f;
}
void RotateTriangle(std::array < FVector2D, 39 > &points, float rotation)
{
    const auto points_center = (points.at(0) + points.at(1) + points.at(2) + points.at(3) + points.at(4) + points.at(5) + points.at(6)
                                + points.at(7) + points.at(8) + points.at(9) + points.at(10) + points.at(11) + points.at(12) + points.at(13)
                                + points.at(14) + points.at(15) + points.at(16) + points.at(17) + points.at(18) + points.at(19) + points.at(20)
                                + points.at(21) + points.at(22) + points.at(23) + points.at(24) + points.at(25) + points.at(26) + points.at(27)
                                + points.at(28) + points.at(29) + points.at(30) + points.at(31) + points.at(32) + points.at(33) + points.at(34)
                                + points.at(35) + points.at(36) + points.at(37) + points.at(38)) / 39;
    for (auto & point:points) {
        point = point - points_center;
        const auto temp_x = point.X;
        const auto temp_y = point.Y;
        const auto theta = DEG2RAD(rotation);
        const auto c = cosf(theta);
        const auto s = sinf(theta);
        point.X = temp_x * c - temp_y * s;
        point.Y = temp_x * s + temp_y * c;
        point = point + points_center;
    }
}
bool _read(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    vm_size_t size = 0;
    kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)addr, len, (vm_address_t)buffer, &size);
    if(error != KERN_SUCCESS || size != len)
    {
        return false;
    }
    return true;
}
FVector2D FindScreenEdge ( FVector WLocation ,FVector MYLOC,float YAW, float PosX, float PosY , FVector Size , float ZOME )
{
    FVector2D Coord;
    FVector2D Return;
    double num = (double)YAW ;
    double num2 = num * 0.017453292519943295;
    float cY = cos(num2 );
    float sY = sin(num2) ;
    float dX = WLocation.X - MYLOC.X;
    float dY = WLocation.Y - MYLOC.Y;
    Coord.X = ( dY * cY - dX * sY ) /  ZOME;
    Coord.Y = ( dX * cY + dY * sY ) /  ZOME;
    Return.X =  Coord.X + PosX + (Size.X / 2.0f);
    Return.Y = -Coord.Y + PosY + (Size.Y / 2.0f);
    if(Return.X > (PosX + Size.X) )
        Return.X = (PosX + Size.X);
    else if(Return.X < (PosX) )
        Return.X = PosX;
    if(Return.Y > (PosY + Size.Y) )
        Return.Y = (PosY + Size.Y);
    else if(Return.Y < (PosY) )
        Return.Y = PosY;
    return Return;
}
bool _write(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    kern_return_t error = vm_write(mach_task_self(), (vm_address_t)addr, (vm_offset_t)buffer, (mach_msg_type_number_t)len);
    if(error != KERN_SUCCESS)
    {
        return false;
    }
    return true;
}
kaddr GetRealOffset(kaddr offset) {
    if (module == 0) {
        return 0;
    }
    return (module + offset);
}
template<typename T> T Read(kaddr addr) {
    T data;
    _read(addr, reinterpret_cast<void *>(&data), sizeof(T));
    return data;
}
FRotator ToRotator(FVector local, FVector &target) {
    
    /*
    FVector rotation;
    rotation.X = local.X - target.X;
    rotation.Y = local.Y - target.Y;
    rotation.Z = local.Z - target.Z;
    FRotator newViewAngle = {0};
    FRotator newViewAngleLocal = {0};
    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);// sqrt: return the square root of any number
    //--
    float hyp_local = sqrt(local.X * local.X + local.Y * local.Y);//get local rotation
    newViewAngleLocal.Yaw = atan(local.Y / local.X) * (180.f / (float) PI);//get local Yaw
    //--
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) PI);//tangent
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) PI);//tangent
    newViewAngle.Roll = (float) 0.f;
    //-
    float RangVal = 100;
    float RangeHalf = RangVal / 2;
    float LeftAngle (newViewAngleLocal.Yaw + RangeHalf);
    float RightAngle (newViewAngleLocal.Yaw - RangeHalf);
    if (LeftAngle < 0){
        LeftAngle = LeftAngle * -1;
    }
    if(RightAngle < 0){
        RightAngle = RightAngle * -1;
    }
    NSLog(@"the newViewAngle.Yaw = %f",newViewAngle.Yaw);
    NSLog(@"the newViewAngleLocal.Yaw = %f",newViewAngleLocal.Yaw);
    float local_180 = newViewAngleLocal.Yaw + 180.0f;
    if ((newViewAngleLocal.Yaw  <= LeftAngle) && (newViewAngleLocal.Yaw >= RightAngle )){
        if (rotation.X >= 0.f)
            newViewAngle.Yaw += 180.0f;
        NSLog(@"the +180 newViewAngle.Yaw = %f",newViewAngle.Yaw);
        //NSLog(@"the +180 newViewAngleLocal.Yaw = %f",newViewAngleLocal.Yaw += 180.0f);
        return newViewAngle;
        
    }else {
        FRotator empty = {0};
        return empty;
    }
    */
    
    
    
    
     FVector rotation;
     rotation.X = local.X - target.X;
     rotation.Y = local.Y - target.Y;
     rotation.Z = local.Z - target.Z;
     FRotator newViewAngle = {0};
     float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);// sqrt: return the square root of any number
     newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) PI);//tangent
     newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) PI);//tangent
     newViewAngle.Roll = (float) 0.f;
     if (rotation.X >= 0.f)
     newViewAngle.Yaw += 180.0f;
     return newViewAngle;
     }
     FRotator ToRotatorAIMBOT(FVector local, FVector &target) {
     FVector rotation;
     rotation.X = local.X - target.X;
     rotation.Y = local.Y - target.Y;
     rotation.Z = local.Z - target.Z;
     FRotator newViewAngle = {0};
     float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);
     newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f/ (float) PI);
     newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) PI);
     newViewAngle.Roll = (float) 0.f;
     if (rotation.X >= 0.f)
     newViewAngle.Yaw += 90.0f;//aimspeedsl();
     return newViewAngle;
     
}
void DrawRectangle(AHUD * HUD, FVector2D Pos, float Width, float Height, float Thickness,
                   FLinearColor Color)
{
    HUD->DrawLine(Pos.X, Pos.Y, Pos.X + Width, Pos.Y, Color, Thickness);
    HUD->DrawLine(Pos.X, Pos.Y, Pos.X, Pos.Y + Height, Color, Thickness);
    HUD->DrawLine(Pos.X + Width, Pos.Y, Pos.X + Width, Pos.Y + Height, Color, Thickness);
    HUD->DrawLine(Pos.X, Pos.Y + Height, Pos.X + Width, Pos.Y + Height, Color, Thickness);
}
void DrawFilledRectangle(AHUD *HUD, FVector2D Pos, float Width, float Height, FLinearColor Color) {
    HUD->DrawRect(Color, Pos.X, Pos.Y, Width, Height);
    for (size_t i = 0; i <5; i++)
        HUD->  DrawRect(FLinearColor(255, 81, 75, 61), Pos.X + (i *2), Pos.Y, 1, 6);
}
void DrawLine(AHUD *HUD, FVector2D posFrom, FVector2D posTo, float Thickness, FLinearColor Color) {
    HUD->DrawLine(posFrom.X, posFrom.Y, posTo.X, posTo.Y, Color, Thickness);
}
void DrawCircle(UCanvas *Canvas, int x, int y, int radius, int numsides, FLinearColor OutlineColor){
    float Step = M_PI * 2.0 / numsides;
    int Count = 0;
    FVector2D V[128];
    for (float a = 0; a < M_PI * 2.0; a += Step)
    {
        float X1 = radius * cos(a) + x;
        float Y1 = radius * sin(a) + y;
        float X2 = radius * cos(a + Step) + x;
        float Y2 = radius * sin(a + Step) + y;
        V[Count].X = X1;
        V[Count].Y = Y1;
        V[Count + 1].X = X2;
        V[Count + 1].Y = Y2;
        Canvas->K2_DrawLine(FVector2D({ V[Count].X, V[Count].Y }), FVector2D({ X2, Y2 }), 1.f, OutlineColor);
    }
}
#define TSL_FONT_DEFAULT_SIZE 20
static UFont *tslFont = 0, *robotoTinyFont = 0 ;
static UFont *itemfont =0 ;
void DrawOutlinedText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(itemfont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
    tslFont->LegacyFontSize = 10;
}
void DrawText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, false, {});
}
void DrawwepText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(robotoTinyFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, {});
}
void DrawSmallOutlinedText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(robotoTinyFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}
void DrawTextcan(UCanvas *Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = true) {
    Canvas->K2_DrawText(itemfont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}
void DrawSmallText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(robotoTinyFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, false, {});
}
void DrawRECTNEW(UCanvas* canvas,  FVector2D min,  FVector2D max, FLinearColor color, float thickness)
{
    canvas->K2_DrawLine(min, FVector2D(max.X, min.Y), thickness, color);
    canvas->K2_DrawLine(min, FVector2D(min.X, max.Y), thickness, color);
    canvas->K2_DrawLine(FVector2D(min.X, max.Y), max, thickness, color);
    canvas->K2_DrawLine(FVector2D(max.X, min.Y), max, thickness, color);
}
void drawFilledRect(UCanvas* canvas, FVector2D min,  FVector2D max, float w, float h, FLinearColor color)
{
    for (float i = 0.f; i < h; i += 1.f)
        canvas->K2_DrawLine(max+i, min+i, 1.f, color);
}
int GetDeviceMaxFPSByDeviceLevel(int a1, int a2, Byte *a3)
{
    int result;
    result = 120;//Ur FPS
    *a3 = result;
    return result;
}
void HealthBar(AHUD *HUD, ASTExtraCharacter* pEntity, int x, int y, int height ,FLinearColor color)
{
    float flBoxes = std::ceil( pEntity->Health / 10.f );
    float flX = x - 7 - height / 3.f; float flY = y - 1;
    float flHeight = height / 10.f;
    float flMultiplier = 12 / 360.f; flMultiplier *= flBoxes - 1;
    HUD->DrawRect( color,flX, flY, 4, height + 2 );
    DrawRectangle(HUD,  flX, flY, 4, height + 2, color);
    HUD->DrawRect(color,flX + 1, flY, 2, flHeight * flBoxes + 1 );
    for ( int i = 0; i < 10; i++ )
        HUD->DrawLine( flX, flY + i * flHeight, flX + 4, flY + i * flHeight ,color,1.f);
}
FVector2D WorldToRadar(float Yaw, FVector Origin, FVector LocalOrigin, float PosX, float PosY,
                       FVector Size, bool & outbuff)
{
    bool flag = false;
    double num = (double)Yaw;
    double num2 = num * 0.017453292519943295;
    float num3 = (float)std::cos(num2);
    float num4 = (float)std::sin(num2);
    float num5 = Origin.X - LocalOrigin.X;
    float num6 = Origin.Y - LocalOrigin.Y;
    FVector2D vector;
    vector.X = (num6 * num3 - num5 * num4) / 150.f;
    vector.Y = (num5 * num3 + num6 * num4) / 150.f;
    FVector2D vector2;
    vector2.X = vector.X + PosX + Size.X / 2.f;
    vector2.Y = -vector.Y + PosY + Size.Y / 2.f;
    bool flag2 = vector2.X > PosX + Size.X;
    if (flag2)
    {
        vector2.X = PosX + Size.X;
    }
    else
    {
        bool flag3 = vector2.X < PosX;
        if (flag3)
        {
            vector2.X = PosX;
        }
    }
    bool flag4 = vector2.Y > PosY + Size.Y;
    if (flag4)
    {
        vector2.Y = PosY + Size.Y;
    }
    else
    {
        bool flag5 = vector2.Y < PosY;
        if (flag5)
        {
            vector2.Y = PosY;
        }
    }
    bool flag6 = vector2.Y == PosY || vector2.X == PosX;
    if (flag6)
    {
        flag = true;
    }
    outbuff = flag;
    return vector2;
}


 
void DrawRadarcan(UCanvas* Canvas,float yaw, FVector Player, FVector Local, int xAxis, int yAxis, int width, int height, FLinearColor color)
{
    bool out = false;
    FVector siz;
    siz.X = width;
    siz.Y = height;
    FVector pos;
    pos.X = xAxis;
    pos.Y = yAxis;
    float RadarCenterX = pos.X + (siz.X / 2);
    float RadarCenterY = pos.Y + (siz.Y / 2);
    Canvas->K2_DrawBox({pos.X, pos.Y}, {siz.X, siz.Y}, 1);
    Canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {pos.X, pos.Y}, 1.f,  color);
    Canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {pos.X + siz.X, pos.Y}, 1.f,  color);
    Canvas->K2_DrawLine({pos.X, RadarCenterY}, {pos.X + siz.X, RadarCenterY}, 1.f,  color);
    Canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {RadarCenterX, pos.Y + siz.Y}, 1.f,  color);
    
    DrawCircle( Canvas, RadarCenterX, RadarCenterY, 2, 2, color);
    FVector2D single = WorldToRadar(yaw, Player, Local, pos.X, pos.Y, FVector(siz.X, siz.Y, 0), out);
    if ( g_disstance>= 0.f && g_disstance < 80)
    {
        DrawCircle( Canvas,single.X, single.Y, 5, 2, color);
    }
}
void FixTriangle(float& XPos, float& YPos, int screenDist){
    //
    // —————————Triangle X Pos—————————————
    if(XPos > (screenWidth - 16)) {
        XPos = screenWidth;
        XPos -= screenDist;
    }
    // ——————————————————————
    if(XPos < 16) {
        XPos = 16;
        XPos += screenDist;
    }
    // ————————— Triangle Y Pos —————————————
    if(YPos > (screenHeight - 16)) {
        YPos = screenHeight;
        YPos -= screenDist;
    }
    if(YPos < 16) {
        YPos = 16;
        YPos += screenDist;
    }
}
void DrawArrows(AHUD * hud,std::array < FVector2D, 39 > Loc, float thickness, FLinearColor color) {
    for (int i = 10; i < 25; i++) {
        DrawLine(hud,Loc.at(i), Loc.at(7), thickness, color);
    }
    for (int i = 26; i < 38; i++) {
        DrawLine(hud,Loc.at(i), Loc.at(7), thickness + 1.5, color);
        DrawLine(hud,Loc.at(i), Loc.at(8), thickness+ 1.5f, color);
        DrawLine(hud,Loc.at(i), Loc.at(9), thickness + 1.5f, color);
    }
    DrawLine(hud,Loc.at(0), Loc.at(1), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(1), Loc.at(2), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(2), Loc.at(6), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(6), Loc.at(5), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(5), Loc.at(4), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(4), Loc.at(3), thickness * 1.f, COLOR_BLACK);
    DrawLine(hud,Loc.at(3), Loc.at(0), thickness * 1.f, COLOR_BLACK);
}

void LineE(ImDrawList *draw, FVector posFrom, FVector posTo, float Thickness, ImColor col) {
 draw->AddLine({posFrom.X, posFrom.Y},{posTo.X, posTo.Y},col, 2.0f);
}

void Lineee(ImDrawList *draw,FVector2D origin, FVector2D dest, ImColor color)
{
   draw->AddLine({origin.X, origin.Y},{dest.X, dest.Y},color, 2.0f);
}



void DrawArrowsFilled(ImDrawList *draw, FVector xy1, FVector xy2, FVector xy3,FVector xy4, FVector xy5 , FVector xy6 , FVector xy7, float Thickness, ImColor col) {
LineE(draw,xy1, xy2, Thickness,col);
LineE(draw,xy2, xy3, Thickness,col);
LineE(draw,xy3, xy7, Thickness,col);
LineE(draw,xy7, xy6, Thickness,col);
LineE(draw,xy6, xy5, Thickness,col);
LineE(draw,xy5, xy4, Thickness,col);
LineE(draw,xy4, xy1, Thickness,col);
}

UKismetMathLibrary* umcc = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();
FVector2D pushToScreenBorder(FVector2D Pos, FVector2D screen, int borders, int offset) {
    int x = (int)Pos.X;
    int y = (int)Pos.Y;
    if ((borders & 1) == 1) {
        y = 0 - offset;
    }
    if ((borders & 2) == 2) {
        x = (int)screen.X + offset;
    }
    if ((borders & 4) == 4) {
        y = (int)screen.Y + offset;
    }
    if ((borders & 8) == 8) {
        x = 0 - offset;
    }
    return FVector2D(x, y);
}
int isOutsideSafezone(FVector2D pos, FVector2D screen) {
    FVector2D mSafezoneTopLeft(screen.X * 0.04f, screen.Y * 0.04f);
    FVector2D mSafezoneBottomRight(screen.X * 0.96f, screen.Y * 0.96f);
    int result = 0;
    if (pos.Y < mSafezoneTopLeft.Y) {
        result |= 1;
    }
    if (pos.X > mSafezoneBottomRight.X) {
        result |= 2;
    }
    if (pos.Y > mSafezoneBottomRight.Y) {
        result |= 4;
    }
    if (pos.X < mSafezoneTopLeft.X) {
        result |= 8;
    }
    return result;
}
void DrawFilledTriangle(AHUD * HUD, float x1, float y1, float x2, float y2, float x3, float y3, float thickness, FLinearColor color) {
    HUD->DrawLine(x1, y1, x2, y2, color, thickness);
    HUD->DrawLine(x2, y2, x3, y3, color, thickness);
    HUD->DrawLine(x3, y3, x1, y1, color, thickness);
   
 
    for (int x = x1; x <= x2; x++) {
        for (int y = y1; y <= y2; y++) {
            HUD->DrawLine(x3, y3, x, y, color, 1.f);
        }
    }
}
void DrawTriangle(AHUD * HUD, float x1, float y1, float x2, float y2, float x3, float y3, float thickness, FLinearColor color) {
    HUD->DrawRect( color,x1, y1, x2, y2);
    HUD->DrawRect(color,x2, y2, x3, y3);
    HUD->DrawRect(color,x3, y3, x1, y1);
}
UGameplayStatics* iosde = (UGameplayStatics*)UGameplayStatics::StaticClass();
ASTExtraPlayerController *localPlayerController = 0;
#define W2S(w, s) iosde->ProjectWorldToScreen(localPlayerController, w, true, s)
FVector RotateCorner(FVector origin, FVector corner, float theta)
{
    float x = corner.X - origin.X;
    float y = corner.Y - origin.Y;
    return {
        origin.X + (x * cos(theta) - y * sin(theta)),
        origin.Y + (x * sin(theta) + y * cos(theta)),
        corner.Z
    };
}
void VectorToAngles(FVector v, FVector &a) {
float tmp, yaw, pitch;
if (v.Y == 0 && v.X == 0) {
yaw = 0;
if (v.Z > 0)
pitch = 270;
else pitch = 90;
} else {
yaw = (atan2(v.Y, v.X) * 180 / M_PI);
if (yaw < 0)
yaw += 360;
tmp = sqrt(v.X * v.X + v.Y * v.Y);
pitch = (atan2(-v.Z, tmp) * 180 / M_PI);
if (pitch < 0)
pitch += 360; }
a.X = pitch;
a.Y = yaw;
a.Z = 0;
}

void RotateArrows(std::array<FVector, 7>& points, float rotation) {
const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
for (auto& point : points) {
point = point - points_center;
const auto temp_x = point.X;
const auto temp_y = point.Y;
const auto theta = DEG2RAD(rotation);
const auto c = cosf(theta);
const auto s = sinf(theta);
point.X = temp_x * c - temp_y * s;
point.Y = temp_x * s + temp_y * c;
point = point + points_center;
 }
}

//#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(g_LocalController, w, true, s)

void Circle3D(ImDrawList* draw, FVector origin, float radius, ImColor color, float thinkless)
{
    const int doan_thang = 50;
    float step = 2 * IM_PI / doan_thang;
    FVector2D prev;
    Vector3 curValid3 = Vector3(origin.X + radius, origin.Y, origin.Z);
    FVector curValidF;
    curValidF.X = curValid3.X;
    curValidF.Y = curValid3.Y;
    curValidF.Z = curValid3.Z;
    bool curValid = W2S(curValidF, &prev);

    for (int i = 1; i <= doan_thang; ++i)
    {
        float angle = i * step;
        FVector2D cur;
        Vector3 nextValid3 = Vector3(origin.X + radius * cos(angle), origin.Y + radius * sin(angle), origin.Z);
        FVector nextValidF;
        nextValidF.X = nextValid3.X;
        nextValidF.Y = nextValid3.Y;
        nextValidF.Z = nextValid3.Z;
        bool nextValid = W2S(nextValidF, &cur);
        if (curValid && nextValid)
        {
            draw->AddLine(ImVec2(prev.X, prev.Y), ImVec2(cur.X, cur.Y), color, thinkless);
        }
        curValid = nextValid;
        prev = cur;
    }
}

FRotator ClampAngless(FRotator inRot) {
    FRotator outRot = inRot;
    if (outRot.Pitch > 180)
        outRot.Pitch -= 360;
    if (outRot.Pitch < -180)
        outRot.Pitch += 360;

    if (outRot.Pitch < -75.f)
        outRot.Pitch = -75.f;
    else if (outRot.Pitch > 75.f)
        outRot.Pitch = 75.f;

    while (outRot.Yaw < -180.0f)
        outRot.Yaw += 360.0f;
    while (outRot.Yaw > 180.0f)
        outRot.Yaw -= 360.0f;
    return outRot;
}
void DrawBox3D(AHUD *HUD, AActor* actor, FLinearColor Color, FVector origin, FVector extent) {


    auto MathLibrary = (UKismetMathLibrary *) UKismetMathLibrary::StaticClass();
    auto GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    FRotator rotation = actor->K2_GetActorRotation();
    float yaw = MathLibrary->DegreesToRadians((int)(rotation.Yaw + 450.0f) % 360);
    FVector2D ts1, ts2, ts3, ts4, bs1, bs2, bs3, bs4;
    FVector t1, t2, t3, t4, b1, b2, b3, b4;
    t1 = t2 = t3 = t4 = b1 = b2 = b3 = b4 = origin;
    t1.X -= extent.X;
    t1.Y -= extent.Y;
    t1.Z -= extent.Z;
    t2.X += extent.X;
    t2.Y -= extent.Y;
    t2.Z -= extent.Z;
    t3.X += extent.X;
    t3.Y += extent.Y;
    t3.Z -= extent.Z;
    t4.X -= extent.X;
    t4.Y += extent.Y;
    t4.Z -= extent.Z;
    t1 = RotateCorner(origin, t1, yaw);
    t2 = RotateCorner(origin, t2, yaw);
    t3 = RotateCorner(origin, t3, yaw);
    t4 = RotateCorner(origin, t4, yaw);
    b1.X -= extent.X;
    b1.Y -= extent.Y;
    b1.Z += extent.Z;
    b2.X += extent.X;
    b2.Y -= extent.Y;
    b2.Z += extent.Z;
    b3.X += extent.X;
    b3.Y += extent.Y;
    b3.Z += extent.Z;
    b4.X -= extent.X;
    b4.Y += extent.Y;
    b4.Z += extent.Z;
    b1 = RotateCorner(origin, b1, yaw);
    b2 = RotateCorner(origin, b2, yaw);
    b3 = RotateCorner(origin, b3, yaw);
    b4 = RotateCorner(origin, b4, yaw);
    if (GameplayStatics->ProjectWorldToScreen(g_PlayerController, b1, false, &bs1) && GameplayStatics->ProjectWorldToScreen(g_PlayerController, b2, false, &bs2)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, b3, false, &bs3)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, b4, false, &bs4)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, t1, false, &ts1)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, t2, false, &ts2)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, t3, false, &ts3)&& GameplayStatics->ProjectWorldToScreen(g_PlayerController, t4, false, &ts4)) {
        DrawLine(HUD, ts1, ts2, EspBoxThik, Color);
        DrawLine(HUD, ts2, ts3, EspBoxThik, Color);
        DrawLine(HUD, ts3, ts4, EspBoxThik, Color);
        DrawLine(HUD, ts4, ts1, EspBoxThik, Color);
        DrawLine(HUD, bs1, bs2, EspBoxThik, Color);
        DrawLine(HUD, bs2, bs3, EspBoxThik, Color);
        DrawLine(HUD, bs3, bs4, EspBoxThik, Color);
        DrawLine(HUD, bs4, bs1, EspBoxThik, Color);
        DrawLine(HUD, ts1, bs1, EspBoxThik, Color);
        DrawLine(HUD, ts2, bs2, EspBoxThik, Color);
        DrawLine(HUD, ts3, bs3, EspBoxThik, Color);
        DrawLine(HUD, ts4, bs4, EspBoxThik, Color);
    }
}
void Box3D1(ImDrawList *draw, FVector origin, FVector extends, FLinearColor Color, ImColor col) {
    origin.X -= extends.X / 2.f;
    origin.Y -= extends.Y / 2.f;
    origin.Z -= extends.Z / 2.f;
    
 FVector one = origin;
 FVector two = origin; two.X += extends.X;
 FVector tree = origin; tree.X += extends.X; tree.Y += extends.Y;
 FVector four = origin; four.Y += extends.Y;

 FVector five = one; five.Z += extends.Z;
 FVector six = two; six.Z += extends.Z;
 FVector seven = tree; seven.Z += extends.Z;
 FVector eight = four; eight.Z += extends.Z;

    FVector2D s1, s2, s3, s4, s5, s6, s7, s8;
    if (W2S(one, &s1) && W2S(two, &s2) && W2S(tree, &s3) && W2S(four, &s4) &&
        W2S(five, &s5) && W2S(six, &s6) && W2S(seven, &s7) && W2S(eight, &s8))
    {
        Lineee(draw,s1, s2, col);
        Lineee(draw,s2, s3, col);
        Lineee(draw,s3, s4, col);
        Lineee(draw,s4, s1, col);

        Lineee(draw,s5, s6, col);
        Lineee(draw,s6, s7, col);
        Lineee(draw,s7, s8, col);
        Lineee(draw,s8, s5, col);
 
        Lineee(draw,s1, s5, col);
        Lineee(draw,s2, s6, col);
        Lineee(draw,s3, s7, col);
        Lineee(draw,s4, s8, col);
     }}
void Box3D(AHUD *HUD , FVector origin, FVector extends , FLinearColor Color, int tik)
{
    
  
    origin.X -= extends.X;
    origin.Y -= extends.Y;
    origin.Z -= extends.Z;
    // bottom plane
    FVector one = origin;
    FVector two = origin; two.X += extends.X;
    FVector three = origin; three.X += extends.X; three.Y += extends.Y;
    FVector four = origin; four.Y += extends.Y;
    
    FVector five = one; five.Z += extends.Z;
    FVector six = two; six.Z += extends.Z;
    FVector seven = three; seven.Z += extends.Z;
    FVector eight = four; eight.Z += extends.Z;
    
    FVector2D s1, s2, s3, s4, s5, s6, s7, s8;
    if (!W2S(one, &s1) || !W2S(two, &s2) || !W2S(three, &s3) || !W2S(four, &s4))
        return;
    
    if (!W2S(five, &s5) || !W2S(six, &s6) || !W2S(seven, &s7) || !W2S(eight, &s8))
        return;
    
    DrawLine(HUD, s1, s2, tik, Color);
    DrawLine(HUD, s2, s3, tik, Color);
    DrawLine(HUD, s3, s4, tik, Color);
    DrawLine(HUD, s4, s1, tik, Color);
    
    DrawLine(HUD, s5, s6, tik, Color);
    DrawLine(HUD, s6, s7, tik, Color);
    DrawLine(HUD, s7, s8, tik, Color);
    DrawLine(HUD, s8, s5, tik, Color);
    
    DrawLine(HUD, s1, s5, tik, Color);
    DrawLine(HUD, s2, s6, tik, Color);
    DrawLine(HUD, s3, s7, tik, Color);
    DrawLine(HUD, s4, s8, tik, Color);
    
    
}


void box3d( AHUD *HUD, ASTExtraPlayerCharacter *Player , FVector Root , FLinearColor Color){
    
    FVector boxRescaling = { 0 /*thickness*/, 0 /*top*/, 0 /*bottom*/ };
    float yy= 0;
    
    
    auto playerstate =  Player->PoseState;
    if (playerstate== ESTEPoseState::ESTEPoseState__Stand || playerstate == ESTEPoseState::ESTEPoseState__Sprint){
        boxRescaling = {42,180.f,5}; yy= 55;
    }
    
    
    if (playerstate == ESTEPoseState::ESTEPoseState__Crouch ||playerstate== ESTEPoseState::ESTEPoseState__CrouchSprint){
        boxRescaling = {42,120.f,5}; yy= 55;
    }
    
    
    
    if (playerstate == ESTEPoseState::ESTEPoseState__Prone || playerstate == ESTEPoseState::ESTEPoseState__Crawl){
        boxRescaling = {42,60.f,5}; yy=200;
    }
    
    
    
    if (playerstate == ESTEPoseState::ESTEPoseState__Dying){
        boxRescaling = {100,80.f,5}; yy= 150; //150
    }
    
    
    
    
    
    
    FVector b1, b2, b3, b4, t1, t2, t3, t4;
    b1.Z = b2.Z = b3.Z = b4.Z = Root.Z - boxRescaling.Z;
    
    float yaw = Player->K2_GetActorRotation().Yaw;
#define TORAD(x) ((x) * (M_PI / 180.f))
    
    b1.X = Root.X + cosf(DEG2RAD(yaw + 45.f)) * boxRescaling.X;
    b1.Y = Root.Y + sinf(DEG2RAD(yaw + 45.f)) * yy;
    
    b2.X = Root.X + cosf(DEG2RAD(yaw + 135.f)) * boxRescaling.X;
    b2.Y = Root.Y + sinf(DEG2RAD(yaw + 135.f)) * yy;
    
    b3.X = Root.X + cosf(DEG2RAD(yaw + 225.f)) * boxRescaling.X;
    b3.Y = Root.Y + sinf(DEG2RAD(yaw + 225.f)) * yy;
    
    b4.X = Root.X + cosf(DEG2RAD(yaw + 315.f)) * boxRescaling.X;
    b4.Y = Root.Y + sinf(DEG2RAD(yaw + 315.f)) * yy;
    
#undef TORAD
    
    t1 = b1, t2 = b2, t3 = b3, t4 = b4;
    t1.Z = t2.Z = t3.Z = t4.Z = Root.Z + boxRescaling.Y;
    
    FVector2D  b11, b22, b33, b44, t11, t22, t33, t44;
    W2S(b1, &b11);
    W2S(b2, &b22);
    W2S(b3, &b33);
    W2S(b4, &b44);
    
    W2S(t1, &t11);
    W2S(t2, &t22);
    W2S(t3, &t33);
    W2S(t4, &t44);
    
    
    
    
    
    DrawLine(HUD, b11, b22, 2.4, Color);
    DrawLine(HUD, b22, b33, 2.4, Color);
    DrawLine(HUD, b33, b44, 2.4, Color);
    DrawLine(HUD, b44, b11, 2.4, Color);
    
    
    
    
    DrawLine(HUD, b11, t11, 2.4, Color);
    DrawLine(HUD, b22, t22, 2.4, Color);
    DrawLine(HUD, b33, t33, 2.4, Color);
    DrawLine(HUD, b44, t44, 2.4, Color);
    
    
    
    
    
    DrawLine(HUD, t11, t22, 2.4, Color);
    DrawLine(HUD, t22, t33, 2.4, Color);
    DrawLine(HUD, t33, t44, 2.4, Color);
    DrawLine(HUD, t44, t11, 2.4, Color);
    
    
    
    
    
    
    
}

bool offscreen (FVector2D point , FVector2D scren)
{
    if (point.X <= 0 || point.Y <= 0 || point.X >= scren.X || point.Y >= scren.Y)
    {
        return true;
        
    }
    
    return false;
}


void DrawWeirdBox(AHUD *HUD,AActor * actor, FLinearColor Color, FVector origin, FVector2D extent)
{
    auto GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    FVector2D bs1 ,bs2, bs3, bs4;
    FVector b1, b2, b3, b4;
    b1 = b2 = b3 = b4 = origin;
    b1.X -= extent.X;
    b1.Y -= extent.Y;
    b2.X += extent.X;
    b2.Y -= extent.Y;
    b3.X += extent.X;
    b3.Y += extent.Y;
    b4.X -= extent.X;
    b4.Y += extent.Y;
    if (W2S(b1, &bs1)
        && W2S(b2, &bs2)
        && W2S(b3, &bs3)
        && W2S(b4, &bs4))
    {
        DrawLine(HUD,bs1, bs2, 2.5f, Color);
        DrawLine(HUD,bs2, bs3, 2.5f, Color);
        DrawLine(HUD,bs3, bs4, 2.5f, Color);
        DrawLine(HUD,bs4, bs1, 2.5f, Color);
    }
}
void DrawRadarHUD(UCanvas *canvas,float Camera, FVector Player, FVector Local, int xAxis, int yAxis, int width, int height,int Distance, FLinearColor color)
{
    bool out = false;
    FVector siz;
    siz.X = width;
    siz.Y = height;
    FVector pos;
    pos.X = xAxis;
    pos.Y = yAxis;
    float RadarCenterX = pos.X + (siz.X / 2);
    float RadarCenterY = pos.Y + (siz.Y / 2);
    canvas->K2_DrawBox( FVector2D {pos.X, pos.Y},  FVector2D {siz.X, siz.Y}, 1.f);
    color.A =0.3;color.B=0.3;color.G=0.3;color.R=0.3;
    canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {pos.X, pos.Y},1.f, color);
    canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {pos.X + siz.X, pos.Y},1.f, color);
    canvas->K2_DrawLine({pos.X, RadarCenterY}, {pos.X + siz.X, RadarCenterY},1.f, color);
    canvas->K2_DrawLine({RadarCenterX, RadarCenterY}, {RadarCenterX, pos.Y + siz.Y},1.f, color);
    DrawCircle(canvas, RadarCenterX, RadarCenterY, 2, 2, color);
    FVector2D single = WorldToRadar(Camera, Player, Local, pos.X, pos.Y, FVector(siz.X, siz.Y, 0), out);
    if (Distance >= 0.f && Distance < Options::distance_Radar)
    {
        DrawCircle(canvas, single.X, single.Y, 5, 2, color);
    }
}
void HealthBarnew( AHUD *HUD,float Health, float x, float y, int height )
{
    float flBoxes = std::ceil( Health / 10.f );
    float flX = x - 7 - height / 3.f; float flY = y - 1;
    float flHeight = height / 10.f;
    float flMultiplier = 12 / 360.f; flMultiplier *= flBoxes - 1;
    //FLinearColor  ColHealth =( flMultiplier, 1, 1 );
    DrawRectangle( HUD,flX, flY, 4, height + 2, COLOR_YELLOW );
    DrawFilledRectangle(HUD,{flX, flY}, 4, height + 2, COLOR_BLACK);
    DrawRectangle( HUD,flX + 1, flY, 2, flHeight * flBoxes + 1, COLOR_RED );
}
void Draw3DBox(AHUD *HUD, FVector2D s1, FVector2D s2, FVector2D s3, FVector2D s4, FVector2D s5, FVector2D s6, FVector2D s7 , FVector2D s8, float Thickness, FLinearColor Color){
    HUD->DrawLine(s1.X,s1.Y, s2.X,s2.Y, Color, Thickness);
    HUD->DrawLine(s2.X,s2.Y, s3.X,s3.Y, Color, Thickness);
    HUD->DrawLine(s3.X,s3.Y, s4.X,s4.Y, Color, Thickness);
    HUD->DrawLine(s4.X,s4.Y, s1.X,s1.Y, Color, Thickness);
    HUD->DrawLine(s5.X,s5.Y, s6.X,s6.Y, Color, Thickness);
    HUD->DrawLine(s6.X,s6.Y, s7.X,s7.Y, Color, Thickness);
    HUD->DrawLine(s7.X,s7.Y, s8.X,s8.Y, Color, Thickness);
    HUD->DrawLine(s8.X,s8.Y, s5.X,s5.Y, Color, Thickness);
    HUD->DrawLine(s1.X,s1.Y, s5.X,s5.Y, Color, Thickness);
    HUD->DrawLine(s2.X,s2.Y, s6.X,s6.Y, Color, Thickness);
    HUD->DrawLine(s3.X,s3.Y, s7.X,s7.Y, Color, Thickness);
    HUD->DrawLine(s4.X,s4.Y, s8.X,s8.Y, Color, Thickness);
}
void VericalHEALTHBAR(AHUD *HUD ,float x ,float y , float health,FLinearColor color  ){
    HUD->   DrawRect(color, x, y + 30, 5, 10);
    for (size_t i = 0; i < 20; i++)
        HUD->  DrawRect(color, x, y + (i * 5), 5, 1);
}
void VericalHEALTHBAR(AHUD *HUD, float x, float y, float Health,FLinearColor color ,bool vertical)
{
    if (Health>0)
    {
        if (vertical)
        {
            HUD->   DrawRect(color, x - 1, y - 1, 7, 102);
            if ( Health > 1)
                HUD-> DrawRect(color, x, y, 5, 10);
            if ( Health > 10)
                HUD->DrawRect(color, x, y + 10, 5, 10);
            if ( Health > 20)
                HUD-> DrawRect(color, x, y + 20, 5, 10);
            if ( Health > 30)
                HUD->   DrawRect(color, x, y + 30, 5, 10);
            if ( Health > 40)
                HUD->   DrawRect(color, x, y + 40, 5, 10);
            if ( Health > 50)
                HUD->   DrawRect(color, x, y + 50, 5, 10);
            if ( Health > 60)
                HUD->   DrawRect( color, x, y + 60, 5, 10);
            if ( Health > 70)
                HUD->   DrawRect(color, x, y + 70, 5, 10);
            if ( Health > 80)
                HUD->   DrawRect(color, x, y + 80, 5, 10);
            if ( Health > 100)
                HUD->  DrawRect( color, x, y + 90, 5, 10);
            for (size_t i = 0; i < 20; i++)
                HUD->  DrawRect(color, x, y + (i * 5), 5, 1);
        }
    }
}
auto GetTargetForAimBotByDistance() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
    USTExtraGameInstance *playerChar = 0;
    
    auto GWorld = GetFullWorld();
    if (GWorld) {
        UNetDriver *NetDriver = GWorld->NetDriver;
        if (NetDriver) {
            UNetConnection *ServerConnection = NetDriver->ServerConnection;
            if (ServerConnection) {
                localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
            }
        }
        if (localPlayerController) {
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
            GetAllActors(PlayerCharacter);
            for (auto actor = PlayerCharacter.begin(); actor != PlayerCharacter.end(); actor++) {
                auto Actor = *actor;
                if (Actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                    localPlayer = Actor;
                    break;
                }
            }
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter2;
            GetAllActors(PlayerCharacter2);
            for (auto actor = PlayerCharacter2.begin(); actor != PlayerCharacter2.end();
                 actor++)
            {
                auto Player = *actor;
                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;
                if (Player->TeamID == localPlayer->TeamID)
                    continue;
                if (Player->bDead)
                    continue;
                if (Player->bHidden )
                    continue;
                if (!Player->Mesh)
                    continue;
                if (!Player->RootComponent)
                    continue;
                if (isAimKnocked) {
                    if (Player->Health == 0.0f)
                        continue;
                }
                if(isAimvisual){
                    if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }
                if (Igronebot) {
                    if (Player->bEnsure)
                        continue;
                }
                float dist = Player->GetDistanceTo(localPlayer);
                if (dist < max) {
                    max = dist;
                    result = Player;
                }
            } PlayerCharacter2.clear();
        }
    }
    return result;
}
bool isInsideFOV(int x, int y) {
    int circle_x = screenWidth / 2;
    int circle_y = screenHeight / 2;
    int rad = (int) add();
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}
auto GetTargetForAimBotByFOV() {
    UGameplayStatics *GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    ASTExtraPlayerCharacter *result = 0;
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
#define W2S(w, s) GameplayStatics->ProjectWorldToScreen(localPlayerController, w, true, s)
    auto GWorld = GetFullWorld();
    if (GWorld) {
        UNetDriver *NetDriver = GWorld->NetDriver;
        if (NetDriver) {
            UNetConnection *ServerConnection = NetDriver->ServerConnection;
            if (ServerConnection) {
                localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
            }
        }
        if (localPlayerController) {
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
            GetAllActors(PlayerCharacter);
            for (auto actor = PlayerCharacter.begin(); actor != PlayerCharacter.end(); actor++) {
                auto Actor = *actor;
                if (Actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                    localPlayer = Actor;
                    break;
                }
            }
            float max = std::numeric_limits<float>::infinity();
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter2;
            GetAllActors(PlayerCharacter2);
            for (auto actor = PlayerCharacter2.begin(); actor != PlayerCharacter2.end();
                 actor++)
            {
                auto Player = *actor;
                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;
                if (Player->TeamID == localPlayer->TeamID)
                    continue;
                if (Player->bDead)
                    continue;
                if (Player->bHidden )
                    continue;
                if (!Player->Mesh)
                    continue;
                if (!Player->RootComponent)
                    continue;
                if (isAimKnocked) {
                    if (Player->Health == 0.0f)
                        continue;
                }
                if(isAimvisual){
                    if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }
                if (Igronebot) {
                    if (Player->bEnsure)
                        continue;
                }
                auto Root = GetBoneLocationByName(Player, "Root");
                auto Head = GetBoneLocationByName(Player, "Head");
                FVector2D RootSc, HeadSc;
                if (GameplayStatics->ProjectWorldToScreen(g_PlayerController, Root, false, &RootSc) && GameplayStatics->ProjectWorldToScreen(g_PlayerController, Head, false, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;
                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= screenWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= screenHeight)) {
                        FVector2D v2Middle = FVector2D((float) (screenWidth / 2), (float) (screenHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);
                        if(isInsideFOV((int)middlePoint.X, (int)middlePoint.Y)) {
                            float dist = FVector2D::Distance(v2Middle, v2Loc);
                            if (dist < max) {
                                max = dist;
                                result = Player;
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

auto GetTargetByPussy()
{
//    ASTExtraPlayerCharacter *result = 0;
    ASTExtraPlayerCharacter *result = 0;
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;

    UGameplayStatics *GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    FVector ViewPosY{0, 0, 0};
    if (localPlayerController)
    {
        ViewPosY = localPlayer->GetBonePos("Head", {});
        ViewPosY.Z += -15.0f;
    }

    if (localPlayerController)
    {
        std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
        GetAllActors(PlayerCharacter);
        for (auto actor = PlayerCharacter.begin(); actor != PlayerCharacter.end(); actor++) {
            auto Actor = *actor;
            if (Actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                localPlayer = Actor;
                break;
            }
        }
      
//        float lund = localPlayer->GetDistanceTo(Player) / 100.0f;
            float max = std::numeric_limits<float>::infinity();
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter2;
            GetAllActors(PlayerCharacter2);
            for (auto actor = PlayerCharacter2.begin(); actor != PlayerCharacter2.end();
                 actor++)
            {
//                float lund = localPlayer->GetDistanceTo(Player) / 100.0f;
                auto Player = *actor;
//                if (lund > 500.0f)
//                    continue;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                 if (isAimKnocked)
                {
                    if (Player->Health == 0.0f)
                        continue;
                }

                 if (isAimvisual)
                {
                    if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }

                 if (Igronebot)
                {
                    if (Player->bEnsure)
                        continue;
                }
                float dist = localPlayer->GetDistanceTo(Player);
                if (dist < max)
                {
                    max = dist;
                    result = Player;
                }
            }
        }
    

    return result;
}
std::wstring wstring_from_bytes(std::string const& str)
{
    size_t requiredSize = 0;
    std::wstring answer;
    wchar_t *pWTempString = NULL;
    /*
     * Call the conversion function without the output buffer to get the required size
     *  - Add one to leave room for the NULL terminator
     */
    requiredSize = mbstowcs(NULL, str.c_str(), 0) + 1;
    /* Allocate the output string (Add one to leave room for the NULL terminator) */
    pWTempString = (wchar_t *)malloc( requiredSize * sizeof( wchar_t ));
    if (pWTempString == NULL)
    {
        printf("Memory allocation failure.\n");
    }
    else
    {
        // Call the conversion function with the output buffer
        size_t size = mbstowcs( pWTempString, str.c_str(), requiredSize);
        if (size == (size_t) (-1))
        {
            printf("Couldn't convert string\n");
        }
        else
        {
            answer = pWTempString;
        }
    }
    if (pWTempString != NULL)
    {
        delete[] pWTempString;
    }
    return answer;
}
bool isEqual(FString s1, const char* check) {
    FString s2(check);
    return 0;
}
void *LoadFont() {
    while (!tslFont || !robotoTinyFont ) {
        tslFont = UObject::FindObject<UFont>(XorEnc("Font TSLFont.TSLFont"));
        robotoTinyFont = UObject::FindObject<UFont>(XorEnc("Font TSLFont.TSLFont"));//Font RobotoTiny.RobotoTiny
        itemfont = UObject::FindObject<UFont>("Font TSLFont.TSLFont");
        sleep(1);
    }
    return 0;
}
const char *GetLootName(APickUpListWrapperActor *Loot) {
    switch (Loot->BoxType) {
        case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_LootBox:
            return "LootBox";
        case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_TombBox:
            return "TomBOX";
        case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_AirDropBox:
            return "Airdrop";
        default:
            return "LootBox";
    }
}
bool isEqual(string s1, string s2) {
    return (s1 == s2);
}






FString getplayerflag(FString nation) {
    if (isEqual(nation, "G1") ) {
        return "🏁";
    }
    if (isEqual(nation, "IQ") ) {
        return "🇮🇶";
    }
    if (isEqual(nation, "SA") ) {
        return "🇸🇦";
    }
    if (isEqual(nation, "BH") ) {
        return "🇧🇭";
    }
    if (isEqual(nation, "SY") ) {
        return "🇸🇾";
    }
    if (isEqual(nation, "CA") ) {
        return "🇨🇦";
    }
    if (isEqual(nation, "PK") ) {
        return "🇵🇰";
    }
    if (isEqual(nation, "AF") ) {
        return "🇦🇫";
    }
    if (isEqual(nation, "AL") ) {
        return "🇦🇱";
    }
    if (isEqual(nation, "DZ") ) {
        return "🇩🇿";
    }
    if (isEqual(nation, "AS") ) {
        return "🇦🇸";
    }
    if (isEqual(nation, "AD") ) {
        return "🇦🇩";
    }
    if (isEqual(nation, "AO") ) {
        return "🇦🇴";
    }
    if (isEqual(nation, "AI") ) {
        return "🇦🇮";
    }
    return "";}
ASTExtraVehicleBase *GetTargetVehicle() {
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
    UGameplayStatics *GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    float max = std::numeric_limits < float >::infinity();
    ASTExtraVehicleBase *result = 0;
    std::vector<ASTExtraVehicleBase*> VehicleBase;
    GetAllActors(VehicleBase);
    for (auto actor = VehicleBase.begin(); actor != VehicleBase.end(); actor++) {
        auto Vehicle = *actor;
        if(!Vehicle)
            continue;
        if(!Vehicle->RootComponent)
            continue;
        if(!Vehicle->Mesh)
            continue;
        auto Driver = Vehicle->GetDriver();
        auto CurrentVeh = localPlayer->CurrentVehicle;
        if(Driver && !CurrentVeh) {
            if(Driver->TeamID == localPlayer->TeamID)
                continue;
            float dist = Vehicle->GetDistanceTo(localPlayer);
            if (dist < max) {
                max = dist;
                result = Vehicle;
            }
        }
    }
    return result;
    VehicleBase.clear();
}


FVector CHUTIA(ASTExtraVehicleBase * Vehicle)
{
    FVector DEFAULTSize, Shit;
    Vehicle->GetActorBounds(true, &Shit, &DEFAULTSize);
    switch (Vehicle->VehicleShapeType)
    {
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike:
            return FVector(33 , 107, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike_SideCart:
            return FVector(89, 114, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Dacia:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyDacia:
            return FVector(99, 209, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MiniBus:
            return FVector(102, 213, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyPickup:
            return FVector(128, 217, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Buggy:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyBuggy:
            return FVector(139, 177, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ02:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ03:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUAZ:
            return FVector(130, 226, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado01:
            return FVector(120, 260, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Rony:
            return FVector(104, 219, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Scooter:
            return FVector(32, 89, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowMobile:
            return FVector(40, 133, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_TukTukTuk:
            return FVector(84, 136, DEFAULTSize.Z); //done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowBike:
            return FVector(42, 137, DEFAULTSize.Z); // dome
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_GoldMirado:
            return FVector(120, 260, DEFAULTSize.Z); // done
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Amphibious:
            return FVector(160, 284, DEFAULTSize.Z);
            break;
        default:
            return DEFAULTSize;
            break;
    }
    return DEFAULTSize;
}

//wstring playerstatus(int GetEnemyState)
//{
//    switch (GetEnemyState)
//    {
//        case 0:
//            return L"AFK";
//            break;
//        case 1032:
//            return L"TILT HEAD";
//            break;
//        case 268435464:
//            return L"PLAY EMOTION";
//            break;
//        case 1552:
//            return L"AIMING";

//            break;
//        case 8388616:
//            return L"PARACHUTE";
//            break;
//        case 131072:
//            return L"KNOCKED";
//            break;
//        case 33554440:
//            return L"PLANE";
//            break;
//        case 8205:
//            return L"SHOT";
//            break;
//        case 32:
//            return L"SIT";
//            break;
//        case 4194303:
//            return L"SWIMMING";
//            break;
//        case 72:
//            return L"JUMPING";
//            break;
//        case 8388608:
//            return L"PARACHUTE";
//            break;
//        case 16392:
//            return L"THROW SOMETHING";
//            break;
//        case 262:
//            return L"RELOADING";
//            break;
//        case 1048584:
//            return L"RIDE";
//            break;
//        case 8200:
//            return L"FIST";
//            break;
//        case 2056:
//            return L"CUT GUN";
//            break;
//        case 4194302:
//            return L"SWIMMING";
//            break;
//        case 269:
//            return L"RELOADING";
//            break;
//        case 16777224:
//            return L"CLIMBING";
//            break;
//        case 10:
//            return L"RUN";
//            break;
//        case 263:
//            return L"RELOADING";
//            break;
//        case 65568 || 65544:
//            return L"FIGHT MEDICINE";
//            break;
//        case 4194308:
//            return L"SWIMMING";
//            break;
//        case 268:
//            return L"RELOADING";
//            break;
//        case 35:
//            return L"GET SIT";
//            break;
//        case 8388617:
//            return L"PARACHUTE";
//            break;
//        case 33:
//            return L"AIMING";
//            break;
//        case 75:
//            return L"JUMPING";
//            break;
//        case 8201:
//            return L"FIST";
//            break;
//        case 266:
//            return L"RELOADING";
//            break;
//        case 32776:
//            return L"KNOCKED";
//            break;
//        case 270:
//            return L"RELOADING";
//            break;
//        case 4194301:
//            return L"SWIMMING";
//            break;
//        case 1033:
//            return L"RUN";
//            break;
//        case 131073:
//            return L"KNOCKED";
//            break;
//        case 524296:
//            return L"DRIVING";
//            break;
//        case 1114120:
//            return L"FIGHT MEDICINE";
//            break;
//        case 265:
//            return L"RELOADING";
//            break;
//        case 9:
//            return L"RUN";
//            break;
//        case 262144:
//            return L"SMOKE";
//            break;
//        case 8203:
//            return L"FIST";
//            break;
//        case 8202:
//            return L"SHOT";
//            break;
//        case 262152:
//            return L"DEATH";
//            break;
//        case 17416:
//            return L"THROW SOMETHING";
//            break;
//        case 17:
//            return L"SIT";
//            break;
//        case 11:
//            return L"RUN";
//            break;
//        case 65545:
//            return L"FIGHT MEDICINE";
//            break;
//        case 33554432:
//            return L"PLANE";
//            break;
//        case 19:
//            return L"SQUAT";
//            break;
//        case 8208:
//            return L"SHOT";
//            break;
//        case 520:
//            return L"AIMING";
//            break;
//        case 8206:
//            return L"SHOT";
//            break;
//        case 8:
//            return L"STAND";
//            break;
//        case 16:
//            return L"SIT";
//            break;
//        case 13180:
//            return L"KNOCKED";
//            break;
//        case 4194310:
//            return L"SWIMMING";
//            break;
//        case 16393:
//            return L"THROW SOMETHING";
//            break;
//        case 4194309:
//            return L"SWIMMING";
//            break;
//        case 264:
//            return L"RELOADING";
//            break;
//        case 4194305:
//            return L"SWIMMING";
//            break;
//        case 8207:
//            return L"SHOT";
//            break;
//        case 4194307:
//            return L"SWIMMING";
//            break;
//            return L"";
//    }
//
//}
wstring GetBoxItems(long code)
{
    if (code == 101008)
        return L"M762";
    else if (code == 101003)
        return L"SCAR-L";
    else if (code == 101004)
        return L"M416";
    else if (code == 101002)
        return L"M16A-4";
    else if (code == 103003)
        return L"AWM";
    else if (code == 103010)
        return L"QBU";
    else if (code == 103009)
        return L"SLR";
    else if (code == 103004)
        return L"SKS";
    else if (code == 103006)
        return L"Mini14";
    else if (code == 103002)
        return L"M24";
    else if (code == 103001)
        return L"Kar98k";
    else if (code == 103005)
        return L"VSS";
    else if (code == 103008)
        return L"Win94";
    else if (code == 101009)
        return L"Mk47";
    else if (code == 101010)
        return L"G36C";
    else if (code == 101007)
        return L"QBZ";
    else if (code == 101001)
        return L"AKM";
    else if (code == 101005)
        return L"Groza";
    else if (code == 101006)
        return L"AUG_A3";
    else if (code == 104003)
        return L"S12K";
    else if (code == 104004)
        return L"DBS";
    else if (code == 104001)
        return L"S686";
    else if (code == 104002)
        return L"S1897";
    else if (code == 106006)
        return L"SawedOff";
    else if (code == 102005)
        return L"PP19 Bizon";
    else if (code == 102004)
        return L"TommyGun";
    else if (code == 102007)
        return L"MP5K";
    else if (code == 102002)
        return L"UMP9";
    else if (code == 102003)
        return L"Vector";
    else if (code == 102001)
        return L"Uzi";
    else if (code == 106003)
        return L"R1895";
    else if (code == 106008)
        return L"Vz61";
    else if (code == 106001)
        return L"P92";
    else if (code == 106004)
        return L"P18C";
    else if (code == 106005)
        return L"R45";
    else if (code == 106002)
        return L"P1911";
    else if (code == 106010)
        return L"DesertEagle";
    else if (code == 108003)
        return L"Sickle";
    else if (code == 108001)
        return L"Machete";
    else if (code == 107001)
        return L"Cross Bow";
    else if (code == 108004)
        return L"Pan";
    else if (code == 103007)
        return L"Mk14";
    else if (code == 302001)
        return L"7.62";
    else if (code == 305001)
        return L"45ACP";
    else if (code == 303001)
        return L"5.56";
    else if (code == 301001)
        return L"9mm";
    else if (code == 306001)
        return L"300Magnum";
    else if (code == 304001)
        return L"12Guage";
    else if (code == 307001)
        return L"Arrows";
    else if (code == 201010)
        return L"Rifle-FlashHider";
    else if (code == 201009)
        return L"Rifle-Compensator";
    else if (code == 201004)
        return L"Mid Compensator";
    else if (code == 205002)
        return L"Tactical_Rifle";
    else if (code == 201012)
        return L"Duckbill";
    else if (code == 201005)
        return L"Sniper_FlashHider";
    else if (code == 201006)
        return L"Mid_Suppressor";
    else if (code == 205003)
        return L"Chekpad Sniper";
    else if (code == 201001)
        return L"Choke";
    else if (code == 205001)
        return L"UZI_Pickup";
    else if (code == 201003)
        return L"Sniper-Compensator";
    else if (code == 201007)
        return L"Sniper-Suppressor";
    else if (code == 201011)
        return L"Suppressor-AR";
    else if (code == 204009)
        return L"Sniper-Extended";
    else if (code == 204004)
        return L"Mid_E";
    else if (code == 204005)
        return L"Mid_Q";
    else if (code == 204007)
        return L"Sniper_Mag";
    else if (code == 204008)
        return L"Sniper_QuickMag";
    else if (code == 204012)
        return L"Rifle_Mag";
    else if (code == 204013)
        return L"Exteded AR";
    else if (code == 204011)
        return L"Mag-AR";
    else if (code == 204006)
        return L"Mid_EQ";
    else if (code == 205004)
        return L"Crossbow";
    else if (code == 204014)
        return L"ZDD_Sniper";
    else if (code == 203005)
        return L"8x";
    else if (code == 203003)
        return L"2x";
    else if (code == 203001)
        return L"Lazer";
    else if (code == 203014)
        return L"3X";
    else if (code == 203002)
        return L"Holo";
    else if (code == 203015)
        return L"6x";
    else if (code == 203004)
        return L"4x";
    else if (code == 105002)
        return L"DP28";
    else if (code == 107001)
        return L"CrossBow";
    else if (code == 105001)
        return L"M249";
    else if (code == 501006)
        return L"Bag Lv.3";
    else if (code == 501004)
        return L"Bag Lv.1";
    else if (code == 501005)
        return L"Bag Lv.2";
    else if (code == 503002)
        return L"Armour Lv.2";
    else if (code == 503001)
        return L"Armour Lv.1";
    else if (code == 503003)
        return L"Armour Lv.3";
    else if (code == 502002)
        return L"Helmet Lv.2";
    else if (code == 502001)
        return L"Helmet Lv.1";
    else if (code == 502003)
        return L"Helmet Lv.3";
    else if (code == 602004)
        return L"Grenade";
    else if (code == 602002)
        return L"Smoke";
    else if (code == 602003)
        return L"Molotof";
    else if (code == 602005)
        return L"Apple";
    else if (code == 601003)
        return L"Painkiller";
    else if (code == 601002)
        return L"Adrenaline";
    else if (code == 601001)
        return L"Energy Drink";
    else if (code == 601005)
        return L"FirstaidKit";
    else if (code == 601004)
        return L"Bandage";
    else if (code == 202006)
        return L"ThumbGrip";
    else if (code == 202007)
        return L"Lasersight";
    else if (code == 202001)
        return L"Angled";
    else if (code == 202004)
        return L"LightGrip";
    else if (code == 106007)
        return L"Flaregun";
    else if (code == 3000312)
        return L"GameCoin";
    else if (code == 601006)
        return L"Medkit";
    else if (code == 308001)
        return L"Flaregun";
    else if (code == 501003)
        return L"Bag Lv.3";
    else if (code == 501002)
        return L"Bag Lv.2";
    else if (code == 501001)
        return L"Bag Lv.1";
    else if (code == 201002)
        return L"Mid_Compensator";
    else if (code == 502005)
        return L"Helmet Lv.2";
    else if (code == 403989)
        return L"Arctic-Suit";
    else if (code == 403045)
        return L"Woodland-Suit";
    else if (code == 403187)
        return L"Desert-Suit";
    else if (code == 403188)
        return L"Desert-Suit";
    else
        return L"";
    
}
void (*orig_shoot_event)(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, void *unk1, int unk2) = 0;
void shoot_event(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, ASTExtraShootWeapon *weapon, int unk1) {
    UKismetMathLibrary* UMC = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();
    if (IsSilentAIM) {
        ASTExtraPlayerCharacter *Target = GetTargetForAimBotByFOV();
        if (Target) {
            bool triggerOk = false;
            if (IsShoot) {
                triggerOk = g_LocalPlayer->bIsWeaponFiring;
            } else if (IsSCope) {
                triggerOk = g_LocalPlayer->bIsGunADS;
            } else if (IsBothaim) {
                triggerOk = g_LocalPlayer->bIsWeaponFiring && g_LocalPlayer->bIsGunADS;
            } else if (IsAny) {
                triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
            }else triggerOk = true;
            if (triggerOk) {
                FVector targetAimPos = Target->GetBonePos("Head", {});
                targetAimPos.Z -= aimpos();
                UShootWeaponEntity *ShootWeaponEntityComponent = thiz->ShootWeaponEntityComponent;
                if (ShootWeaponEntityComponent) {
                    ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                    if (CurrentVehicle) {
                        FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
                        float dist = g_LocalPlayer->GetDistanceTo(Target);
                        auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
                        targetAimPos = UMC->Add_VectorVector(targetAimPos, UMC->Multiply_VectorFloat(LinearVelocity, timeToTravel));
                    } else {
                        FVector Velocity = Target->GetVelocity();
                        float dist = g_LocalPlayer->GetDistanceTo(Target);
                        auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
                        targetAimPos =UMC->Add_VectorVector(targetAimPos, UMC->Multiply_VectorFloat(Velocity, timeToTravel));
                    }
                    FVector fDir = UMC->Subtract_VectorVector(targetAimPos, g_PlayerController->PlayerCameraManager->CameraCache.POV.Location);
                    rot = UMC->Conv_VectorToRotator(fDir);
                }
            }
        }
    }
    return orig_shoot_event(thiz, start, rot, weapon, unk1);
}

void (*orig_BroadcastFatalDamage)(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter, void *pArgs);
void hk_BroadcastFatalDamage(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter, void *pArgs)
{
    if (g_LocalPlayer->PlayerKey == FatalDamageParameter->CauserKey && !g_PlayerController->STExtraBaseCharacter->CurrentVehicle)

    {

        if(initkillmsgopen){
            
            if (thanhgiap1){
                FatalDamageParameter->CauserClothAvatarID = 1405909; //blood raven x suit
            }
            if (thanhgiap2){
                FatalDamageParameter->CauserClothAvatarID = 1405628; //Golden Pharaoh X-Suit
        }
        if (thanhgiap3){
            FatalDamageParameter->CauserClothAvatarID = 1406152; //Avalanche
    }
    if (thanhgiap4) {
        FatalDamageParameter->CauserClothAvatarID = 1406475; //Irresidence
}
if (thanhgiap5){
                FatalDamageParameter->CauserClothAvatarID = 1405983; //Poseidon
}
if (thanhgiap6){
                FatalDamageParameter->CauserClothAvatarID = 1406638; //Arcane Jester X-suit
}
if (thanhgiap7){
                FatalDamageParameter->CauserClothAvatarID = 1406311; //Silvanus X-Sui
}
if (thanhgiap8){
                FatalDamageParameter->CauserClothAvatarID = 1406971; //Silvanus X-Sui
}
            
//if (thanhgiap9) {
//                FatalDamageParameter->CauserClothAvatarID = 1407102; //Fiore X-Suit
//}
            
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AKM")){
                if (akm1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001042; //Sculpture - AKM
                }
                if (akm2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001063; //The Seven Seas - AKM
                }
                if (akm3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001068; //Roaring Tiger - AKM
                }
                if (akm4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001089; //Glacier - AKM
                }
                if (akm5){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001101; //Desert Fossil - AKM
                }
                if (akm6){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001116; //Jack-o'-lantern - AKM
                }
                if (akm7){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001128; //Ghillie Dragon - AKM
                }
                if (akm8){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001143; //Gold Pirate - AKM
                }
                if (akm9){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001174;
                }
                if (akm10){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001213;
                }
                if (akm11){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001023;
                }
                if (akm12){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101001242;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M416")){
                if (skinm41) {


FatalDamageParameter->CauserWeaponAvatarID = 1101004044; //Glacier - M416
                    if(checkeffectm4){
                        effectm4 =true;
                    }
                }
                if (skinm42) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004062; //The Fool - M416
                }
                if (skinm43) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004086; //Lizard Roar - M416
                }
                if (skinm44) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004078; //Wanderer - M416
                }
                if (skinm45) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004098; //Call of the Wild - M416
                }
                if (skinm46) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004163; //Imperial Splendor - M416
                }
                if (skinm47) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004201; //Silver Guru - M416
                    if(checkeffectm4){
                        effectm4 =true;
                    }
                }
                if (skinm48) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101004138; //TechnoCore - M416
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SCAR-L")){
                if (scarl1) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003057; //Water Blaster - SCAR-L
                }
                if (scarl2) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003070; //Enchanted Pumpkin - SCAR-L
                }
                if (scarl3) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003079; //Operation Tomorrow - SCAR-L
                }
                if (scarl4) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003099; //Drop the Bass - SCAR-L
                }
                if (scarl5) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003119;
                }
                if (scarl6) {
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003146;
                    
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M762")){
                if (m7621){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101003057; //8-bit Unicorn - M762
                }
                if (m7622){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008116; //Messi Football Icon M762
                }
                if (m7623){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008070; //GACKT MOONSAGA-M762
                }
                if (m7624){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008036; //Lotus Fury - M762
                }
                if (m7625){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008051; //Concerto of Love - M762
                }
                if (m7626){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008104; //StarCore-M762
                }
                if (m7627){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008081; //Stray Rebellion - M762
                }
                if (m7628){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101008126; //Stray Rebellion - M762
                }
            }
            
            
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "GROZA")){
                if (gloza1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101005019;
                }
                if (gloza2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101005052;
                }
                if (gloza3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101005025;
                }
                
                if (gloza4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101005038;
                }
            }
            
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UZI")){
                
                if (uzi1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102001024; //Savagery - UZI
                }
                if (uzi2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102001036; //Ethereal Emblem - UZI
                }
                if (uzi3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102001058; //Romantic Moments - UZI
                }
                if (uzi4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102001069; //Shimmer Power - UZI
                }
                
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UMP45")){
                
                if (ump1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002043;
                }
                if (ump2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002053;
                }
                if (ump3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002061;
                }
                if (ump4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002070;
                }
                if (ump5){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002030;
                }
                if (ump6){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002090;
                }
                if (ump7){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102002136;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vector")){
                
                if (vectorr1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102003020;
                }
                if (vectorr2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102003031;
                }
                if (vectorr3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102003039;}
                if (vectorr4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102003072;}
                if (vectorr5){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102003060;
                }
                
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Thompson")){
                
                if(thomson1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102004018; //candy cane
                }
                
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "PP-19 Bizon")){
                
                if (bizon1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102005007;
                }
                if (bizon2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1102005020;
                }
                
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Kar98K")){
                
                if (k981){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103001060;
                }
                if (k982){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103001079;
                }
                if (k983){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103001085;
                }
                
                if (k984){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103001101;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M24")){
                
                if (m241){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103002018;
                }
                if (m242){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103002030;
                }
                if (m243){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103002049;
                }
                if (m244)
                    FatalDamageParameter->CauserWeaponAvatarID = 1103002047;
            }
            if (m245){
                FatalDamageParameter->CauserWeaponAvatarID = 1103002059;
            }
            if (m246){
                FatalDamageParameter->CauserWeaponAvatarID = 1103002087;
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AWM")){
                
                if (awm1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103003022;
                }
                if (awm2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103003030;
                }
                if (awm3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103003042;
                }
                if (awm4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103003062;
                }
                
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "DP28")){
                
                if (dp281){
                    FatalDamageParameter->CauserWeaponAvatarID = 1105002018;
                }
                if (dp282){
                    FatalDamageParameter->CauserWeaponAvatarID = 1105002035;
            }
            
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M16A4")){
            
            if (m161){
                FatalDamageParameter->CauserWeaponAvatarID = 1101002029;
            }
            if (m162){
                FatalDamageParameter->CauserWeaponAvatarID = 1101002056;
            }
            if (m163){
                FatalDamageParameter->CauserWeaponAvatarID = 1101002068;
            }
            if (m164){
                FatalDamageParameter->CauserWeaponAvatarID = 1101002081;
            }
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "QBZ")){
            if(qbz1){
                FatalDamageParameter->CauserWeaponAvatarID = 1101007025;
            }
            if(qbz2){
                FatalDamageParameter->CauserWeaponAvatarID = 1101007036;
            }
            if(qbz3){
                FatalDamageParameter->CauserWeaponAvatarID = 1101007046;
            }
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M249")){
            if (m2491){
                FatalDamageParameter->CauserWeaponAvatarID = 1105001034;
            }
            if (m2492){
                FatalDamageParameter->CauserWeaponAvatarID = 1105001020;
            }
            if (m2493){
                FatalDamageParameter->CauserWeaponAvatarID = 1105001048;
            }
            
            if (m2494){
                FatalDamageParameter->CauserWeaponAvatarID = 1105001034;
            }
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Mini 14")){
            if (mini1){
                FatalDamageParameter->CauserWeaponAvatarID = 1101007025;
            }
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SLR")){
            if (slr1){
                FatalDamageParameter->CauserWeaponAvatarID = 1103009022;
            }
        }
        else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SKS")){
            if (sks1){
                FatalDamageParameter->CauserWeaponAvatarID = 1103004037;
            }
            if (sks2){
                FatalDamageParameter->CauserWeaponAvatarID = 1103004046;
            }
            if (sks3){
                FatalDamageParameter->CauserWeaponAvatarID = 1103004058;
            
        }
    }
    else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Pan")){
        
        if (pan1){
            FatalDamageParameter->CauserWeaponAvatarID = 1108004125;
    }
        if (pan2){
        FatalDamageParameter->CauserWeaponAvatarID = 1108004145;
}
        if (pan3){
                    FatalDamageParameter->CauserWeaponAvatarID = 1108004160;
}
        if (pan4){
                    FatalDamageParameter->CauserWeaponAvatarID = 1108004337;
}
        if (pan5){
                    FatalDamageParameter->CauserWeaponAvatarID = 1108004283;
}
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vss")){
                if (vss1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103005024;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Mk14")){
                if (mk141){
                    FatalDamageParameter->CauserWeaponAvatarID = 1103007020;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S1897")){
                if (s18971){
                    FatalDamageParameter->CauserWeaponAvatarID = 1104002022;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AUG")){
                if (aug1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101006033;
                }

                if (aug2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101006060;
                }
            }

            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S12K")){
                if (sk12k1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1104003026;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "ACE32")){
                if (ace1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101102007;
                }
                if (ace2){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101102017;
                }
            }
            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "HONEY")){
                if (honey1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1101012009;
                }

            }

            else if(strstr(g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "DBS")){
                if (dbs1){
                    FatalDamageParameter->CauserWeaponAvatarID = 1104004023;
                }

            }
            
        }
        
    }
  return orig_BroadcastFatalDamage(thiz, FatalDamageParameter, pArgs);
}

void RenderESP( AHUD *pHUD,int ScreenWidth, int ScreenHeight) {
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
    USTExtraGameInstance *playerChar = 0;
    screenWidth = ScreenWidth;
    screenHeight = ScreenHeight;
    ASTExtraBaseCharacter *STExtraBaseCharacter = 0;
    ASTExtraCharacter *Charac = 0;
    FVerifySwitch *VerifySwitch = 0;
    FDistanceContinueHitCheck *DistanceContinueHitCheck = 0;
    FAntiCheatDetailData *AntiCheatDetailData = 0;
    UWeaponAntiCheatComp *WeaponAntiCheatComp = 0;
    AGameNetworkManager *GameNetworkManager = 0;
    UCheatManager *CheatManager = 0;
    UPlayerAntiCheatManager *PlayerAntiCheatManager = 0;
    USTExtraFloatingVehicleMovementComponent *STExtraFloatingVehicleMovementComponent = 0;
    USTExtraHelicopterVehicleMovementComponent *Helicopter = 0;
    ASTExtraShootWeapon *STExtraShootWeapon = 0;
    USceneComponent *SceneComponent = 0;
    UAntiCheatUtils *AntiCheatUtils = 0;
    UGMCheatManager *GMCheatManager = 0;
    UVACTask_AccelerationControl *VACTask_AccelerationControl = 0;
    UWeaponAntiCheatComp *WeaponCheat = 0;
    UVACTask_FlyingVehicle *VACTask_FlyingVehicle = 0;
    UVACTask_FlyingVehicleVelocity *VACTask_FlyingVehicleVelocity = 0;
    UVACTask_FlyingVehicleVelocityChange *VACTask_FlyingVehicleVelocityChange = 0;
    UVACTask_FlyingVehicleZ *VACTask_FlyingVehicleZ = 0;
    UVACTask_SuperSpeed *VACTask_SuperSpeed = 0;
    UVACTask_SuperSpeedAllDir *VACTask_SuperSpeedAllDir = 0;
    UActorComponent *ActorComponent = 0;
    UVACTask_ClientAbsSpeed *VACTask_ClientAbsSpeed = 0;
    FMoveCheatAntiStrategy *MoveCheatAntiStrategy = 0;
    UAssetUserData *AssetUserData = 0;
    USTBuildSystemComponent *STBuildSystemComponent = 0;
    UDefaultAntiCheatComponent *DefaultAntiCheatComponent = 0;
    //FCharacterZMoveDistanceCheck *CharacterZMoveDistanceCheck = 0;
    FClientTimeSpeedCheck *ClientTimeSpeedCheck = 0;
    FRealtimeMoveSpeedCheck *RealtimeMoveSpeedCheck = 0;
    FShovelAntiCheat *ShovelAntiCheat = 0;
    FVector LocalPos{0, 0, 0}, ViewPos{0, 0, 0};
 
    //ASurviveHUD * AASurviveHUD = 0; //for draw FText
    //revival var
    if (localPlayer) {
        LocalPos = GetBoneLocationByName(localPlayer, "Root");
        ViewPos = GetBoneLocationByName(localPlayer, "Head");
        ViewPos.Z += 15.f;
    }
    UCanvas *Canvas = pHUD->Canvas;
    if (Canvas) {
        static bool loadFont = false;
        if (!loadFont) {
            LoadFont();
            loadFont = true;
        }
        if (!tslFont || !robotoTinyFont )
            return;
        {

            
            tslFont->LegacyFontSize = 40;
            
            wstring dd = L"GwH";
            DrawOutlinedText(pHUD, FString(dd), {(float) screenWidth / 2, 100}, COLOR_RED, COLOR_BLACK, true);
            tslFont->LegacyFontSize = 40;
        }
        UGameplayStatics* gGameplayStatics = (UGameplayStatics*)UGameplayStatics::StaticClass();
#define W2S(w, s) gGameplayStatics->ProjectWorldToScreen(localPlayerController, w, true, s)
        UKismetMathLibrary* UMC = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();
        UKismetSystemLibrary*USl = (UKismetSystemLibrary*)UKismetSystemLibrary::StaticClass();
        auto GWorld = GetFullWorld();
        if (GWorld) {
            UNetDriver *NetDriver = GWorld->NetDriver;
            if (NetDriver) {
                UNetConnection *ServerConnection = NetDriver->ServerConnection;
                if (ServerConnection) {
                    localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
                }
            }
            

            if (localPlayerController) {
                std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
                GetAllActors(PlayerCharacter);
                int IntCount = 0;
                for (auto actor = PlayerCharacter.begin(); actor != PlayerCharacter.end(); actor++) {
                    auto Actor = *actor;
                    if (Actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                        localPlayer = Actor;
                        break;
                    }
                }
                localPlayerController->AntiCheatManagerComp = 0;
                auto CheatManger = localPlayerController->CheatManager;
                if(CheatManger){
                    CheatManger->FlushLog();
                }
                {
                    if (localPlayer) {
                        if (localPlayer->PartHitComponent) {
                            auto ConfigCollisionDistSqAngles = localPlayer->PartHitComponent->ConfigCollisionDistSqAngles;
                            for (int j = 0; j < ConfigCollisionDistSqAngles.Num(); j++) {
                                ConfigCollisionDistSqAngles[j].Angle = 180.f;
                            }
                            localPlayer->PartHitComponent->ConfigCollisionDistSqAngles = ConfigCollisionDistSqAngles;
                        }
                        
                        
                        static bool bShooting = false;
                      
                        if (IsbulletTrack) {
                            ASTExtraPlayerCharacter *Target = GetTargetForAimBotByFOV();
                            if (Target) {
                                if (g_LocalPlayer->bIsWeaponFiring)
                                {
                                    FVector targetAimPos = Target->GetBonePos("Head", {});
                                    targetAimPos.Z -= 15.0f;
                                    auto WeaponManagerComponent = g_LocalPlayer->WeaponManagerComponent;
                                    if (WeaponManagerComponent)
                                    {
                                        auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                                        if ((int)propSlot.GetValue() >= 1 && (int)propSlot.GetValue() <= 3)
                                        {
                                            auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
                                            if (CurrentWeaponReplicated)
                                            {
                                                auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                                if (ShootWeaponComponent)
                                                {
                                                    UShootWeaponEntity *ShootWeaponEntityComponent = ShootWeaponComponent->ShootWeaponEntityComponent;
                                                    if (ShootWeaponEntityComponent)
                                                    {
                                                        ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                                                        if (CurrentVehicle)
                                                        {
                                                            FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
                                                            float dist = g_LocalPlayer->GetDistanceTo(Target);
                                                            auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;
                                                            targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel));
                                                        }
                                                        else
                                                        {
                                                            FVector Velocity = Target->GetVelocity();
                                                            float dist = g_LocalPlayer->GetDistanceTo(Target);
                                                            auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;
                                                            targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity, timeToTravel)); }
                                                        
                                                        if (g_PlayerController) {
                                                            auto PlayerCameraManage = g_PlayerController->PlayerCameraManager;
                                                            if (PlayerCameraManage) {
                                                                FVector currViewAngle = PlayerCameraManage->CameraCache.POV.Location;
                                                                FRotator aimRotation = ToRotator(currViewAngle, targetAimPos);
                                                                g_PlayerController->PlayerCameraManager->CameraCache.POV.Rotation = aimRotation;
                                                                g_PlayerController->PlayerCameraManager->CameraCache.POV.Location = targetAimPos; }}
                                                    }
                                                }}}}}}}
                        if(initkillmsgcheck){
                            if (initkillmsgopen) {
                                if (!cdmokkill)
                                {
                                    
                                    bool cdmokkill = false;                                    auto VTable = *(void ***)g_PlayerController;
                                    
                                    if (VTable && (VTable[1005] != hk_BroadcastFatalDamage)) {
                                        orig_BroadcastFatalDamage = decltype(orig_BroadcastFatalDamage)(VTable[1005]);
                                        
                                        VTable[1005] = (void *)hk_BroadcastFatalDamage;
                                        
                                        cdmokkill = true;
                                        
                                    }
                                    
                                }
                            }
                        }

                        if(carskin){
                            if (g_LocalPlayer->CurrentVehicle) {
                                if (g_LocalPlayer->CurrentVehicle->VehicleAvatar)
                                {
                                    //                                                if (xegb1) {
                                    switch (value) {
                                        case 0:
                                           
                                            
                                            if (Active::lastCarID2 != 1961001)
                                            {
                                                Active::lastCarID2 = 1961001;
                                                Active::newCarID4 = 1961001; //Dacia
                                                g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                                
                                            }
                                    
                                    break;
                                case 1:
                                    
                   
                                        
                                        if (Active::lastCarID2 != 1961042)
                                        {
                                            Active::lastCarID2 = 1961042;
                                            Active::newCarID4 = 1961042; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                    
                                break;
                            case 2:
                                
          
                                        
                                        if (Active::lastCarID2 != 1961043)
                                        {
                                            Active::lastCarID2 = 1961043;
                                            Active::newCarID4 = 1961043; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                    break;
                                case 3:
                                    
                                    
                                    
                              
                                        // Bugati La Voiture Noire
                                        
                                        if (Active::lastCarID2 != 1961044)
                                        {
                                            Active::lastCarID2 = 1961044;
                                            Active::newCarID4 = 1961044; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                    
                                            break;
                                        case 4:
                                            
                                            
                                        // Bugati La Voiture Noire (Alloy)
                                        
                                        if (Active::lastCarID2 != 1961045)
                                        {
                                            Active::lastCarID2 = 1961045;
                                            Active::newCarID4 = 1961045; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 5:
                                            
                                            
                                        // Bugati La Voiture Noire (Warrior)
                                        
                                        if (Active::lastCarID2 != 1961046)
                                        {
                                            Active::lastCarID2 = 1961046;
                                            Active::newCarID4 = 1961046; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 6:
                                            
                                            
                                        // Bugati La Voiture Noire (Nebula)
                                        
                                        if (Active::lastCarID2 != 1961047)
                                        {
                                            Active::lastCarID2 = 1961047;
                                            Active::newCarID4 = 1961047; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 7:
                                            
                                            
                                        // McLaren 570S (Zenith Black)
                                        
                                        if (Active::lastCarID2 != 1961007)
                                        {
                                            Active::lastCarID2 = 1961007;
                                            Active::newCarID4 = 1961007; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 8:
                                            
                                            
                                        // McLaren 570S (Lunar White)
                                        
                                        if (Active::lastCarID2 != 1961010)
                                        {
                                            Active::lastCarID2 = 1961010;
                                            Active::newCarID4 = 1961010; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 9:
                                            
                                            
                                        //McLaren 570S (Raspberry)
                                        
                                        if (Active::lastCarID2 != 1961012)
                                        {
                                            Active::lastCarID2 = 1961012;
                                            Active::newCarID4 = 1961012; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 10:
                                            
                                            
                                        // McLaren 570S (Glory White)
                                        
                                        if (Active::lastCarID2 != 1961013)
                                        {
                                            Active::lastCarID2 = 1961013;
                                            Active::newCarID4 = 1961013; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 11:
                                            
                                            
                                        // McLaren 570S (Royal Black)
                                        
                                        if (Active::lastCarID2 != 1961014)
                                        {
                                            Active::lastCarID2 = 1961014;
                                            Active::newCarID4 = 1961014; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 12:
                                            
                                            
                                        // McLaren 570S (Pearlescent)
                                        
                                        if (Active::lastCarID2 != 1961015)
                                        {
                                            Active::lastCarID2 = 1961015;
                                            Active::newCarID4 = 1961015; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 13:
                                            
                                            
                                        // Koenigsegg Jesko (Silver Gray)
                                        
                                        if (Active::lastCarID2 != 1961016)
                                        {
                                            Active::lastCarID2 = 1961016;
                                            Active::newCarID4 = 1961016; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 14:
                                            
                                            
                                        // Koenigsegg Jesko (Rainbow)
                                        
                                        if (Active::lastCarID2 != 1961017)
                                        {
                                            Active::lastCarID2 = 1961017;
                                            Active::newCarID4 = 1961017; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 15:
                                 
                                        // Koenigsegg Jesko (Dawn)
                                        
                                        if (Active::lastCarID2 != 1961018)
                                        {
                                            Active::lastCarID2 = 1961018;
                                            Active::newCarID4 = 1961018; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 16:
                                            
                                            
                                        // Lamborghini Aventador SVJ GREEN
                                        
                                        if (Active::lastCarID2 != 1961020)
                                        {
                                            Active::lastCarID2 = 1961020;
                                            Active::newCarID4 = 1961020; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 17:
                                            
                                            
                                        // Lamborghini Centenario Galassia
                                        
                                        if (Active::lastCarID2 != 1961021)
                                        {
                                            Active::lastCarID2 = 1961021;
                                            Active::newCarID4 = 1961021; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 18:
                                            
                                            
                                        // Lambarghini Centenario Carbon Fiber
                                        
                                        if (Active::lastCarID2 != 1961025)
                                        {
                                            Active::lastCarID2 = 1961025;
                                            Active::newCarID4 = 1961025; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 19:
                                            
                                            
                                        // Koenigsegg One:1 Gilt
                                        
                                        if (Active::lastCarID2 != 1961029)
                                        {
                                            Active::lastCarID2 = 1961029;
                                            Active::newCarID4 = 1961029; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 20:
                                            
                                            
                                        // Maserati MC20 Bianco Audace
                                        
                                        if (Active::lastCarID2 != 1961038)
                                        {
                                            Active::lastCarID2 = 1961038;
                                            Active::newCarID4 = 1961038; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 21:
                                            
                                            
                                        // Maserati MC20 Rosso Vincente
                                        
                                        if (Active::lastCarID2 != 1961039)
                                        {
                                            Active::lastCarID2 = 1961039;
                                            Active::newCarID4 = 1961039; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 22:
                                            
                                            
                                        // Maserati MC20 Sogni
                                        
                                        if (Active::lastCarID2 != 1961040)
                                        {
                                            Active::lastCarID2 = 1961040;
                                            Active::newCarID4 = 1961040; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 23:
                                            
                                            
                                        // Pagani Zonda R (Tricolore Carbon)
                                        
                                        if (Active::lastCarID2 != 1961051)
                                        {
                                            Active::lastCarID2 = 1961051;
                                            Active::newCarID4 = 1961051; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 24:
                                            
                                            
                                        // Pagani Zonda R (Bianco Benny)
                                        
                                        if (Active::lastCarID2 != 1961052)
                                        {
                                            Active::lastCarID2 = 1961052;
                                            Active::newCarID4 = 1961052; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 25:
                                            
                                            
                                        // Pagani Zonda R (Melodic Midnight)
                                        
                                        if (Active::lastCarID2 != 1961053)
                                        {
                                            Active::lastCarID2 = 1961053;
                                            Active::newCarID4 = 1961053; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 26:
                                            
                                            
                                        // Pagani lmola (Grigio Montecarlo)
                                        
                                        if (Active::lastCarID2 != 1961054)
                                        {
                                            Active::lastCarID2 = 1961054;
                                            Active::newCarID4 = 1961054; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 27:
                                            
                                            
                                        // Pagani lmola (Crystal Clear Carbon)
                                        
                                        if (Active::lastCarID2 != 1961055)
                                        {
                                            Active::lastCarID2 = 1961055;
                                            Active::newCarID4 = 1961055; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 28:
                                            
                                            
                                        // Pagani lmola (Nebula Dream)
                                        
                                        if (Active::lastCarID2 != 1961056)
                                        {
                                            Active::lastCarID2 = 1961056;
                                            Active::newCarID4 = 1961056; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 29:
                                            
                                            
                                        // Pagani lmola (Arctic Aegis)
                                        
                                        if (Active::lastCarID2 != 1961057)
                                        {
                                            Active::lastCarID2 = 1961057;
                                            Active::newCarID4 = 1961057; //Dacia
                                            g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                            
                                        }
                                            break;
                                        case 30:
                                            
                                            
                                        // Pagani lmola (Arctic Aegis)
                                        
                                            if (Active::lastCarID2 != 1961041)
                                            {
                                                Active::lastCarID2 = 1961041;
                                                Active::newCarID4 = 1961041; //Dacia
                                                g_LocalPlayer->CurrentVehicle->VehicleAvatar->ChangeItemAvatar(Active::newCarID4, true);
                                                
                                            }
                                            break;
                                            
                                    }
                                }
                            }}
                                
                                
                        if (Box) {

auto objs = UObject::GetGlobalObjects();
for (int i = 0; i < objs.Num(); i++) {
auto Object = objs.GetByIndex(i);
if (isObjectInvalid(Object))
continue;

if (Object->IsA(UDeadBoxAvatarComponent::StaticClass())) {
auto DeadBox = (UDeadBoxAvatarComponent *)Object;
    DeadBox->ChangeItemAvatar(1101001213, true);
}
}
}
        
                                
                        if(ESPGAME){
                            float Distance =0;
                            int totalEnemies = 0, totalBots = 0;
                            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter2;
                            GetAllActors(PlayerCharacter2);
                            for (auto actor = PlayerCharacter2.begin(); actor != PlayerCharacter2.end(); actor++) {
                                auto Player = *actor;
                                if (Player->PlayerKey == localPlayer->PlayerKey)
                                    continue;
                                if (Player->TeamID == localPlayer->TeamID)
                                    continue;
                                if (Player->bDead)
                                    continue;
                                if (Player->bHidden )
                                    continue;
                                if (!Player->Mesh)
                                    continue;
                                if (!Player->RootComponent)
                                    continue;
                                //if (Config["ESP::NO_BOT"]) {
                                //if (Player->bEnsure)
                                //  continue;
                                //}
                                //                                    if (Player->bIsAI)
                                //                                        totalBots++;
                                //                                    else totalEnemies++;
                                
                                if (Player->bEnsure)
                                    totalBots++;
                                else totalEnemies++;
                                FVector   Head = GetBoneLocationByName(Player, "Head");
                                Head.Z += 12.5f;
                                FVector Root = GetBoneLocationByName(Player, "Root");
                                headp = GetBoneLocationByName(Player, "Head");
                                Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                                //colors
                                bool IsVisible = localPlayerController->LineOfSightTo(Player, {0,0,0}, true);
                                if(IsVisible) {
                                    if(Player->bEnsure){
                                        //white color
                                        visCol.R = 1.f;
                                        visCol.G = 1.f;
                                        visCol.B = 1.f;
                                        visCol.A = 1.f;
                                    }else if(Player->Health == 0.0f){
                                        //drak green if knock down and visible
                                        visCol.R = 0.0f;
                                        visCol.G = 0.3f;
                                        visCol.B = 0.0f;
                                        visCol.A = 1.0f;
                                    }else{
                                        //green
                                        visCol.R = 0.f;
                                        visCol.G = 1.f;
                                        visCol.B = 0.f;
                                        visCol.A = 1.f;
                                    }
                                }else if (Player->bEnsure){
                                    //gray R G B A
                                    //    FLinearColor Gray = { 0.501960814f, 0.501960814f, 0.501960814f, 1.000000000f };
                                    visCol.R = 0.435294117f;
                                    visCol.G = 0.501960814f;
                                    visCol.B = 0.501960814f;
                                    visCol.A = 1.000000000f;
                                    // if knocked down player color
                                }else if(Player->Health == 0.0f){
                                    //drak++ red if knocked down and not visible
                                    visCol.R = 0.549019607f;
                                    visCol.G = 0.039215686f;
                                    visCol.B = 0.050980392f;
                                    visCol.A = 1.0f;
                                }else{
                                    //red
                                    visCol.R = 1.f;
                                    visCol.G = 0.f;
                                    visCol.B = 0.f;
                                    visCol.A = 1.f;
                                }
                                if (Player->IsInvincible)
                                {
                                    //yallow
                                    visCol.R = 1.f;
                                    visCol.G = 1.f;
                                    visCol.B = 0.f;
                                    visCol.A = 1.f;
                                }
                                //show skeleton only player who < 500 m
                                if (Distance < 500.f) {
                                    FVector2D HeadSc, RootSc;
                                    //---- draw bone/SKELETON -----------
                                    if(IsBone)
                                    {
                                        // ESP SKELETON
                                        static vector<string> right_arm{"neck_01", "clavicle_r", "upperarm_r", "lowerarm_r", "hand_r", "item_r"};
                                        static vector<string> left_arm{"neck_01", "clavicle_l", "upperarm_l", "lowerarm_l", "hand_l", "item_l"};
                                        static vector<string> spine{"Head", "neck_01", "spine_03", "spine_02", "spine_01", "Pelvis"};
                                        static vector<string> lower_right{"Pelvis", "thigh_r", "calf_r", "foot_r"};
                                        static vector<string> lower_left{"Pelvis", "thigh_l", "calf_l", "foot_l"};
                                        static vector<vector<string>> skeleton{right_arm, left_arm, spine, lower_right, lower_left};
                                        for (auto &boneStructure : skeleton) {
                                            string lastBone;
                                            for (string &currentBone : boneStructure) {
                                                if (!lastBone.empty()) {
                                                    FVector2D boneFrom, boneTo;
                                                    if  (W2S(Player->GetBonePos(lastBone.c_str(), {}), (FVector2D *)&boneFrom) && W2S(Player->GetBonePos(currentBone.c_str(), {}), (FVector2D *)&boneTo)) {
                                                        
                                                        bool isVisible = localPlayerController->LineOfSightTo(localPlayerController->PlayerCameraManager, Player->GetBonePos(currentBone.c_str(), {}), true);
                                                        
                                                        
                                                        FVector wBoneFrom = GetBoneLocationByName(Player, lastBone.c_str());
                                                        FVector wBoneTo = GetBoneLocationByName(Player, currentBone.c_str());
                                                        
                                                        if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, wBoneFrom, false, &boneFrom) && gGameplayStatics->ProjectWorldToScreen(localPlayerController, wBoneTo, false, &boneTo)) {
                                                            if (IsVisible)
                                                                pHUD->Canvas->K2_DrawLine(boneFrom, boneTo, EspSktonThik, visCol);//EspSktonThik
                                                            else
                                                                pHUD->Canvas->K2_DrawLine(boneFrom, boneTo, EspSktonThik, visCol);//EspSktonThik
                                                        }
                                                    }
                                                }
                                                lastBone = currentBone;
                                            }
                                        }
                                    }
                                    // Aimbot
                                    bool AimbotStatus = false;
                                    if((IsAimbot) && (isAimKnocked)){
                                        AimbotStatus = true;
                                    }else if ((IsAimbot)&&(Player->Health != 0.0f)){
                                        AimbotStatus = true;
                                    }else{
                                        AimbotStatus = false;
                                    }
                                    if (AimbotStatus) {
                                        ASTExtraPlayerCharacter *Target =0;
                                        if (IsAimbotFov) {
                                            Target = GetTargetForAimBotByDistance();
                                            Target = GetTargetForAimBotByFOV();
                                        }
                                        else if (IsAimbotDis) {
                                            Target = GetTargetForAimBotByDistance();
                                        }
                                        if (Target) {
                                            bool triggerOk = true;
                                            if (!IsAutofire) {
                                                if (IsShoot) {
                                                    triggerOk = localPlayer->bIsWeaponFiring;
                                                } else if (IsSCope) {
                                                    triggerOk = localPlayer->bIsGunADS;
                                                } else if ((IsShoot)&&(IsSCope))  {//IsBothaim
                                                    triggerOk = localPlayer->bIsWeaponFiring && localPlayer->bIsGunADS;
                                                } else if (IsAny) {
                                                    triggerOk = localPlayer->bIsWeaponFiring || localPlayer->bIsGunADS;
                                                }
                                            } else triggerOk = true;
                                            if (triggerOk) {
                                                FVector targetAimPos = Target->GetHeadLocation(true);
                                                targetAimPos.Z -= aimpos();//  speed
                                                if(IsAimHead){
                                                    targetAimPos = Target->GetHeadLocation(true);
                                                }else if(IsAimNeck){
                                                    targetAimPos = Target->GetBonePos("neck_01", {});
                                                } else if (IsAimRoot){
                                                    targetAimPos = Target->GetBonePos("Pelvis", {});
                                                }
                                                auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                                                if (WeaponManagerComponent) {
                                                    auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                                                    if ((int) propSlot.GetValue() >= 1 &&
                                                        (int) propSlot.GetValue() <= 3) {
                                                        auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                                                        if (CurrentWeaponReplicated) {
                                                            auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                                            if (ShootWeaponComponent) {
                                                                UShootWeaponEntity *ShootWeaponEntityComponent = ShootWeaponComponent->ShootWeaponEntityComponent;
                                                                if (ShootWeaponEntityComponent) {
                                                                    ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                                                                    if (CurrentVehicle) {
                                                                        FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
                                                                        float dist = localPlayer->GetDistanceTo(Target);
                                                                        auto timeToTravel = dist /
                                                                        ShootWeaponEntityComponent->BulletFireSpeed;
                                                                        targetAimPos = UMC->Add_VectorVector(targetAimPos,UMC->Multiply_VectorFloat(LinearVelocity, timeToTravel));
                                                                    } else {
                                                                        FVector Velocity = Target->GetVelocity();
                                                                        float dist = localPlayer->GetDistanceTo(Target);
                                                                        auto timeToTravel = dist /
                                                                        ShootWeaponEntityComponent->BulletFireSpeed;
                                                                        targetAimPos = UMC->Add_VectorVector(targetAimPos, UMC->Multiply_VectorFloat(Velocity, timeToTravel));
                                                                    }
                                                                    localPlayerController->ClientSetLocation(localPlayer->K2_GetActorLocation(), ToRotator(localPlayerController->PlayerCameraManager->CameraCache.POV.Location, targetAimPos));
                                                                    //- check if player knocked dwon tragent or not target
                                                                    bool AuFirStatus = false;
                                                                    if((IsAutofire) && (isAimKnocked)){
                                                                        AuFirStatus = true;
                                                                    }else if ((IsAutofire)&&(Player->Health != 0.0f)){
                                                                        AuFirStatus = true;
                                                                    }else{
                                                                        AuFirStatus = false;
                                                                    }
                                                                    if (AuFirStatus){
                                                                        if(Distance < autodiss()){
                                                                            if(CurrentWeaponReplicated->CurBulletNumInClip > 1)
                                                                            {
                                                                                // localPlayerController->OnPressFire();
                                                                                // localPlayerController->OnReleaseFire();
                                                                                // autoFIRE(Interval);
                                                                                counter++;
                                                                                if(counter > Interval){
                                                                                    localPlayerController->OnPressFire();
                                                                                    localPlayerController->OnReleaseFire();
                                                                                    counter = 0;
                                                                                }
                                                                            }
                                                                            if(CurrentWeaponReplicated->CurBulletNumInClip <= 1){
                                                                                CurrentWeaponReplicated->StartReload();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if(ipadview){
                                    
                                    localPlayer->ThirdPersonCameraComponent->SetFieldOfView(ThanhIpad);
                                    
                                }
                                if (ipadviewv2) {
                                    auto MAIN =(FUObjectArray *) (obbbbl());
                                    auto objs = MAIN->ObjObjects;
                                    //                                            auto objs = UObject::GetGlobalObjects();
                                    for (int i = 0; i < objs.Num(); i++) {
                                        auto Object = objs.GetByIndex(i);
                                        if (isObjectInvalid(Object))
                                            continue;
                                        
                                        if (Object->IsA(ULocalPlayer::StaticClass())) {
                                            auto playerChar = (ULocalPlayer *) Object;
                                            playerChar->AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV;
                                        }}}
                                //IsJump
                                                                    if(IsJump){
                                                                        localPlayer->CharacterMovement->GravityScale = (int) -15;
                                                                        localPlayer->CharacterMovement->JumpZVelocity = 10.f;
                                                                        localPlayer->CharacterMovement->JumpOffJumpZFactor = 10.f;
                                                                        localPlayer->CharacterMovement->JumpZVelocity = 1000.f;
                                                                    }

                                if(AUOTJUMPAN){
                                    localPlayer->Jump();
                                }
                                // Arrows warring
                                if (IsWarring)
                                {
                                    bool Useless = false;
                                    FVector2D EntityPos = WorldToRadar(localPlayer->K2_GetActorRotation().Yaw, Head, localPlayer->GetHeadLocation(true), NULL, NULL, FVector((float)screenWidth, (float)screenHeight, 0.f), Useless);
                                    float radar_range = 270.f;
                                    FVector angle;
                                    FVector MiddlePoint(((float)screenWidth / 2.f) - EntityPos.X, ((float)screenHeight / 2.f) - EntityPos.Y, 0.f);
                                    VectorAnglesRadar(MiddlePoint, angle);
                                    const auto AngleYawRadian = DEG2RAD(angle.Y + 180.f);
                                    float Point_X = ((float)screenWidth / 2.f) + (radar_range) / 2.f * 8.f * cosf(AngleYawRadian);
                                    float Point_Y = ((float)screenHeight / 2.f) + (radar_range) / 2.f * 8.f * sinf(AngleYawRadian);
                                    FixTriangle(Point_X, Point_Y, 100);
                                    std::array < FVector2D, 39 > points
                                    {
                                        FVector2D((float)Point_X - (5.6f * (float)3.f), Point_Y - (7.3f *3.f)),
                                        FVector2D((float)Point_X + (11.6f *3.f), Point_Y),
                                        FVector2D((float)Point_X - (5.6f *3.f), Point_Y + (7.3f *3.f)),
                                        FVector2D((float)Point_X - (5.6f *3.f), Point_Y - (4.3f *3.f)),
                                        FVector2D((float)Point_X - (19.5f *3.f), Point_Y - (4.3f *3.f)),
                                        FVector2D((float)Point_X - (19.5f *3.f), Point_Y + (4.3f *3.f)),
                                        FVector2D((float)Point_X - (5.6f *3.f), Point_Y + (4.3f *3.f)),
                                        FVector2D((float)Point_X + (10.3f *3.f), Point_Y),
                                        FVector2D((float)Point_X - (5.f *3.f), Point_Y - (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f *3.f), Point_Y + (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (6.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (5.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (2.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (1.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (0.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (6.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (5.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (3.f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (2.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (1.5f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y + (0.2f *3.f)),
                                        FVector2D((float)Point_X - (5.f * (float)3.f), Point_Y - (0.2f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (3.75f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (3.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (2.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (1.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (0.5f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y - (0.2f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (3.75f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (3.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (2.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (1.f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (0.5f *3.f)),
                                        FVector2D((float)Point_X - (18.5f *3.f), Point_Y + (0.2f *3.f)),
                                    };
                                    // bool IsVisible = localPlayerController->LineOfSightTo(Player, {0,0,0}, true);
                                    /*  if(IsVisible) {
                                     visCol.R = 0.f;
                                     visCol.G = 1.f;
                                     visCol.B = 0.f;
                                     visCol.A = 1.f;
                                     }else {
                                     visCol.R = 1.f;
                                     visCol.G = 0.f;
                                     visCol.B = 0.f;
                                     visCol.A = 1.f;
                                     }*/
                                    FVector2D BelowRoowwtSc;
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, Head, false, &BelowRoowwtSc)) {
                                    }else{
                                        RotateTriangle(points, angle.Y + 180.0f);
                                        
                                        float Thickness = 3.f;
                                        if(Player->bEnsure){
                                            // DrawArrows(pHUD,points, Thickness, COLOR_WHITE); //No arrows if it Bots
                                        } else{
                                            DrawArrows(pHUD,points, Thickness, visCol);
                                      
                                        }
                                    }
                                }
                                //show players weapon name --------------
                                if(IsPlayerWEP){
                                    FVector rrrr = Player->GetBonePos("Head", {});
                                    FVector2D we;
                                    std::wstring wep;
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, rrrr, false, &we)) {
                                        auto WeaponManagerComponent = Player->WeaponManagerComponent;
                                        if (WeaponManagerComponent) {
                                            auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                                            if (CurrentWeaponReplicated) {
                                                auto wppp = CurrentWeaponReplicated->GetWeaponID();
                                                if(wppp == 108004 || wppp == 108003 || wppp == 108002  ||wppp == 108001 || wppp == 108000 || wppp == 108005 || wppp == 108006 || wppp == 108007)
                                                    continue;
                                                switch (wppp) {
                                                        // Rifle
                                                    case 101001:
                                                        wep = std::wstring(L" AKM ");
                                                        break;
                                                    case 101002:
                                                        wep = std::wstring(L" M16A4 ");
                                                        break;
                                                    case 101003:
                                                        wep = std::wstring(L" SCAR-L ");
                                                        break;
                                                    case 101004:
                                                        wep = std::wstring(L" M416 ");
                                                        break;
                                                    case 101005:
                                                        wep = std::wstring(L" Groza ");
                                                        break;
                                                    case 101006:
                                                        wep = std::wstring(L" AUG ");
                                                        break;
                                                    case 101007:
                                                        wep = std::wstring(L" QBZ ");
                                                        break;
                                                    case 101008:
                                                        wep = std::wstring(L" M762 ");
                                                        break;
                                                    case 101009:
                                                        wep = std::wstring(L" Mk47 ");
                                                        break;
                                                    case 101010:
                                                        wep = std::wstring(L" G36C ");
                                                        break;
                                                    case 101100:
                                                        wep = std::wstring(L" FAMAS ");
                                                        break;
                                                        //LIGHT MACHINEGUN
                                                    case 105001:
                                                        wep = std::wstring(L" M249 ");
                                                        break;
                                                    case 105002:
                                                        wep = std::wstring(L" DP-28 ");
                                                        break;
                                                        //SMG
                                                    case 102001:
                                                        wep = std::wstring(L" UZI ");
                                                        break;
                                                    case 102002:
                                                        wep = std::wstring(L" UMP45 ");
                                                        break;
                                                    case 102003:
                                                        wep = std::wstring(L" Vector ");
                                                        break;
                                                    case 102004:
                                                        wep = std::wstring(L" TommyGun ");
                                                        break;
                                                    case 102005:
                                                        wep = std::wstring(L" PP-19 Bizon ");
                                                        break;
                                                    case 102007:
                                                        wep = std::wstring(L" Skorpion ");
                                                        break;
                                                        //SNIPER
                                                    case 103001:
                                                        wep = std::wstring(L" Kar98K ");
                                                        break;
                                                    case 103002:
                                                        wep = std::wstring(L" M24 ");
                                                        break;
                                                    case 103003:
                                                        wep = std::wstring(L" AWM ");
                                                        break;
                                                    case 103004:
                                                        wep = std::wstring(L" SKS ");
                                                        break;
                                                    case 103005:
                                                        wep = std::wstring(L" VSS ");
                                                        break;
                                                    case 103006:
                                                        wep = std::wstring(L" Mini14 ");
                                                        break;
                                                    case 103007:
                                                        wep = std::wstring(L" Mk14 ");
                                                        break;
                                                    case 103008:
                                                        wep = std::wstring(L" Win94 ");
                                                        break;
                                                    case 103009:
                                                        wep = std::wstring(L" SLR ");
                                                        break;
                                                    case 103010:
                                                        wep = std::wstring(L" QBU ");
                                                        break;
                                                    case 103011:
                                                        wep = std::wstring(L" Mosin ");
                                                        break;
                                                        //SHOTGUN
                                                    case 103100:
                                                        wep = std::wstring(L" Mk12 ");
                                                        break;
                                                    case 104001:
                                                        wep = std::wstring(L" S686 ");
                                                        break;
                                                    case 104002:
                                                        wep = std::wstring(L" S1897 ");
                                                        break;
                                                    case 104003:
                                                        wep = std::wstring(L" S12K ");
                                                        break;
                                                    case 104004:
                                                        wep = std::wstring(L" M1014 ");
                                                        break;
                                                    case 106006:
                                                        wep = std::wstring(L" Sawed-off ");
                                                        break;
                                                        //POSTIL
                                                    case 106001:
                                                        wep = std::wstring(L" P1911 ");
                                                        break;
                                                    case 106003:
                                                        wep = std::wstring(L" R1895 ");
                                                        break;
                                                    case 106004:
                                                        wep = std::wstring(L" P18C ");
                                                        break;
                                                    case 106005:
                                                        wep = std::wstring(L" R45 ");
                                                        break;
                                                    case 106008:
                                                        wep = std::wstring(L" Vz61 ");
                                                        break;
                                                    case 106010:
                                                        wep = std::wstring(L" Desert Eagle ");
                                                        break;
                                                        //OTHER
                                                    case 107001:
                                                        wep = std::wstring(L" Crossbow ");
                                                        break;
                                                    case 108001:
                                                        wep = std::wstring(L" vcMachete ");
                                                        break;
                                                    case 108002:
                                                        wep = std::wstring(L" Crowbar ");
                                                        break;
                                                    case 108003:
                                                        wep = std::wstring(L" Sickle ");
                                                        break;
                                                    case 108004:
                                                        wep = std::wstring(L" Pan ");
                                                        break;
                                                    case 201001:
                                                        wep = std::wstring(L" Choke ");
                                                        break;
                                                    case 103012:
                                                        wep =std::wstring(L"AMR Sniper");
                                                        break;
                                                    default:
                                                        break;
                                                }
                                            }
                                        }
                                        robotoTinyFont->LegacyFontSize = max(EspTextSiz, 14 - (int)(Distance / 100));//4
                                        float txtWidth, txtHeight;
                                        pHUD->GetTextSize(FString(wep), robotoTinyFont, 1.f, &txtWidth,
                                                          &txtHeight);
                                        we.X  -= txtWidth *4.2;
                           
                                        DrawSmallOutlinedText(pHUD, wep, { we.X,we.Y}, visCol, COLOR_BLACK);
                                    }
                                }
                                if(!localPlayer->IsUsingGrenade()) {
                                    auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                                    if (WeaponManagerComponent) {
                                        auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                                        if ((int) propSlot.GetValue() >= 1 &&
                                            (int) propSlot.GetValue() <= 3) {
                                            auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                                            if (CurrentWeaponReplicated) {
                                                auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
                                                auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
                                                
                                                
                                                auto ID = CurrentWeaponReplicated->GetWeaponID();
                                                if(ID != 108004 && ID != 108003 && ID != 108002 && ID != 108001 && ID != 108000 && ID != 108005 && ID != 108006 && ID != 108007)
                                                    if (ShootWeaponEntityComp && ShootWeaponEffectComp)
                                                    {
                                                        if(IsCrossHair){
                                                            static float cnt = 0.0f;
                                                            float r = cos(cnt) * .5f + .5f;
                                                            float g = cos(cnt - 2.f * 3.14 / 3.f) * .5f + .5f;
                                                            float b = cos(cnt - 4.f * 3.14 / 3.f) * .5f + .5f;
                                                            if (cnt >= FLT_MAX) {
                                                                cnt = 0.0f;
                                                            } else {
                                                                cnt += 0.01f;
                                                            }
                                                            
                                                            memset(&ShootWeaponEntityComp->DeviationInfo, 0, sizeof(FSDeviation));
                                                            memset(&ShootWeaponEntityComp->RecoilInfo, 0, sizeof(FSRecoilInfo));
                                                            
                                                            ShootWeaponEntityComp->ShotGunCenterPerc = 0.0f;
                                                            ShootWeaponEntityComp->ShotGunVerticalSpread = 0.0f;
                                                            ShootWeaponEntityComp->ShotGunHorizontalSpread = 0.0f;
                                                            ShootWeaponEntityComp->GameDeviationFactor = 0.0f;
                                                            ShootWeaponEntityComp->GameDeviationAccuracy = 0.0f;
                                                            ShootWeaponEntityComp->CrossHairInitialSize = 0.0f;
                                                            ShootWeaponEntityComp->CrossHairBurstSpeed = 0.0f;
                                                            ShootWeaponEntityComp->CrossHairBurstIncreaseSpeed = 0.0f;
                                                            ShootWeaponEntityComp->VehicleWeaponDeviationAngle = 0.0f;
                                                        
                                                        }
                                                        if(IsHitXPL){
                                                            ShootWeaponEntityComp->ExtraHitPerformScale = 100;
                                                            ShootWeaponEntityComp->HUDAlphaDecreaseSpeedScale = 1.f;
                                                        }
                                                        if(IsNocamerashake) {
                                                            ShootWeaponEffectComp->CameraShakeInnerRadius = 0.0f;
                                                            ShootWeaponEffectComp->CameraShakeOuterRadius = 0.0f;
                                                            ShootWeaponEffectComp->CameraShakFalloff = 0.0f;
                                                        }
                                                        if(IsNorecoil){
                                                            {
                                                                ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.0f;
                                                                ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.0f;
                                                                ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.0f;
                                                            }
                                                        }
                                                        if(IsFastshoot){
                                                            ShootWeaponEntityComp->ShootInterval =0.060606f;
                                                        }
                                                        if(IsFastBullet) {
                                                            ShootWeaponEntityComp->BulletFireSpeed = 80000.f;
                                                        }
                                                        if(IsFastBullet) {
                                                            
                                                            ShootWeaponEntityComp->AnimationKick = 10;
                                                        }
                                                        
                                                    
                                                        
                                                      
                                                    }
                                            }
                                        }
                                    }
                                }
                                // ------------------------- 3D Player Box ESP  -------------------------------
                                if (Is3Dbox) {
                                    if(Distance <120){
                                        auto BoxBounds = Player->Mesh->CachedLocalBounds;
                                        auto colV = FLinearColor();
                                        FVector org;
                                        FVector extends;
                                        FVector Chest = Player->K2_GetActorLocation();
                                        DrawBox3D(pHUD,Player, visCol, Chest, BoxBounds.BoxExtent);
                                        box3d(pHUD, Player, Root, colV);
#define COLOR_ITEM FLinearColor(1, 1, 0.6, 1.f)
                                        Box3D(pHUD, org, {extends.X  +  40 , extends.Y + 130 , extends.Z + 70} ,COLOR_ITEM , 2.9 );
                                    }
                                }
                                
                                
                              
                                // ------------------------- HEALTH ESP  -------------------------------
                                if(IsPlayerHP){
                                    float CurHP = std::max(0.f, std::min(Player->Health, Player->HealthMax));
                                    float MaxHP = Player->HealthMax;
                                    float magic_number = (Distance);
                                                           float mx = (kWidth / 4) / magic_number;

                                                           float healthLength = kWidth / 20;
                                                           if (healthLength < mx)
                                                               healthLength = mx;
                                    
//                                    int CurHP = (int) std::max(0, std::min((int) Player->Health, (int)  Player->HealthMax));
//                                                                        int MaxHP = (int) Player->HealthMax;
                                    FLinearColor ColorHP = {
                                        std::min(((510.f * (MaxHP - CurHP)) / MaxHP) / 255.f, 1.f),
                                        std::min(((510.f * CurHP) / MaxHP) / 255.f, 1.f),
                                        0.f,
                                        0.5f
                                    };
                                    if (CurHP == 0 && !Player->bDead) {
                                        ColorHP = {0.63f, 0.82f, 0.42f, 0.75f};
                                        CurHP = Player->NearDeathBreath;
                                        USTCharacterNearDeathComp *NearDeatchComponent = Player->NearDeatchComponent;
                                        if (NearDeatchComponent) {
                                            MaxHP = NearDeatchComponent->BreathMax;
                                        }
                                    }
                                    auto AboveHead =  Player->GetHeadLocation(true);
                                    AboveHead.Z+=35.f;
                                    FVector2D AboveHeadSc;
                                    FVector2D ROT3;
                                    
                                    
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, AboveHead, false, &AboveHeadSc)) {
                                        auto mWidthScale = std::min(0.1f * Distance, 35.f);
                                        auto mWidth = 80.f - mWidthScale;
                                        auto mHeight = mWidth * 0.07f;
                                        AboveHeadSc.X -= (mWidth / 2);
                                        AboveHeadSc.Y -= (mHeight * 1.55f);
                                        if(Player->bEnsure){
                                            DrawFilledRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, (CurHP * mWidth / MaxHP), mHeight, allColors::Green);
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-16, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-32, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-48, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-64, mHeight, 1.3f, {0, 0, 0, 1.f});
                                  
                }else{
                                            DrawFilledRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, (CurHP * mWidth / MaxHP), mHeight, COLOR_RED);
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-16, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-32, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-48, mHeight, 1.3f, {0, 0, 0, 1.f});
                                            DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth-64, mHeight, 1.3f, {0, 0, 0, 1.f});
                                        }
                                        
                                    }
                                }
                                if(IsPLayerName){
                                    float isRed1 = 1.0f;  // Khởi tạo màu đỏ
                                    float isGreen1 = 0.01f;
                                    static float isRed = 0.0f, isGreen = 0.01f, isBlue = 0.0f;
                                    auto isFrames = ImGui::GetFrameCount();
                                    if (isFrames % 2 == 0) {  // Cập nhật màu mỗi 2 frame
                                        isGreen1 += 0.04f;  // Tăng dần màu xanh với tốc độ nhanh hơn
                                        if (isGreen1 > 0.99f) {
                                            isGreen1 = 0.01f;  // Reset xanh về 0.01 khi đạt mức cao nhất
                                            isRed1 = 1.0f - isGreen;  // Đồng thời giảm đỏ tương ứng
                                        }
                                    }
                                    std::wstring fpd;
                                    std::wstring w;
                                   
             
                                    }
                                
                                    
                                // ------------------------- Player Name -------------------------------
                                if(IsPLayerName){
                                    FVector BelowRoot = Player->GetBonePos("Head", {});
                                    FVector2D BelowRootSc;
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, BelowRoot, false, &BelowRootSc)) {
                                        std::wstring ws;
                                        std::string s;
                                        {

                                            
                                            if (Player->Health == 0.0f) {
                                                ws = L"Knocked";
                                            }

                                        }
                                        robotoTinyFont->LegacyFontSize = max(EspTextSiz, 14 - (int)(Distance / 100));//4
                                        float txtWidth, txtHeight;
                                        pHUD->GetTextSize(FString(ws), robotoTinyFont, 1.f, &txtWidth,
                                                          &txtHeight);
                                        BelowRootSc.Y += txtHeight * 1.5;
                                        DrawSmallOutlinedText(pHUD,ws, FVector2D(BelowRootSc.X, BelowRootSc.Y ), visCol, COLOR_BLACK, true);
                         

                                        UIColor *TextColor = [UIColor colorWithRed:visCol.R green:visCol.G blue:visCol.B alpha:visCol.A];
                                        // draw player line
                                        FVector Head = GetBoneLocationByName(Player, "Head");
                                        Head.Z += 75.5f;

                                        FVector Root = GetBoneLocationByName(Player, "Root");
                                        FVector2D HeadSc, RootSc;
                                        auto HeadPos = Player->GetBonePos("Head", {});
                                        if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, Head, false, &HeadSc) && gGameplayStatics->ProjectWorldToScreen(localPlayerController, Root, false, &RootSc)) {
                                            if(DrawPlayerLine){
                                                DrawLine(pHUD, {(float)ScreenWidth / 2, 8}, HeadSc, 1.5f, visCol);
                                            }
                                        }
      
                                        if (Player->IsInvincible){
                                            IntCount ++;
                                            std::wstring spwanCounter;
                                            spwanCounter += L"Hồi sinh: ";
                                            spwanCounter += std::to_wstring((int)IntCount);
                                            DrawSmallOutlinedText(pHUD,spwanCounter, FVector2D(BelowRootSc.X, BelowRootSc.Y ), visCol, COLOR_BLUE, true);
                                        }else{
                                            IntCount = 0;
                                        }
                                        std::wstring ws_msg ;
                                        if(Player->IsRescueingOther){
//
                                            ws_msg = L"Đợi Tao Tí";
                                            tslFont->LegacyFontSize = 14;
                                            if(AR_language){
                                                ws_msg = L"ذﺎﻘﻧﻻﺍ";
                                                tslFont->LegacyFontSize = 14;
                                            }
                                            DrawOutlinedText(pHUD, FString(ws_msg),FVector2D(BelowRootSc.X, BelowRootSc.Y+40 ), visCol, COLOR_BLACK, true);
                                        }
                                        if(Player->Health == 0.0f){
                                            tslFont->LegacyFontSize = 14;
                                            if(AR_language){
                                                ws_msg = L"ﻂﻘﺳﺍ";
                                                tslFont->LegacyFontSize = 14;
                                            }
                                            DrawOutlinedText(pHUD, FString(ws_msg),FVector2D(BelowRootSc.X, BelowRootSc.Y+40 ), visCol, COLOR_BLACK, true);
                                        }
                                    }
                                }
                                if (IsPLayerName || iSPLAYERDIS) {
                                    FVector AboveHead = Player->GetBonePos("Head", {});
                                   
                                    AboveHead.Z += 35.f;
                                    FVector2D AboveHeadSc;
                                    
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, AboveHead, false, &AboveHeadSc)) {
                                        std::wstring ws;
                                        std::wstring s;
                                        std::wstring dis;

                                        if (IsPLayerName) {
                                            if (Player->bEnsure)
                                                ws += L"BOT";
                                                else if (Player->PlayerName.IsValid())
                                                ws += Player->PlayerName.ToWString();
                                        }

                                        robotoTinyFont->LegacyFontSize = max(EspTextSiz, 14 - (int)(Distance / 80));
                                        float txtWidth, txtHeight;
                                        pHUD->GetTextSize(FString(ws), robotoTinyFont, 1.f, &txtWidth, &txtHeight);
                                        DrawSmallOutlinedText(pHUD,ws, FVector2D(AboveHeadSc.X, AboveHeadSc.Y - txtHeight), COLOR_WHITE, COLOR_BLACK, true);
                                        
                                    
                                        
                                    
                                      
          
                                    }
                                }
                                // --------- Player distnation --------
                                if(iSPLAYERDIS){
                                    FVector BelowRootE = Player->GetBonePos("foot_r", {});
                                    FVector2D BelowRootScD;
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, BelowRootE, false, &BelowRootScD)) {
                                        std::wstring ws;
                                        ws += L"";
                                        ws += std::to_wstring((int) Distance);
                                        ws += L"m";
                                        robotoTinyFont->LegacyFontSize = max(EspTextSiz, 14 - (int)(Distance / 100));//4
                                        float txtWidth, txtHeight;
                                        pHUD->GetTextSize(FString(ws), robotoTinyFont, 1.f, &txtWidth,
                                                          &txtHeight);
                                        DrawSmallOutlinedText(pHUD,ws, FVector2D(BelowRootScD.X, BelowRootScD.Y ), COLOR_WHITE, COLOR_BLACK, true);
                                        //color for next item Enemies label
                                        bool IsVisible = localPlayerController ->LineOfSightTo(Player, { 0, 0, 0 }, false);
                                        if(IsVisible) {
                                            //green
                                            visCol.R = 0.f;
                                            visCol.G = 1.f;
                                            visCol.B = 0.f;
                                            visCol.A = 1.f;
                                        }else {
                                            //red
                                            visCol.R = 1.f;
                                            visCol.G = 0.f;
                                            visCol.B = 0.f;
                                            visCol.A = 1.f;
                                        }
                                    }
                                }
                            }PlayerCharacter2.clear();
                        
                                // Enemies counter top label
                            {
                              
                                //iAwareText:
                                if(iAwareText){
                                    FVector2D opp;
                                    FVector ii;
                                    if(gGameplayStatics->ProjectWorldToScreen(localPlayerController, ii, false, &opp)){
                                    }else{
                                        if(totalEnemies>0 || totalBots >0){
                                     

                                        
                                            std::wstring fpd ;
                                            std::wstring cc3m ;
                                            std::wstring s;
                                            std::wstring w;
                                          
                                            if(AR_language){
                                                fpd=L" ءاﺪﻋﻻﺍ ";
                                            }else{
                                                
                                             if (totalEnemies == 0 && totalBots == 0) {  // New condition for resetting skin
                                                if(checkm4rs){
                                                  m4rs =true;
                                                }
                                            }
                                                fpd=L"Kẻ Thù: " + std::to_wstring((int)totalEnemies) + L" Bot: " + std::to_wstring((int)totalBots);
                                                if(checkskinsung){
                                                    skinsung =true;
                                                }
                                                if(checktrangphuc){
                                                    trangphuc =true;
                                                }
                                                if(initkillmsgcheck){
                                                    initkillmsgopen =true;
                                                }
                                           
                                                                                            if(DeadBox){
                                                    Box =true;
                                                }
                                           
                                            }
                      
                                            
                                            
                                  
                                            tslFont->LegacyFontSize = 30;
                                            DrawText(pHUD, FString(fpd), FVector2D(screenWidth / 2, 165),
                                                     visCol, true);
                                            
                                    

                                        }
                                    }
                                }
                          
                            }
                                }//
                            }
                        }
                    }
                
        }
        
        
        
         {

                    if(localPlayer){
                        if(SceneComponent) {
                            SceneComponent->AntiCheatRandValue0 = 0;
                            SceneComponent->AntiCheatRandValue1 = 0;
                            SceneComponent->AntiCheatRandValue2 = 0;
                            SceneComponent->AntiCheatRandValue3 = 0;
                            SceneComponent->AntiCheatRandValue4 = 0;
                            SceneComponent->AntiCheatRandValue5 = 0;
                            SceneComponent->AntiCheatRandValue6 = 0;
                        }
                        if(localPlayer->MoveAntiCheatComponent) {
                            localPlayer-> MoveAntiCheatComponent = 0;
                        }
                        if(STExtraShootWeapon) {
                            STExtraShootWeapon->AntiCheatComp = 0;
                        }
                        if(localPlayerController) {
                            localPlayerController->AntiCheatManagerComp = 0;
                            localPlayerController->bShouldReportAntiCheat = (bool) 0;
                            localPlayerController->CheatManager = 0;
                        }
                        if(CheatManager) {
                            CheatManager = 0;
                        }
                        if(PlayerAntiCheatManager) {
                            PlayerAntiCheatManager = 0;
                            PlayerAntiCheatManager->VehicleSpeedZDeltaTotal = (float) 0;
                            PlayerAntiCheatManager->VehicleSpeedZDeltaOver10Times = (int) 0;
                        }
                        if(localPlayer->STCharacterMovement) {
                            localPlayer-> STCharacterMovement->bCheatFlying = (bool) 0;
                        }
                        if(GameNetworkManager) {
                            GameNetworkManager->bHasStandbyCheatTriggered = (bool) 0;
                            GameNetworkManager->StandbyRxCheatTime = (float) 0;
                            GameNetworkManager->StandbyTxCheatTime = (float) 0;
                            GameNetworkManager->bMovementTimeDiscrepancyDetection = (bool) 0;
                        }
                        if(VerifySwitch) {
                            VerifySwitch = 0;
                            VerifySwitch->VerifyFailedCnt = 0;
                        }
                        if(AntiCheatDetailData){
                            AntiCheatDetailData = 0;
                        }
                        if(DistanceContinueHitCheck) {
                            DistanceContinueHitCheck = 0;
                            DistanceContinueHitCheck->MaxCheatTimes = (float) 99999999;
                            DistanceContinueHitCheck->CheckDisSquared = (float) 0;
                        }
                        if(WeaponAntiCheatComp) {
                            WeaponAntiCheatComp = 0;
                            WeaponAntiCheatComp->ShootRateCheckInterval = (float) 0;
                            WeaponAntiCheatComp->ShootRateCheckTag = (bool) 0;
                            WeaponAntiCheatComp->ShootRateCheckMulCoff = (float) 0;
                            WeaponAntiCheatComp->ShootHitTargetIntervalMulCoff = (float) 0;
                            WeaponAntiCheatComp->ShootTimeInfoCheckClearInterval = (float) 0;
                            WeaponAntiCheatComp->ShootTimeInfoCheckLifeTime = (float) 0;
                            WeaponAntiCheatComp->ShootTimeGunPosBigCircle = (float) 0;
                            WeaponAntiCheatComp->ShootTimeGunPosMaxRightDif = (float) 0;
                            WeaponAntiCheatComp->ShootTimeGunPosMaxRightDifInVehicle = (float) 0;
                            WeaponAntiCheatComp->ShootTimeGunPosMaxRightDif = (float) 0;
                            WeaponAntiCheatComp->ShootTimeGunPosMaxRightDifInVehicle = (float) 0;
                            WeaponAntiCheatComp->MaxClientCapsuleHalfHeight = (int) 9999999;
                            WeaponAntiCheatComp->ShootTimeMuzzleDistThres = (float) 0;
                            WeaponAntiCheatComp->ShootTimeMuzzleZThres = (float) 0;
                            WeaponAntiCheatComp->bVerifyTimeLineSync = (bool) 0;
                            WeaponAntiCheatComp->TimeLineCheckDnBorder = (float) 0;
                            WeaponAntiCheatComp->TimeLineCheckUpBorder = (float) 0;
                            WeaponAntiCheatComp->ShootTimeConnectionDeltaThres = (float) 0;
                            WeaponAntiCheatComp->bVerifyStartFireTime = (bool) 0;
                            WeaponAntiCheatComp->MaxShootPassTimeDeltaBetweenSysAndLevel = (float) 0;
                            WeaponAntiCheatComp->TolerateFlyTime = (float) 0;
                            WeaponAntiCheatComp->TolerateFlyDis = (float) 0;
                        }

                        if( localPlayer->STCharacterMovement){
                            localPlayer-> STCharacterMovement->CheatCheckSumFailed = (bool) 0;
                            localPlayer->STCharacterMovement->bCheatClientLocation = (bool) 0;
                            localPlayer-> STCharacterMovement->bUseTimeSpeedAntiCheatCheck = (bool) 0;
                        }
                        if(AntiCheatUtils) {
                            AntiCheatUtils = 0;
                        }
                        if(DefaultAntiCheatComponent) {
                            DefaultAntiCheatComponent = 0;
                        }
                        if(GMCheatManager) {
                            GMCheatManager = 0;
                        }
                        if(STBuildSystemComponent) {
                        }
                        if(VACTask_AccelerationControl) {
                            VACTask_AccelerationControl->MaxAccelerationSpeed = (float) 999999;
                            VACTask_AccelerationControl->CheckInterval = (float) 0;
                        }
                        if(VACTask_ClientAbsSpeed) {
                            VACTask_ClientAbsSpeed->CheckInterval = (float) 0;
                        }
                        if(VACTask_FlyingVehicle) {
                            VACTask_FlyingVehicle = 0;
                        }
                        if(VACTask_FlyingVehicleVelocityChange) {
                            VACTask_FlyingVehicleVelocityChange = 0;
                        }
                        if(VACTask_FlyingVehicleVelocity) {
                            VACTask_FlyingVehicleVelocity = 0;
                        }
                        if(VACTask_SuperSpeed) {
                            VACTask_SuperSpeed = 0;
                        }
                        if(VACTask_SuperSpeedAllDir) {
                            VACTask_SuperSpeedAllDir = 0;
                        }
                        if(VACTask_FlyingVehicle) {
                            VACTask_FlyingVehicle = 0;
                        }
                        if(ActorComponent) {
                            ActorComponent = 0;
                        }
                        if(AssetUserData) {
                            AssetUserData = 0;
                        }
                    }
                    
                
        }
        //flay man
        if (IsFastKnock) {{
            if(localPlayer)
                if( localPlayer->STCharacterMovement){
                    localPlayer->STCharacterMovement->MaxWalkSpeed += 500.f;
                    localPlayer->STCharacterMovement->MaxWalkSpeedCrouched =  localPlayer->STCharacterMovement->MaxWalkSpeed * 1000.f;
                  
                }
        }
        }
        
        
        if (IsFastDrop) {
            if(localPlayer){
                if(   localPlayer->ParachuteComponent) {
                    localPlayer-> ParachuteComponent->CurrentFallSpeed = (float) 8300;
                    localPlayer->  ParachuteComponent->FreeFall_AcceFall = (float) 25000;
                    localPlayer->  ParachuteComponent->FreeFall_MaxFreeFallSpeed = (float) 25000;
                    localPlayer-> ParachuteComponent->FreeFall_AcceForward = (float) 25000;
                    localPlayer-> ParachuteComponent->FreeFall_MaxForwardExtraFallSpeed = (float) 25000;
                    localPlayer-> ParachuteComponent->Opened_AcceFall = (float) 5000;
                    localPlayer->  ParachuteComponent->Opened_MaxFreeFallSpeed = (float) 5000;
                    localPlayer->  ParachuteComponent->Opened_AcceForward = (float) 5000;
                    localPlayer-> ParachuteComponent->Opened_MaxForwardSpeed = (float) 5000;
                    localPlayer->  ParachuteComponent->Opened_MaxForwardExtraFallSpeed = (float) 5000;
                    localPlayer->  ParachuteComponent->FreeFall_AcceForward = (float) 5000;
                    localPlayer-> ParachuteComponent->FreeFall_MaxForwardExtraFallSpeed = (float) 5000;
                    localPlayer->  ParachuteComponent->Opened_AcceFall = (float) 5000;
                    localPlayer-> ParachuteComponent->Opened_MaxFreeFallSpeed = (float) 5000;
                    localPlayer-> ParachuteComponent->Opened_AcceForward = (float) 5000;
                    localPlayer-> ParachuteComponent->AllowMaxDiatanceSqAtServer = (float) 40000;
                    localPlayer-> ParachuteComponent->MaxZAllowDistance = (float) 40000;
                }}
        }
        // islootbox
        if(IsLootBox) {
            // std::vector<Airdropbox*>ddd;
            
            std::vector < APickUpListWrapperActor * >ItemBase;
         
            GetAllActors(ItemBase);
            
            for (auto actor = ItemBase.begin(); actor != ItemBase.end(); actor++)
            {
                auto PickUpList = *actor;
                auto RootComponent = PickUpList->RootComponent;
                if (!RootComponent)
                    continue;
                //--
                std::wstring lootBoxType;
                switch (PickUpList->BoxType) {
                    case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_LootBox:
                        lootBoxType = L"LootBox";
                    case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_TombBox:
                        lootBoxType = L"TomBOX";
                    case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_AirDropBox:
                        lootBoxType = L"Airdrop";
                    default:
                        lootBoxType = L"LootBox";
                }
               
                
                //--
                float Distance = PickUpList->GetDistanceTo(localPlayer) / 100.f;
                auto Location = PickUpList->RootComponent->RelativeLocation;
                FVector2D itemPos;
                DrawBox3D(pHUD,PickUpList, COLOR_LIME, Location, FVector(26, 42, 15));//draw TomBOX 3d
                if( W2S(Location, &itemPos)){
                    auto Items = PickUpList->GetDataList();
                    for (int i = 0; i < Items.Num(); i++) {
                        auto iditeam = Items[i].ID.TypeSpecificID;
                        std::wstring AR;
                        std::wstring SM;
                        std::wstring SN;
                        std::wstring SH;
                        std::wstring OTH;
                        std::wstring AMMO;
                        std::wstring SCO;
                        std::wstring ARM;
                        std::wstring item;
                        std::wstring airdrop_x;
                        switch (iditeam) {
                            case 101001:
                                AR = std::wstring(L" AKM ");
                                break;
                            case 101002:
                                AR = std::wstring(L" M16A4 ");
                                break;
                            case 101003:
                                AR = std::wstring(L" SCAR-L ");
                                break;
                            case 101004:
                                AR = std::wstring(L" M416 ");
                                break;
                            case 101005:
                                AR= std::wstring(L" Groza ");
                                break;
                            case 101006:
                                AR = std::wstring(L" AUG ");
                                break;
                            case 602002:
                                if(AR_language){
                                    AR = std::wstring(L" ﺔﻴﻧﺎﺧﺩ ﻪﻠﺒﻨﻗ ");
                                }else{
                                    AR = std::wstring(L" Smoke ");
                                }
                                break;
                            case 602003:
                                if(AR_language){
                                    AR = std::wstring(L"فﻮﺗﻮﻟﻮﻣ");
                                }else{
                                    AR = std::wstring(L" Molitove ");
                                }
                                break;
                            case 602004:
                                if(AR_language){
                                    SM = std::wstring(L" ﻪﻠﺒﻨﻗ ");
                                }else{
                                    SM = std::wstring(L" Grenade ");
                                }
                                
                                break;
                            case 101007:
                                SM = std::wstring(L" QBZ ");
                                break;
                            case 101008:
                                SM = std::wstring(L" M762 ");
                                break;
                            case 101009:
                                SM = std::wstring(L" Mk47 ");
                                break;
                            case 101010:
                                SM = std::wstring(L" G36C ");
                                break;
                            case 101100:
                                SM = std::wstring(L" FAMAS ");
                                break;
                            case 102001:
                                SM = std::wstring(L" UZI ");
                                break;
                            case 102002:
                                SM = std::wstring(L" UMP45 ");
                                break;
                            case 102003:
                                SM = std::wstring(L" Vector ");
                                break;
                            case 102004:
                                SN = std::wstring(L" TommyGun ");
                                break;
                            case 102005:
                                SN = std::wstring(L" PP-19 Bizon ");
                                break;
                            case 102007:
                                SN = std::wstring(L" Skorpion ");
                                break;
                            case 103001:
                                SN = std::wstring(L" Kar98K ");
                                break;
                            case 103002:
                                SN = std::wstring(L" M24 ");
                                break;
                            case 103003:
                                SN = std::wstring(L" AWM ");
                                break;
                            case 103004:
                                SN = std::wstring(L" SKS ");
                                break;
                            case 103005:
                                SN = std::wstring(L" VSS ");
                                break;
                            case 103006:
                                SN = std::wstring(L" Mini14 ");
                                break;
                            case 103007:
                                SN = std::wstring(L" Mk14 ");
                                break;
                            case 103008:
                                SN = std::wstring(L" Win94 ");
                                break;
                            case 103009:
                                SH = std::wstring(L" SLR ");
                                break;
                            case 103010:
                                SH = std::wstring(L" QBU ");
                                break;
                            case 103011:
                                SH = std::wstring(L" Mosin ");
                                break;
                            case 103012:
                                SH =std::wstring(L"AMR Sniper");
                                break;
                            case 103100:
                                SH = std::wstring(L" Mk12 ");
                                break;
                            case 104001:
                                SH = std::wstring(L" S686 ");
                                break;
                            case 104002:
                                SH = std::wstring(L" S1897 ");
                                break;
                            case 104003:
                                SH = std::wstring(L" S12K ");
                                break;
                            case 104004:
                                SH = std::wstring(L" M1014 ");
                                break;
                            case 106006:
                                SH = std::wstring(L" Sawed-off ");
                                break;
                            case 203001:
                                if(AR_language){
                                    OTH = std::wstring(L"تﻭﺩ ﺪﻳﺭ ");
                                }else{
                                    OTH = std::wstring(L"Red Dot");
                                }
                                
                                break;
                            case 203002:
                                if(AR_language){
                                    OTH = std::wstring(L" ﻮﻟﻮﻫ رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"Holographic");
                                }
                                break;
                            case 203003:
                                if(AR_language){
                                    OTH = std::wstring(L" 2x رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"2x Scope");
                                    
                                }
                                break;
                            case 203004:
                                if(AR_language){
                                    OTH = std::wstring(L" 4x رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"4x Scope");
                                }
                                break;
                            case 203005:
                                if(AR_language){
                                    OTH = std::wstring(L" 8x رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"8x Scope");
                                }
                                break;
                            case 203014:
                                if(AR_language){
                                    OTH = std::wstring(L" 3x رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"3x Scope");
                                }
                                break;
                            case 203015:
                                if(AR_language){
                                    OTH = std::wstring(L" 6x رﺎﻈﻨﻣ ");
                                }else{
                                    OTH = std::wstring(L"6x Scope");
                                }
                                break;
                            case 301001:
                                OTH = std::wstring(L" 9mm ");
                                break;
                            case 302001:
                                OTH = std::wstring(L" 7.62mm");
                                break;
                            case 303001:
                                OTH = std::wstring(L" 5.56mm ");
                                break;
                            case 304001:
                                if(AR_language){
                                    OTH = std::wstring(L" 12 ﻦﺟ تﻮﺷ ");
                                }else{
                                    OTH = std::wstring(L"12 Gauge");
                                }
                                break;
                            case 305001:
                                if(AR_language){
                                    OTH = std::wstring(L".45 ﺾﻴﺑﺍ صﺎﺻﺭ ");
                                }else{
                                    OTH = std::wstring(L".45 ACP");
                                }
                                break;
                            case 306001:
                                if(AR_language){
                                    OTH = std::wstring(L".300 مﻮﻨﻛﺎﻣ صﺎﺻﺭ ");
                                }else{
                                    OTH = std::wstring(L".300 Magnum");
                                }
                                break;
                            case 307001:
                                if(AR_language){
                                    OTH = std::wstring(L" سﻮﻗ ﻢﻬﺳﺍ ");
                                }else{
                                    OTH = std::wstring(L"Crossbow");
                                }
                                break;
                            case 105001:
                                OTH = std::wstring(L" M249 ");
                                break;
                            case 105002:
                                OTH = std::wstring(L" DP-28 ");
                                break;
                            case 601001:
                                if(AR_language){
                                    SCO = std::wstring(L" ﺔﻗﺎﻃ بﻭﺮﺸﻣ ");
                                }else{
                                    SCO = std::wstring(L"Soda");
                                }
                                break;
                            case 601002:
                                if(AR_language){
                                    SCO = std::wstring(L"جﻼﻋ ﻪﻨﻘﺣ ");
                                }else{
                                    SCO = std::wstring(L"Pills");
                                }
                                break;
                            case 601003:
                                if(AR_language){
                                    SCO = std::wstring(L"ﻦﻜﺴﻣ ");
                                }else{
                                    SCO = std::wstring(L"Adrenaline");
                                }
                                break;
                            case 601004:
                                if(AR_language){
                                    SCO = std::wstring(L"جﺪﻧﺎﺑ ");
                                }else{
                                    SCO = std::wstring(L"Bandage");
                                }
                                break;
                            case 601005:
                                if(AR_language){
                                    SCO = std::wstring(L"ﺔﻴﻟﻭﺍ جﻼﻋ ﺔﺒﻴﻘﺣ ");
                                }else{
                                    SCO = std::wstring(L"First Aid");
                                }
                                break;
                            case 601006:
                                if(AR_language){
                                    SCO = std::wstring(L"جﻼﻋ ﺔﺒﻴﻘﺣ ");
                                }else{
                                    SCO = std::wstring(L"Med kit");
                                }
                                break;
                            case 501001:
                                if(AR_language){
                                    SCO = std::wstring(L" ١ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                }else{
                                    SCO = std::wstring(L"Bag Lv1");
                                }
                                break;
                            case 501002:
                                if(AR_language){
                                    SCO = std::wstring(L"٢ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                }else{
                                    SCO = std::wstring(L"Bag Lv2");
                                }
                                break;
                            case 501006:
                                if(AR_language){
                                    AMMO = std::wstring(L" ٣ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                }else{
                                    AMMO = std::wstring(L"Bag Lv3");
                                }
                                break;
                            case 502001:
                                if(AR_language){
                                    AMMO = std::wstring(L" ١ ىﻮﺘﺴﻣ هﺫﻮﺧ ");
                                }else{
                                    AMMO = std::wstring(L"Helmet Lv1");
                                }
                                break;
                            case 502002:
                                if(AR_language){
                                    AMMO = std::wstring(L"٢ ىﻮﺘﺴﻣ هﺫﻮﺧ");
                                }else{
                                    AMMO = std::wstring(L"Helmet Lv2");
                                }
                                break;
                            case 502003:
                                if(AR_language){
                                    AMMO = std::wstring(L" ٣ ىﻮﺘﺴﻣ هﺫﻮﺧ");
                                }else{
                                    AMMO = std::wstring(L"Helmet Lv3");
                                }
                                break;
                            case 503001:
                                if(AR_language){
                                    AMMO = std::wstring(L"١ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                }else{
                                    AMMO = std::wstring(L"Police Vest(Lv1)");
                                }
                                break;
                            case 503002:
                                if(AR_language){
                                    AMMO = std::wstring(L"٢ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                }else{
                                    AMMO = std::wstring(L"Police Vest(Lv2)");
                                }
                                break;
                            case 503003:
                                if(AR_language){
                                    AMMO = std::wstring(L"٣ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                }else{
                                    AMMO = std::wstring(L"Police Vest(Lv3)");
                                }
                                break;
                            default:
                                break;
                        }
                        
                        
                        robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                        float txtWidth, txtHeight;
                        pHUD->GetTextSize(FString(AR), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(SN), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(SH), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(SM), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(AMMO), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(OTH), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        pHUD->GetTextSize(FString(SCO), robotoTinyFont, 1.f, &txtWidth,
                                          &txtHeight);
                        itemPos.Y += txtHeight *1.3;
                        visCol.R = 1;
                        visCol.G = 0.3;
                        visCol.B = 0.2;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, AR, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 0.3;
                        visCol.G = 1;
                        visCol.B = 0.2;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, OTH, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 0.2;
                        visCol.G = 0.3;
                        visCol.B = 1;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, SM, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 1.2;
                        visCol.G = 1.5;
                        visCol.B = 0.5;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, SN, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 0.2;
                        visCol.G = 0.3;
                        visCol.B = 0.2;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, SH, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 1;
                        visCol.G = 1;
                        visCol.B = 1.4;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, SCO, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        visCol.R = 1.2;
                        visCol.G = 3.3;
                        visCol.B = 3.2;
                        visCol.A = 1.f;
                        DrawSmallOutlinedText(pHUD, AMMO, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                        // next line for text not approved yet - to draw lootbox name
                        DrawSmallOutlinedText(pHUD, lootBoxType, { 100.f,100.f}, visCol, COLOR_BLACK);
                    }
                }
            }ItemBase.clear();
        }
        //Airdrop esp
        if(IsAirDrop){
            //(actor->IsA(Classes::ACarePackageItem::StaticClass()))
            //APickUpListWrapperActor->AAirDropListWrapperActor
            std::vector < AAirDropListWrapperActor * >ItemBase;
            GetAllActors(ItemBase);
            for (auto actor = ItemBase.begin(); actor != ItemBase.end(); actor++)
            {
                auto PickUpList = *actor;
                //std::wstring lootType = GetLootName(PickUpList);
                auto RootComponent = PickUpList->RootComponent;
                if (!RootComponent)
                    continue;
                //float Distance = PickUpList->GetDistanceTo(localPlayer) / 100.f;
                auto Location = PickUpList->RootComponent->RelativeLocation;
                FVector2D itemPos;
                //auto LotTypeSTR = "";
                //LotTypeSTR =  GetLootName(PickUpList);
                DrawBox3D(pHUD,PickUpList, COLOR_RED, Location, FVector(50, 50, 50));
                
                /*if(PickUpList->BoxType == EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_AirDropBox){
                 DrawBox3D(pHUD,PickUpList, COLOR_LIME, Location, FVector(26, 42, 15));
                 }*/
            }
        }
        {
            std::vector<APickUpWrapperActor*> ITEMM;
            GetAllActors(ITEMM);
            for (auto actor = ITEMM.begin(); actor != ITEMM.end(); actor++) {
                auto PickUp = *actor;
                //if(PickUp->IsA(FAirDropBoxData)){};
                if(PickUp->bIsInAirDropBox){
                    auto Location = PickUp->RootComponent->RelativeLocation;
                    DrawBox3D(pHUD,PickUp, COLOR_BLUE, Location, FVector(60, 60, 60));
                };
                auto pp =(PickUp->DefineID.TypeSpecificID);
                if(pp){
                    auto RootComponent = PickUp->RootComponent;
                    if (!RootComponent ||PickUp->bHidden)
                        continue;
                    float Distance = PickUp->GetDistanceTo(localPlayer) / 100.f;
                    FVector2D itemPos;
                    if (Distance > 2 && Distance <= 50) {
                        if(gGameplayStatics->ProjectWorldToScreen(localPlayerController, PickUp->K2_GetActorLocation(), true, &itemPos)){
                            std::wstring AR;
                            std::wstring SM;
                            std::wstring SN;
                            std::wstring SH;
                            std::wstring OTH;
                            std::wstring AMMO;
                            std::wstring SCO;
                            std::wstring ARM;
                            std::wstring item;
                            if(IsITM){
                            if(IsAR){
                                switch (pp) {
                                    case 101001://need to be translate
                                        AR = std::wstring(L" AKM ");
                                        break;
                                    case 101002:
                                        AR = std::wstring(L" M16A4 ");
                                        break;
                                    case 101003:
                                        AR = std::wstring(L" SCAR-L ");
                                        break;
                                    case 101004:
                                        AR = std::wstring(L" M416 ");
                                        break;
                                    case 101005:
                                        AR= std::wstring(L" Groza ");
                                        break;
                                    case 101006:
                                        AR = std::wstring(L" AUG ");
                                        break;
                                    case 602002:
                                        if(AR_language){
                                            AR = std::wstring(L" ﺔﻴﻧﺎﺧﺩ ");
                                        }else{
                                            AR = std::wstring(L" Smoke ");
                                        }
                                        
                                        break;
                                    case 602003:
                                        if(AR_language){
                                            AR = std::wstring(L" فﻮﺗﻮﻟﻮﻣ ");
                                        }else{
                                            AR = std::wstring(L" Molitove ");
                                        }
                                        break;
                                    case 602004:
                                        if(AR_language){
                                            AR = std::wstring(L" ﻪﻠﺒﻨﻗ ");
                                        }else{
                                            AR = std::wstring(L" Grenade ");
                                        }
                                        
                                        break;
                                    case 101007:
                                        AR = std::wstring(L" QBZ ");
                                        break;
                                    case 101008:
                                        AR = std::wstring(L" M762 ");
                                        break;
                                    case 101009:
                                        AR = std::wstring(L" Mk47 ");
                                        break;
                                    case 101010:
                                        AR = std::wstring(L" G36C ");
                                        break;
                                    case 101100:
                                        AR = std::wstring(L" FAMAS ");
                                        break;
                                    default:
                                        break;
                                }
                                visCol.R = 1.f;
                                visCol.G = 1.4f;
                                visCol.B = 0.5f;
                                visCol.A = 1.f;
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                DrawSmallOutlinedText(pHUD, AR, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                        }
                            if(IsSMG){
                                switch (pp) {
                                    case 102001:
                                        SM = std::wstring(L" UZI ");
                                        break;
                                    case 102002:
                                        SM = std::wstring(L" UMP45 ");
                                        break;
                                    case 102003:
                                        SM = std::wstring(L" Vector ");
                                        break;
                                    case 102004:
                                        SM = std::wstring(L" TommyGun ");
                                        break;
                                    case 102005:
                                        SM = std::wstring(L" PP-19 Bizon ");
                                        break;
                                    case 102007:
                                        SM = std::wstring(L" Skorpion ");
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 1;
                                visCol.G = 0.3;
                                visCol.B = 0.2;
                                visCol.A = 1.f;
                                DrawSmallOutlinedText(pHUD, SM, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsSniper){
                                switch (pp) {
                                    case 103001:
                                        SN = std::wstring(L" Kar98K ");
                                        break;
                                    case 103002:
                                        SN = std::wstring(L" M24 ");
                                        break;
                                    case 103003:
                                        SN = std::wstring(L" AWM ");
                                        break;
                                    case 103004:
                                        SN = std::wstring(L" SKS ");
                                        break;
                                    case 103005:
                                        SN = std::wstring(L" VSS ");
                                        break;
                                    case 103006:
                                        SN = std::wstring(L" Mini14 ");
                                        break;
                                    case 103007:
                                        SN = std::wstring(L" Mk14 ");
                                        break;
                                    case 103008:
                                        SN = std::wstring(L" Win94 ");
                                        break;
                                    case 103009:
                                        SN = std::wstring(L" SLR ");
                                        break;
                                    case 103010:
                                        SN = std::wstring(L" QBU ");
                                        break;
                                    case 103011:
                                        SN = std::wstring(L" Mosin ");
                                        break;
                                    case 103012:
                                        SN =std::wstring(L"AMR Sniper");
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 0.9f;
                                visCol.G = 2.8f;
                                visCol.B = 0.7f;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, SN, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsShotgun){
                                switch (pp) {
                                    case 103100:
                                        SH = std::wstring(L" Mk12 ");
                                        break;
                                    case 104001:
                                        SH = std::wstring(L" S686 ");
                                        break;
                                    case 104002:
                                        SH = std::wstring(L" S1897 ");
                                        break;
                                    case 104003:
                                        SH = std::wstring(L" S12K ");
                                        break;
                                    case 104004:
                                        SH = std::wstring(L" M1014 ");
                                        break;
                                    case 106006:
                                        SH = std::wstring(L" Sawed-off ");
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 1;
                                visCol.G = 1.3;
                                visCol.B = 0.4;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, SH, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsShotgun){
                                switch (pp) {
                                    case 106001:
                                        item = std::wstring(L" P1911 ");
                                        break;
                                    case 106003:
                                        item = std::wstring(L" R1895 ");
                                        break;
                                    case 106004:
                                        item = std::wstring(L" P18C ");
                                        break;
                                    case 106005:
                                        item = std::wstring(L" R45 ");
                                        break;
                                    case 106008:
                                        item = std::wstring(L" Vz61 ");
                                        break;
                                    case 106010:
                                        item = std::wstring(L" Desert Eagle ");
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 0.98f;
                                visCol.G = 1;
                                visCol.B = 1;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, item, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsShotgun){
                                switch (pp) {
                                    case 203001:
                                        if(AR_language){
                                            SCO = std::wstring(L"تﻭﺩ ﺪﻳﺭ ");
                                        }else{
                                            SCO = std::wstring(L"Red Dot");
                                        }
                                        break;
                                    case 203002:
                                        if(AR_language){
                                            SCO = std::wstring(L" ﻮﻟﻮﻫ رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"Holographic");
                                        }
                                        break;
                                    case 203003:
                                        if(AR_language){
                                            SCO = std::wstring(L" 2x رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"2x Scope");
                                        }
                                        break;
                                    case 203004:
                                        if(AR_language){
                                            SCO = std::wstring(L" 4x رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"4x Scope");
                                        }
                                        break;
                                    case 203005:
                                        if(AR_language){
                                            SCO = std::wstring(L" 8x رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"8x Scope");
                                        }
                                        break;
                                    case 203014:
                                        if(AR_language){
                                            SCO = std::wstring(L" 3x رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"3x Scope");
                                        }
                                        break;
                                    case 203015:
                                        if(AR_language){
                                            SCO = std::wstring(L" 6x رﺎﻈﻨﻣ ");
                                        }else{
                                            SCO = std::wstring(L"6x Scope");
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 1;
                                visCol.G = 0.2;
                                visCol.B = 0.4;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, SCO, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsAmmo){
                                switch (pp) {
                                    case 301001:
                                        AMMO = std::wstring(L" 9mm ");
                                        break;
                                    case 302001:
                                        AMMO = std::wstring(L" 7.62mm");
                                        break;
                                    case 303001:
                                        AMMO = std::wstring(L" 5.56mm ");
                                        break;
                                    case 304001:
                                        if(AR_language){
                                            AMMO = std::wstring(L" 12 ﻦﺟ تﻮﺷ ");
                                        }else{
                                            AMMO = std::wstring(L"12 Gauge");
                                        }
                                        break;
                                    case 305001:
                                        if(AR_language){
                                            AMMO = std::wstring(L".45 ﺾﻴﺑﺍ صﺎﺻﺭ ");
                                        }else{
                                            AMMO = std::wstring(L".45 ACP");
                                        }
                                        break;
                                    case 306001:
                                        if(AR_language){
                                            AMMO = std::wstring(L".300 مﻮﻨﻛﺎﻣ صﺎﺻﺭ ");
                                        }else{
                                            AMMO = std::wstring(L".300 Magnum");
                                        }
                                        break;
                                    case 307001:
                                        if(AR_language){
                                            AMMO = std::wstring(L" سﻮﻗ ﻢﻬﺳﺍ ");
                                        }else{
                                            AMMO = std::wstring(L"Crossbow");
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 1.63;
                                visCol.G = 1.43;
                                visCol.B = 2;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, AMMO, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsShotgun){
                                switch (pp) {
                                    case 105001:
                                        if(AR_language){
                                            OTH = std::wstring(L" ٩٤٢ ﻲﻟﺍ شﺎﺷﺭ ");
                                        }else{
                                            OTH = std::wstring(L"M249");
                                        }
                                        break;
                                    case 105002:
                                        if(AR_language){
                                            OTH = std::wstring(L" ٨٢- ﻲﺑ يﺩ ");
                                        }else{
                                            OTH = std::wstring(L"DP-28");
                                        }
                                        
                                        break;
                                    case 107001:
                                        if(AR_language){
                                            OTH = std::wstring(L" سﻮﻗ ");
                                        }else{
                                            OTH = std::wstring(L"Crossbow");
                                        }
                                        
                                        break;
                                    case 108001:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﻦﻴﻜﺳ");
                                        }else{
                                            OTH = std::wstring(L"Machete");
                                        }
                                        
                                        break;
                                    case 108002:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﻠﺘﻋ ﺾﻴﺑﺍ حﻼﺳ ");
                                        }else{
                                            OTH = std::wstring(L"Crowbar");
                                        }
                                        
                                        break;
                                    case 108003:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﻞﺠﻨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Sickle");
                                        }
                                        break;
                                    case 108004:
                                        if(AR_language){
                                            OTH = std::wstring(L" ةﻼﻘﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Pan");
                                        }
                                        break;
                                    case 201001:
                                        if(AR_language){
                                            OTH = std::wstring(L"Choke");//?
                                        }else{
                                            OTH = std::wstring(L"Choke");
                                        }
                                        break;
                                        //         ATTCHMENT
                                    case 201002:
                                        if(AR_language){
                                            OTH = std::wstring(L"AR ضﻮﻌﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Compensator (AR)");
                                        }
                                        break;
                                    case 201003:
                                        if(AR_language){
                                            OTH = std::wstring(L" DMR ﺔﺻﺎﻨﻘﻠﻟ ﻒﺜﻜﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Muzzle Brake (DMR)");
                                        }
                                        break;
                                    case 201004:
                                        if(AR_language){
                                            OTH = std::wstring(L"سﺪﺴﻣ - ﺾﻴﻣﻭ ءﺎﻔﺧﺃ");
                                        }else{
                                            OTH = std::wstring(L"Flash Hider (Pistol)");
                                        }
                                        break;
                                    case 201005:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﺔﺻﺎﻨﻘﻠﻟ ﺾﻴﻣﻭ ءﺎﻔﺧﺍ ");
                                        }else{
                                            OTH = std::wstring(L"Flash Hider (DMR)");
                                        }
                                        // ---
                                        break;
                                    case 201006:
                                        if(AR_language){
                                            OTH = std::wstring(L"GMS تﻮﺻ ﻢﺗﺎﻛ");
                                        }else{
                                            OTH = std::wstring(L"Suppressor (SMG)");
                                        }
                                        
                                        break;
                                    case 201007:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﺻﺎﻨﻘﻠﻟ تﻮﺻ ﻢﺗﺎﻛ ");
                                        }else{
                                            OTH = std::wstring(L"Suppressor (Snipers)");
                                        }
                                        break;
                                    case 201009:
                                        if(AR_language){
                                            OTH = std::wstring(L"RA ﻒﺜﻜﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Compensator (AR) ");
                                        }
                                        break;
                                    case 201010:
                                        if(AR_language){
                                            OTH = std::wstring(L"RA ﺾﻴﻣﻭ ءﺎﻔﺧﺍ ");
                                        }else{
                                            OTH = std::wstring(L"Flash Hider (AR)");
                                        }
                                        break;
                                    case 201011:
                                        if(AR_language){
                                            OTH = std::wstring(L" RA تﻮﺻ ﻢﺗﺎﻛ ");
                                        }else{
                                            OTH = std::wstring(L"Suppressor (AR) ");
                                        }
                                        break;
                                    case 201012:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﻂﺒﻟﺍ رﺎﻘﻨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Duckbill");//
                                        }
                                        break;
                                    case 202001:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﻳﻭﺍﺯ ﺔﻀﺒﻗ");
                                        }else{
                                            OTH = std::wstring(L"Angled Foregrip (AR)");
                                        }
                                        break;
                                    case 202002:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﻪﻳﺩﻮﻣﺎﻋ ﺔﻀﺒﻗ ");
                                        }else{
                                            OTH = std::wstring(L"Vertical Foregrip");
                                        }
                                        break;
                                    case 202004:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺖﻳﻻ هﺮﻴﻐﺻ ﺔﻀﺒﻗ ");
                                        }else{
                                            OTH = std::wstring(L"Light Grip");
                                        }
                                        break;
                                    case 202005:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﺔﻀﺒﻗ ﻒﺼﻧ  ");
                                        }else{
                                            OTH = std::wstring(L"Half Grip");
                                        }
                                        break;
                                    case 202006:
                                        if(AR_language){
                                            OTH = std::wstring(L"مﺎﻬﺑﺍ ﺔﻀﺒﻗ ");
                                        }else{
                                            OTH = std::wstring(L"Thumb Grip");
                                        }
                                        break;
                                    case 202007:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﻲﺒﻧﺎﺟ رﺰﻴﻟ ");
                                        }else{
                                            OTH = std::wstring(L"Laser Sight");
                                        }
                                        break;
                                        //         SCOPE
                                        //         ATTCHMENT
                                    case 203018:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﻲﺒﻧﺎﺟ رﺎﻈﻨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Canted Sight");
                                        }
                                        break;
                                    case 204014:
                                        if(AR_language){
                                            OTH = std::wstring(L"صﺎﺻﺮﻟﺍ ﻞﻣﺎﺣ ");
                                        }else{
                                            OTH = std::wstring(L"Bullet Loop");
                                        }
                                        break;
                                    case 205001:
                                        if(AR_language){
                                            OTH = std::wstring(L" يﺯﻮﻴﻟﺍ حﻼﺳ ﻪﻳﺎﻣﺭ ﺪﻨﺴﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Stock (Micro UZI)");
                                        }
                                        break;
                                    case 205002:
                                        if(AR_language){
                                            OTH = std::wstring(L" يﺩﺎﻌﻟﺍﻭ ﻲﻟﻻﺍ شﺎﺷﺮﻠﻟ ﻪﻳﺎﻣﺭ ﺪﻨﺴﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Tactical Stock (Rifles, SMG)");
                                        }
                                        break;
                                    case 205003:
                                        if(AR_language){
                                            OTH = std::wstring(L"   )ﻪﺻﺎﻨﻗ(  ﻪﻳﺎﻣﺭ ﺪﻨﺴﻣ ");
                                            
                                        }else{
                                            OTH = std::wstring(L"Cheek Pad (Snipers)");
                                        }
                                        break;
                                    case 205004:
                                        if(AR_language){
                                            OTH = std::wstring(L"  )سﻮﻗ(  ﻊﺳﻮﻣ نﺰﺨﻣ");
                                        }else{
                                            OTH = std::wstring(L"Quiver (Crossbow)");
                                        }
                                        break;
                                    case 204004:
                                        if(AR_language){
                                            OTH = std::wstring(L"  )slotsiP ,GMS(  ﻊﺳﻮﻣ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Extended Mag (SMG, Pistols)");
                                        }
                                        break;
                                    case 204005:
                                        if(AR_language){
                                            OTH = std::wstring(L" )slotsiP ,GMS(  ﻊﻳﺮﺳ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Quickdraw Mag (SMG, Pistols)");
                                        }
                                        break;
                                    case 204006:
                                        if(AR_language){
                                            OTH = std::wstring(L" )slotsiP ,GMS(  ﻊﺳﻮﻣ ﻊﻳﺮﺳ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Extended Quickdraw Mag (SMG, Pistols)");
                                        }
                                        break;
                                    case 204007:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﺻﺎﻨﻘﻠﻟ  ﻊﺳﻮﻣ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Extended Mag (Snipers)");
                                        }
                                        break;
                                    case 204008:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﺻﺎﻨﻘﻠﻟ  ﻊﻳﺮﺳ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Quickdraw Mag (Snipers)");
                                        }
                                        break;
                                    case 204009:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﺔﺻﺎﻨﻘﻠﻟ  ﻊﺳﻮﻣ ﻊﻳﺮﺳ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Extended Quickdraw Mag (Snipers)");
                                        }
                                        break;
                                    case 204011:
                                        if(AR_language){
                                            OTH = std::wstring(L"RA  ﻊﺳﻮﻣ نﺰﺨﻣ");
                                        }else{
                                            OTH = std::wstring(L"Extended Quickdraw Mag (AR) ");
                                        }
                                        break;
                                    case 204012:
                                        if(AR_language){
                                            OTH = std::wstring(L" RA ﻊﻳﺮﺳ نﺰﺨﻣ");
                                        }else{
                                            OTH = std::wstring(L"Quickdraw Mag (AR)");
                                        }
                                        break;
                                    case 204013:
                                        if(AR_language){
                                            OTH = std::wstring(L" RA ﻊﺳﻮﻣ ﻊﻳﺮﺳ نﺰﺨﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Extended Quickdraw Mag (AR)");
                                        }
                                        break;
                                        //         AMMO
                                    case 601001:
                                        if(AR_language){
                                            OTH = std::wstring(L" ﺔﻗﺎﻃ بﻭﺮﺸﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Energy Drink");
                                        }
                                        break;
                                    case 601002:
                                        if(AR_language){
                                            OTH = std::wstring(L"جﻼﻋ ﻪﻨﻘﺣ ");
                                        }else{
                                            OTH = std::wstring(L"Syringe");
                                        }
                                        break;
                                    case 601003:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﻦﻜﺴﻣ ");
                                        }else{
                                            OTH = std::wstring(L"Painkiller");
                                        }
                                        break;
                                    case 601004:
                                        if(AR_language){
                                            OTH = std::wstring(L"جﺪﻧﺎﺑ ");
                                        }else{
                                            OTH = std::wstring(L"Bandage");
                                        }
                                        break;
                                    case 601005:
                                        if(AR_language){
                                            OTH = std::wstring(L"ﺔﻴﻟﻭﺍ جﻼﻋ ﺔﺒﻴﻘﺣ ");
                                        }else{
                                            OTH = std::wstring(L"First Aid Kit");
                                        }
                                        break;
                                    case 601006:
                                        if(AR_language){
                                            OTH = std::wstring(L"جﻼﻋ ﺔﺒﻴﻘﺣ ");
                                        }else{
                                            OTH = std::wstring(L"Med Kit");
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                visCol.R = 0.2;
                                visCol.G = 1;
                                visCol.B = 0.7;
                                visCol.A = 1;
                                DrawSmallOutlinedText(pHUD, OTH, { itemPos.X,itemPos.Y}, visCol, COLOR_BLACK);
                            }
                            if(IsShotgun){
                                if(AR_language){
                                    switch (pp) {
                                        case 501001:
                                            ARM = std::wstring(L" ١ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                            break;
                                        case 501002:
                                            ARM = std::wstring(L"٢ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                            break;
                                        case 501006:
                                            ARM = std::wstring(L" ٣ ىﻮﺘﺴﻣ ﺔﺒﻴﻘﺣ ");
                                            break;
                                        case 502001:
                                            ARM = std::wstring(L" ٢ ىﻮﺘﺴﻣ هﺫﻮﺧ ");
                                            break;
                                        case 502002:
                                            ARM = std::wstring(L"٣ ىﻮﺘﺴﻣ هﺫﻮﺧ");
                                            break;
                                        case 502003:
                                            ARM = std::wstring(L" ٣ ىﻮﺘﺴﻣ هﺫﻮﺧ");
                                            break;
                                        case 503001:
                                            ARM = std::wstring(L"١ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                            break;
                                        case 503002:
                                            ARM = std::wstring(L"٢ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                            break;
                                        case 503003:
                                            ARM = std::wstring(L"٣ ىﻮﺘﺴﻣ ﻪﻃﺮﺷ ﺔﻳﺭﺪﺻ ");
                                            break;
                                        default:
                                            break;
                                    }
                                }else{
                                    switch (pp) {
                                        case 501001:
                                            ARM = std::wstring(L" Backpack (Lv. 1) ");
                                            break;
                                        case 501002:
                                            ARM = std::wstring(L" Backpack (Lv. 2) ");
                                            break;
                                        case 501006:
                                            ARM = std::wstring(L" Backpack (Lv. 3) ");
                                            break;
                                        case 502001:
                                            ARM = std::wstring(L" Helmet LV1 ");
                                            break;
                                        case 502002:
                                            ARM = std::wstring(L" Helmet LV2");
                                            break;
                                        case 502003:
                                            ARM = std::wstring(L" Helmet LV3 ");
                                            
                                            break;
                                        case 503001:
                                            ARM = std::wstring(L"Armor LV1 ");
                                            break;
                                        case 503002:
                                            ARM = std::wstring(L"Armor LV2 ");
                                            break;
                                        case 503003:
                                            ARM = std::wstring(L"Armor LV3 ");
                                            break;
                                        default:
                                            break;
                                    }
                                }
                               
                                robotoTinyFont->LegacyFontSize = max(EspTextSiz, 13 - (int) (Distance / 100));//5
                                DrawSmallOutlinedText(pHUD, ARM, { itemPos.X,itemPos.Y}, COLOR_LIME, COLOR_BLACK);
                            }
                        }
                    }
                }
            }ITEMM.clear();
        }
        {
            std::vector<ASTExtraVehicleBase*> ITS;
            GetAllActors(ITS);
            for (auto actor = ITS.begin(); actor != ITS.end(); actor++) {
                auto Vehicle = *actor;
                if (!Vehicle->Mesh)
                    continue;
                auto vv = Vehicle->VehicleShapeType;
                float Distance = Vehicle->GetDistanceTo(localPlayer) / 100.f;
                FVector2D vehiclePos;
                auto ROOT  =Vehicle->K2_GetActorLocation();
                ROOT.Z -=50;
                if (Distance > 10 && Distance <= 600) {
                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController,ROOT, true, &vehiclePos)) {
                        std::wstring veh;
                        switch (vv) {
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike_SideCart:
                                if(AR_language){
                                    veh = std::wstring(L"ﺔﺟﺍﺭﺩ");
                                    
                                }else{
                                    veh = std::wstring(L"Motorbike");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Dacia:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyDacia:
                                if(AR_language){
                                    veh = std::wstring(L"ﺎﻴﺳﺍﺩ");
                                }else{
                                    veh = std::wstring(L"Dacia");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MiniBus:
                                if(AR_language){
                                    veh = std::wstring(L" ﺮﻴﻐﺻ صﺎﺑ");
                                }else{
                                    veh = std::wstring(L"MiniBus");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp01:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyPickup:
                                if(AR_language){
                                    veh = std::wstring(L" بﺍ ﻚﻴﺑ");
                                }else{
                                    veh = std::wstring(L"PickUp");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Buggy:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyBuggy:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲَﻜﺑ");
                                }else{
                                    veh = std::wstring(L"Buggy");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ01:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ02:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ03:
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUAZ:
                                if(AR_language){
                                    veh = std::wstring(L"زﺍﻭ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"UAZ");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PG117:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﺋﺎﻣ قﺭﻭﺯ");
                                }else{
                                    veh = std::wstring(L"Watercraft PG117");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Aquarail:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﺋﺎﻣ ﺮﺗﻮﻜﺳ");
                                }else{
                                    veh = std::wstring(L"Aquarail");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado:
                                if(AR_language){
                                    veh = std::wstring(L"وﺩﺍﺮﻴﻣ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Mirado");
                                }
                                
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado01:
                                if(AR_language){
                                    veh = std::wstring(L"وﺩﺍﺮﻴﻣ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Mirado");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Rony:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﻧﻭﺭ بﺍ ﻚﻴﺑ");
                                }else{
                                    veh = std::wstring(L"Rony pickup");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Scooter:
                                if(AR_language){
                                    veh = std::wstring(L"ﺮﺗﻮﻜﺳ");
                                }else{
                                    veh = std::wstring(L"Scooter");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowMobile:
                                if(AR_language){
                                    veh = std::wstring(L" ﻪﻴﺠﻠﺛ ﺔﺟﺍﺭﺩ");
                                }else{
                                    veh = std::wstring(L"SnowMobile");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_TukTukTuk:
                                if(AR_language){
                                    veh = std::wstring(L"ﻚﺗ ﻚﺗ");
                                }else{
                                    veh = std::wstring(L"TukTuk");
                                }
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowBike:
                                if(AR_language){
                                    veh = std::wstring(L" ﻪﻴﺠﻠﺛ ﺔﺟﺍﺭﺩ");
                                }else{
                                    veh = std::wstring(L"SnowBike");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Surfboard:
                                if(AR_language){
                                    veh = std::wstring(L"ﻪﺠﻤﻛﺮﻟﺍ حﻮﻟ");
                                }else{
                                    veh = std::wstring(L"Surfboard");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Snowboard:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﺠﻠﺛ ﺮﻴﻐﺻ قﺭﻭﺯ");
                                }else{
                                    veh = std::wstring(L"Snowboard");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Amphibious:
                                if(AR_language){
                                    veh = std::wstring(L"ﻪﻴﺋﺎﻣﺮﺑ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Amphibious");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_LadaNiva:
                                if(AR_language){
                                    veh = std::wstring(L"ﺎﻔﻴﻧ اﺩﻻ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Lada Niva");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAV:
                                if(AR_language){
                                    veh = std::wstring(L"ةﺮﻴﺴﻣ هﺮﺋﺎﻃ");
                                }else{
                                    veh = std::wstring(L"Drone");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MegaDrop:
                                if(AR_language){
                                    veh = std::wstring(L"ﺮﻴﺒﻛ بﻭﺭﺩ");
                                }else{
                                    veh = std::wstring(L"MegaDrop");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﻨﻴﻏﺭﻮﺒﻣﻻ");
                                }else{
                                    veh = std::wstring(L"Lamborghini");
                                }
                                
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini01:
                                if(AR_language){
                                    veh = std::wstring(L"ﻲﻨﻴﻏﺭﻮﺒﻣﻻ");
                                }else{
                                    veh = std::wstring(L"Lamborghini 01");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_GoldMirado:
                                if(AR_language){
                                    veh = std::wstring(L" ﻪﻴﺒﻫﺫ ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"GoldMirado");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_BigFoot:
                                if(AR_language){
                                    veh = std::wstring(L"ةﺮﻴﺒﻛ مﺪﻗ");
                                }else{
                                    veh = std::wstring(L"BigFoot");
                                }
                                
                                break;
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UH60:
                                if(AR_language){
                                    veh = std::wstring(L"ﺔﻴﺣﻭﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Helicopter UH60");
                                }
                                
                            case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUH60:
                                if(AR_language){
                                    veh = std::wstring(L"ﺔﻴﺣﻭﺮﻣ");
                                }else{
                                    veh = std::wstring(L"Helicopter Heavy-UH60");
                                }
                                break;
                            default:
                                if(AR_language){
                                    veh = std::wstring(L"ﺔﺒﻛﺮﻣ");
                                }else{
                                    veh = std::wstring(L"");
                                }
                                break;
                        }
                        veh += std::wstring(L" [");
                        veh += std::to_wstring((int) Distance);
                        veh += std::wstring(L"m]");
                        if(IsVehcle){
                            visCol.A =1.f;
                            visCol.B =0.6f;
                            visCol.G =0.8f;
                            visCol.R =1.f;
                            tslFont->LegacyFontSize = max(3, 14 - (int) (Distance / 100));
                            DrawSmallOutlinedText(pHUD, veh, { vehiclePos.X,vehiclePos.Y}, visCol, COLOR_BLACK);
                        }
                        if(IsboxVechle){
                            FVector Bounds, b2;
                            Bounds = CHUTIA(Vehicle);
                            Vehicle->GetActorBounds(true, &Bounds, &b2);
                            DrawBox3D(pHUD, Vehicle, allColors::LightGoldenrodYellow, Bounds, b2);
                        }
                        auto vhebase = Vehicle->VehicleCommon;
                        float CurHP = std::max(0.f, std::min(vhebase->HP, vhebase->HPMax));
                        float CurFEL = std::max(0.f, std::min(vhebase->Fuel, vhebase->FuelMax));
                        float MAXHEL = vhebase->HPMax;
                        float MaxFEL = vhebase->FuelMax;
                        FLinearColor ColorFEL = {
                            std::min(((310.f * (MaxFEL - CurFEL)) / MaxFEL) / 155.f, 3.f),
                            std::min(((310.f * CurFEL) / MaxFEL) / 155.f, 3.f),
                            0.f,
                            0.5f
                        };
                        FLinearColor ColorHP = {
                            std::min(((510.f * (MAXHEL - CurHP)) / MAXHEL) / 255.f, 1.f),
                            std::min(((510.f * CurHP) / MAXHEL) / 255.f, 1.f),
                            0.f,
                            0.5f
                        };
                        auto AboveHead = Vehicle->K2_GetActorLocation();
                        AboveHead.Z += 60;
                        FVector2D AboveHeadSc;
                        if (gGameplayStatics->ProjectWorldToScreen(localPlayerController,AboveHead, true, &AboveHeadSc))  {
                            auto mWidthScale = std::min(0.1f * Distance, 12.f);
                            auto mWidth = 75.f - mWidthScale;
                            auto mHeight = mWidth * 0.175f;
                            AboveHeadSc.X -= (mWidth / 2);
                            AboveHeadSc.Y -= (mHeight * 1.5f);
                            visCol.A=1.0f;
                            visCol.B=0.5f;
                            visCol.G=1.2f;
                            visCol.R =1.f;
                            if(IsCarHP){
                                tslFont->LegacyFontSize = max(2, 12 - (int) (Distance / 100));
                                DrawFilledRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, (CurHP * mWidth / MAXHEL ), 6, ColorHP);
                                DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth, 6, 1.0f, {0, 0, 0, 1.f});
                            }
                            if(IsCarFuel){
                                AboveHeadSc.Y -=20;
                                tslFont->LegacyFontSize = max(2, 12 - (int) (Distance / 100));
                                DrawFilledRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, (CurFEL * mWidth / MaxFEL), 6, visCol);
                                DrawRectangle(pHUD, {AboveHeadSc.X, AboveHeadSc.Y}, mWidth, 6, 1.0f, {0, 0, 0, 1.f});
                            }
                        }
                    }
                }
            }ITS.clear();
        }
        if (IsFov) {
            DrawCircle(pHUD->Canvas, ScreenWidth/2, ScreenHeight/2, add(), 10, COLOR_RED);
        }
    }
    UGameplayStatics* gGameplayStatics = (UGameplayStatics*)UGameplayStatics::StaticClass();
    if (IsGRWAR)
    {
        std::vector < ASTExtraGrenadeBase * >GrenadeBase;
        GetAllActors(GrenadeBase);
        for (auto actor = GrenadeBase.begin();
             actor != GrenadeBase.end(); actor++)
        {

            auto Grenade = *actor;
            if(Grenade) {
                if(Grenade->ItemDefineID.TypeSpecificID ==602002)
                    continue;
                if(Grenade->ItemDefineID.TypeSpecificID == 602004);
                auto RootComponent = Grenade->RootComponent;
                if (RootComponent) {
                    float gDistance =
                    Grenade->GetDistanceTo(localPlayer) /100.f;
                    if (gDistance <= 200.f)
                    {
                       // ImDrawList *draw = ImGui::GetForegroundDrawList();
                        tslFont->LegacyFontSize =
                        max(6, 15 - (int)(gDistance / 100.f));
                        float txtWidth, txtHeight;
//                        std::wstring grenadetext = (L"<Grenade>");
                        std::wstring grenadetext = (L"<DAMAGE DAMAGE>");
                        if(AR_language){
                            std::wstring grenadetext = (L"ﻪﻠﺒﻨﻗ ");
                        }
                        pHUD->GetTextSize(grenadetext,
                                          tslFont, 1.f, &txtWidth,
                                          &txtHeight);
                        FVector2D Location;
                        if (W2S
                            (RootComponent->RelativeLocation, &Location))
                        {
                            DrawOutlinedText(pHUD,
                                             FString(
                                                     grenadetext),
                                             FVector2D(Location.X,
                                                       Location.Y + 34),COLOR_RED, COLOR_BLACK, true);
                        }
;
//                                                        }
                        tslFont->LegacyFontSize = TSL_FONT_DEFAULT_SIZE;
                        if (gDistance < 13)
                        {
                           
                            std::wstring gwarn;
//                            gwarn = std::wstring(L"MOVE, MOVE, MOVE!");//iAwareTexSiz
                            gwarn = std::wstring(L"WARNING! BOOM WILL FUCK YOU ASS!");//iAwareTexSiz
                       
                            if(AR_language){
                                gwarn = std::wstring(L"كﺮﺤﺗ, كﺮﺤﺗ , كﺮﺤﺗ !");
                            }
                            tslFont->LegacyFontSize = 92 + iAwareTexSiz;
                            DrawOutlinedText(pHUD, FString(gwarn),
                                             FVector2D(screenWidth / 2,
                                                       screenHeight / 2),
                                             COLOR_RED, COLOR_BLACK, true);
                            tslFont->LegacyFontSize =
                            TSL_FONT_DEFAULT_SIZE;
                           
                            
                            
                        }//
                        {
                            

                            ImDrawList* draw;
               
                            FVector2D Cross;
                            
                            Cross.X = 890.0f;
                            Cross.Y = 840.0f; // Front
//                            Cross.Z = 3.0f; // Height
                            FVector bbOrigin =
                            RootComponent->RelativeLocation;
                            FVector bbExtends(700, 700, 3);
                            FVector bbExtends2(10, 10, 3);
                            FVector bbOrigin2 =
                            RootComponent->RelativeLocation;
                            bbOrigin -= bbExtends / 2;
                            bbOrigin2 -= bbExtends2 / 2;
                            // bottom plane
//                            FVector grenadePos = bbOrigin;
                            FVector one = bbOrigin;
                            FVector two = bbOrigin;
                            FVector giua = bbOrigin2;
                            two.X += bbExtends.X;
                            giua.X += bbExtends2.X;
                            FVector three = bbOrigin;
                            three.X += bbExtends.X;
                            three.Y += bbExtends.Y;
                            FVector four = bbOrigin;
                            four.Y += bbExtends.Y;
                            FVector five = one;
                            five.Z += bbExtends.Z;
                            FVector six = two;
                            FVector six2 = giua;
                            six.Z += bbExtends.Z;
                            six2.Z += bbExtends2.Z;
                            FVector seven = three;
                            seven.Z += bbExtends.Z;
                            FVector eight = four;
                            eight.Z += bbExtends.Z;
                            FVector2D s1, s2, s3, s4, s5, s6, s7, s8, sgiua;
                            FVector2D grenadePos;
                            if (W2S(one, &s1) && W2S(two, &s2)
                                && W2S(three, &s3) && W2S(four, &s4)
                                && W2S(five, &s5) && W2S(six, &s6)
                                && W2S(seven, &s7) && W2S(eight, &s8) && W2S(giua, &sgiua) && W2S(Grenade->K2_GetActorLocation(), &grenadePos))
                            {
                                pHUD->Canvas->K2_DrawLine(Cross, sgiua, 2.3f, COLOR_YELLOW);
                                DrawLine(pHUD, s1, s2, 1.3f, COLOR_RED);
                                                                DrawLine(pHUD, s2, s3,1.3f, COLOR_RED);
                                                            DrawLine(pHUD, s3, s4, 1.3f, COLOR_RED);
                                                                DrawLine(pHUD, s4, s1, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s5, s6, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s6, s7, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s7, s8,1.3f, COLOR_RED);
                                DrawLine(pHUD, s8, s5, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s1, s5, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s2, s6, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s3, s7, 1.3f, COLOR_RED);
                                DrawLine(pHUD, s4, s8, 1.3f, COLOR_RED);
                             

                                Circle3D(draw, Grenade->K2_GetActorLocation(), 720, ImColor(0, 255, 255, 255), 5);
                            
                            }
                            
                            
                            
                        }
                    }
                }
            }
        }
        GrenadeBase.clear();
    }
    
    if (thongtin)
    {
       
        std::vector < ASTExtraGameStateBase * >ingame;
        std::vector < UGameLevelManagerComponent * >cheat;
        GetAllActors(ingame);
        for (auto actor = ingame.begin();
             actor != ingame.end(); actor++)
        {
            

            auto ingame = *actor;
            auto game = *actor;
            auto cheat = *actor;
            std::string s;
         
        
       

            s += " Match Information: ";
            s += "\n My Team: ";
            s += std::to_string((int) ingame->PlayerNumPerTeam);
            s += "\n Team Remaining: ";
            s += std::to_string(ingame->AliveTeamNum);
            s += "\n Player Alive: ";
            s += std::to_string(game->AlivePlayerNum);
            s += "\n Real Player: ";
            s += std::to_string(game->PlayerNum);
            s += "\n Total Number of Teams: ";
s += std::to_string(game->PlayerNumPerTeam);
s += "\n Time match  : ";
//            s += std::to_string((int) game->ElapsedTime);
//            s += "s | ";
            s += std::to_string((int) game->ElapsedTime / 60);
            s += " Minutes";
            tslFont->LegacyFontSize = 15;
            DrawText(pHUD, FString(s),
                             FVector2D(screenWidth / 2 - 650,
                                       screenHeight / 2),
                             COLOR_WHITE, true);
            tslFont->LegacyFontSize = 15;
            
        } ingame.clear();
        
    }
    
g_LocalPlayer = localPlayer;
    g_PlayerController = localPlayerController;
    
    
}

//void ASTExtraGameStateBase::OnGameEnd()
//{
//    // Thực hiện hành động khi game kết thúc
//}

//void UAutoTestSubsystem::OnGameStart(){
//        ESPGAME =false;
//
//    }
//    void OnGameEnd() {
//        ESPGAME =true;
//
//    }


void RenderFText( UHUDWidgetBase *U_HUDWidgetBase) {
    
}

std::wstring NStoWS ( NSString* Str )
{
    NSStringEncoding pEncode    =   CFStringConvertEncodingToNSStringEncoding ( kCFStringEncodingUTF32LE );
    NSData* pSData              =   [ Str dataUsingEncoding : pEncode ];
    return std::wstring ( (wchar_t*) [ pSData bytes ], [ pSData length] / sizeof ( wchar_t ) );
}
//from wstring to NSString
NSString* WStoNS ( const std::wstring& Str )
{
    NSString* pString = [ [ NSString alloc ]
                          initWithBytes : (char*)Str.data()
                          length : Str.size() * sizeof(wchar_t)
                          encoding : CFStringConvertEncodingToNSStringEncoding ( kCFStringEncodingUTF32LE ) ];
    return pString;
}
void *(*oProcessEvent)(UObject *pObj, UFunction *pFunc, void *pArgs);
void *hkProcessEvent(UObject *pObj, UFunction *pFunc, void *pArgs) {
    if (pFunc) {
        if (pFunc->GetFullName() == XorEnc("Function Engine.HUD.ReceiveDrawHUD") ){
            AHUD *pHUD = (AHUD *) pObj;
            if (pHUD) {
                auto Params = (AHUD_ReceiveDrawHUD_Params *) pArgs;
                if (Params) {
                    RenderESP(pHUD, Params->SizeX, Params->SizeY);
                    g_screenWidth = Params->SizeX;
                    g_screenHeight = Params->SizeY;
                }
            }
        }
        // renderFText
        //UHUDWidgetBase
        if (pFunc->GetFullName() == XorEnc("Function ShadowTrackerExtra.HUDWidgetBase.ShouldDraw") ){
            UHUDWidgetBase *U_HUDWidgetBase = (UHUDWidgetBase *) pObj;
            if (U_HUDWidgetBase) {
                auto Params = (UHUDWidgetBase_DrawText_Params *) pArgs;//UHUDWidgetBase_ShouldDraw_Params
                if (Params) {
                    //  NSLog(@"yes there are Fun");
                    RenderFText(U_HUDWidgetBase);
                }else{
                    // NSLog(@"no function 3");
                }
            }else{
                //NSLog(@"no function 2");
            }
        }else{
            //NSLog(@"no function 1");
            std::string funName = pFunc->GetFullName();
            NSString *NSFunName = [NSString stringWithCString:funName.c_str()
                                                     encoding:[NSString defaultCStringEncoding]];
            //NSLog(@"FunName: %@",NSFunName);
        }

    }
    
    
    return oProcessEvent(pObj, pFunc, pArgs);
}
static PubgLoad *instance = nil;
+ (PubgLoad *)getInstance
{
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            instance = [[self alloc] init];
        });
    
    
    return instance;
}
int setPageProtection(uintptr_t target, int protection) {
    void *start = reinterpret_cast<void *>(target & -PAGE_SIZE);
    return mprotect(start, PAGE_SIZE, protection);
}
void  *RTL_language(){
   
        auto MAIN =(FUObjectArray *) (obbbbl());
        auto gobjects = MAIN->ObjObjects;
        for (int i=0;i< gobjects.Num(); i++)
            if (auto obj = gobjects.GetByIndex(i)) {
                if(obj->IsA(AHUD::StaticClass())) {
                    auto HUD = (AHUD *) obj;
                    //const char * tt1 = L"75";
                    int its = IntEnc("75");
                
                    auto VTable = (void**)HUD->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                if(obj->IsA(USTExtraShootWeaponComponent::StaticClass())) {
                    auto wep = (USTExtraShootWeaponComponent *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                if(obj->IsA(ASTExtraShootWeapon::StaticClass())) {
                    auto wep = (ASTExtraShootWeapon *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                if(obj->IsA(UDestructibleComponent::StaticClass())) {
                    auto wep = (UDestructibleComponent *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                if(obj->IsA(UMovementComponent::StaticClass())) {
                    auto wep = (UMovementComponent *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                //
                if(obj->IsA(ASurviveHUD::StaticClass())) {
                    auto wep = (ASurviveHUD *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
                
                if(obj->IsA(UHUDWidgetBase::StaticClass())) {
                    auto wep = (UHUDWidgetBase *) obj;
                    int its =IntEnc("75");
                    auto VTable = (void**)wep->VTable;
                    if (VTable && ( VTable[its] != hkProcessEvent)) {
                        oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                        VTable[its] = (void *) hkProcessEvent;
                    }
                }
          


                
            }
        
    
    return 0;
}

__attribute__((constructor)) static void initialize() {

    pthread_t silenceeffectDCThread;
    pthread_create(&silenceeffectDCThread, NULL, effect , NULL);
    
    pthread_t silenceskinDCThread;
    pthread_create(&silenceskinDCThread, NULL, skin , NULL);
    
    pthread_t silencersskinDCThread;
    pthread_create(&silencersskinDCThread, NULL, rsskin , NULL);
    
    pthread_t silencexsuitttDCThread;
    pthread_create(&silencexsuitttDCThread, NULL, xsuittt , NULL);
    
   
    
}
void *xsuittt(void *) {
    usleep(1666);
    while (true) {
        
        if(thanhgiap2){
            if(trangphuc){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 403003;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1405628;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
  
                        
                    }
                    
                });
            }
        }
    }
    
    return 0;
}
 
void *effect(void *) {
    usleep(1666);
    while (true) {
//        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
     
        if(skinm41){
            
            if(effectm4){
               
                    
//                dispatch_async(dispatch_get_global_queue(0, 0), ^{
//
//                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 101004;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                        SInt32 search1 = 65537;
                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 1101004046;
                        SInt32 modifyAllResults = 1101004046;
                        for(int i = 20;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
//                    });
//                });
                }}
        
        if(skinm47){
            if(effectm4){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 101004;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 65537;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004201;
                    SInt32 modifyAllResults = 1101004201;
                    for(int i = 1;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
        }
//        auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
//               std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
    }
    return 0;
}

void *skin(void *) {
    usleep(1666);
    while (true) {
        
        if(skinm41) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004046;
                    SInt32 modifyAllResults = 1101004046;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040463;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040461;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040462;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            
        }
        
        
        
        if(skinm42) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004062;
                    SInt32 modifyAllResults = 1101004062;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040623;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040621;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040622;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
          
        }
        
        
        if(skinm43) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004086;
                    SInt32 modifyAllResults = 1101004086;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040863;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040861;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040862;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
        }
            
            if(skinm44) {
                if(skinsung){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 10100400;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                        SInt32 search1 = 8404;
                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 1101004078;
                        SInt32 modifyAllResults = 1101004078;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                
                if(skinsung){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 20500500;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 1010040783;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(skinsung){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 29100400;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 1010040781;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(skinsung){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 20300800;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 1010040782;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
        }
        if(skinm45) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004098;
                    SInt32 modifyAllResults = 1101004098;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040983;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040981;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010040982;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
    }
        
        if(skinm46) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004163;
                    SInt32 modifyAllResults = 1101004163;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041633;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041631;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041632;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
    }
        
        if(skinm47) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004201;
                    SInt32 modifyAllResults = 1101004201;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010042013;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010042011;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010042012;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
    }
        if(skinm48) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 10100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8404;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101004138;
                    SInt32 modifyAllResults = 1101004138;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                });
                
            }
            
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20500500;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041383;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 29100400;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041381;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 20300800;
                    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1010041382;
                    for(int i = 0;i < results.size();i++){
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        
                        
                    }
                    
                });
                
            }
        }
        if(akm1) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x100000000,0x200000000};
                    SInt32 search = 101001;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8401;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 1101001089;
                    //AK BĂNG
                    SInt32 modifyAllResults = 1101001089;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                        
                    }
                });
            }
        }
            
                if(akm2) {
                    if(skinsung){
                        static dispatch_once_t onceToken;
                        dispatch_once(&onceToken, ^{
                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                            int32_t search = 10100100;
                            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                            SInt32 search1 = 8401;
                            engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                            
                            vector<void*>results = engine.getAllResults();
                            int32_t  modify = 1101001103;
                            SInt32 modifyAllResults = 1101001103;
                            for(int i = 0;i < results.size();i++){
                                if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                
                                
                            }
                            
                        });
                    }
                }
                
                    if(akm3) {
                        if(skinsung){
                            static dispatch_once_t onceToken;
                            dispatch_once(&onceToken, ^{
                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                int32_t search = 10100100;
                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                SInt32 search1 = 8401;
                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                
                                vector<void*>results = engine.getAllResults();
                                int32_t  modify = 1101001116;
                                SInt32 modifyAllResults = 1101001116;
                                for(int i = 0;i < results.size();i++){
                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                    
                                    
                                }
                                
                            });
                            
                        }
                    }
                    
                        if(akm4) {
                            if(skinsung){
                                static dispatch_once_t onceToken;
                                dispatch_once(&onceToken, ^{
                                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                                    int32_t search = 10100100;
                                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                    SInt32 search1 = 8401;
                                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                    
                                    vector<void*>results = engine.getAllResults();
                                    int32_t  modify = 1101001128;
                                    SInt32 modifyAllResults = 1101001128;
                                    for(int i = 0;i < results.size();i++){
                                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                        
                                    }
                                });
                                
                            }
                        }
                       
                            if(akm5) {
                                if(skinsung){
                                    static dispatch_once_t onceToken;
                                    dispatch_once(&onceToken, ^{
                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                                        int32_t search = 10100100;
                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                        SInt32 search1 = 8401;
                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                        
                                        vector<void*>results = engine.getAllResults();
                                        int32_t  modify = 1101001143;
                                        SInt32 modifyAllResults = 1101001143;
                                        for(int i = 0;i < results.size();i++){
                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                            
                                            
                                        }
                                    });
                                    
                                }
                            }
                        
                            if(akm6) {
                                if(skinsung){
                                    static dispatch_once_t onceToken;
                                    dispatch_once(&onceToken, ^{
                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                                        int32_t search = 10100100;
                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                        SInt32 search1 = 8401;
                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                        
                                        vector<void*>results = engine.getAllResults();
                                        int32_t  modify = 1101001154;
                                        SInt32 modifyAllResults = 1101001154;
                                        for(int i = 0;i < results.size();i++){
                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                            
                                            
                                        }
                                    });
                                    
                                }
                            }
                                if(akm7) {
                                    if(skinsung){
                                        static dispatch_once_t onceToken;
                                        dispatch_once(&onceToken, ^{
                                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                                            int32_t search = 10100100;
                                            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                            SInt32 search1 = 8401;
                                            engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                            
                                            vector<void*>results = engine.getAllResults();
                                            int32_t  modify = 1101001174;
                                            SInt32 modifyAllResults = 1101001174;
                                            for(int i = 0;i < results.size();i++){
                                                if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                
                                                
                                            }
                                        });
                                        
                                    }
                                }
                                    if(akm8) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                int32_t search = 10100100;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8401;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                int32_t  modify = 1101001213;
                                                SInt32 modifyAllResults = 1101001213;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl1) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //Water Blaster - SCAR-L
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003057;
                                            
                                                SInt32 modifyAllResults = 1101003057;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                    
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl2) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //Enchanted Pumpkin - SCAR-L
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003070;
                                                //AK BĂNG
                                                SInt32 modifyAllResults = 1101003070;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                    
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl3) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //Operation Tomorrow - SCAR-L
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003080;
                                                //AK BĂNG
                                                SInt32 modifyAllResults = 1101003080;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                   
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl4) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //Drop the Bass
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003099;
                                         
                                                SInt32 modifyAllResults = 1101003099;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                                    }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl5) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003119;
                                                //AK BĂNG
                                                SInt32 modifyAllResults = 1101003119;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(scarl6) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x00000000,0x200000000};
                                                SInt32 search = 10100300;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8403;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003146;
                                          
                                                SInt32 modifyAllResults = 1101003146;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                    
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7621) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101003057;
                                                //Unicorn - M762
                                                SInt32 modifyAllResults = 1101003057;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7622) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008116;
                                                //Messi Football Icon M762
                                                SInt32 modifyAllResults = 1101008116;
                                                
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7623) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //GACKT MOONSAGA-M762
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008070;
                                                //GACKT MOONSAGA-M762
                                                SInt32 modifyAllResults = 1101008070;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7624) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008036;
                                                //GACKT MOONSAGA-M762
                                                SInt32 modifyAllResults = 1101008036;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7625) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                //Concerto of Love - M762
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008051;
                                                //GACKT MOONSAGA-M762
                                                SInt32 modifyAllResults = 1101008051;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7626) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008104;
                                                //GACKT MOONSAGA-M762
                                                SInt32 modifyAllResults = 1101008104;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7627) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                        vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008081;
                                                //Rebellion - M762
                                                SInt32 modifyAllResults = 1101008081;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(m7628) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                SInt32 search = 10100800;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8408;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101008126;
                                                //Stray Rebellion - M762
                                                SInt32 modifyAllResults = 1101008126;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                }
                                                
                                            });
                                            
                                        }
                                    }
                                    if(gloza1) {
                                        if(skinsung){
                                            static dispatch_once_t onceToken;
                                            dispatch_once(&onceToken, ^{
                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                AddrRange range = (AddrRange){0x100000000,0x200000000};
                                                SInt32 search = 10100500;
                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                SInt32 search1 = 8405;
                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                
                                                vector<void*>results = engine.getAllResults();
                                                SInt32 modify = 1101005019;
                                                //AK BĂNG
                                                SInt32 modifyAllResults = 1101005019;
                                                for(int i = 0;i < results.size();i++){
                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                    
                                                    
                                                }
                                            });
                                        }
                                    }
                                        
                                            if(gloza2) {
                                                if(skinsung){
                                                    static dispatch_once_t onceToken;
                                                    dispatch_once(&onceToken, ^{
                                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                        int32_t search = 10100500;
                                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                        SInt32 search1 = 8405;
                                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                        
                                                        vector<void*>results = engine.getAllResults();
                                                        int32_t  modify = 1101005052;
                                                        SInt32 modifyAllResults = 1101005052;
                                                        for(int i = 0;i < results.size();i++){
                                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                            
                                                            
                                                        }
                                                        
                                                    });
                                                }
                                            }
                                            
                                                if(gloza3) {
                                                    if(skinsung){
                                                        static dispatch_once_t onceToken;
                                                        dispatch_once(&onceToken, ^{
                                                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                            int32_t search = 10100500;
                                                            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                            SInt32 search1 = 8405;
                                                            engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                            
                                                            vector<void*>results = engine.getAllResults();
                                                            int32_t  modify = 1101005025;
                                                            SInt32 modifyAllResults = 1101005025;
                                                            for(int i = 0;i < results.size();i++){
                                                                if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                            }
                                                            
                                                        });
                                                    }
                                                }
                                                
                                                    if(gloza4) {
                                                        if(skinsung){
                                                            static dispatch_once_t onceToken;
                                                            dispatch_once(&onceToken, ^{
                                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                int32_t search = 10100500;
                                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                SInt32 search1 = 8405;
                                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                
                                                                vector<void*>results = engine.getAllResults();
                                                                int32_t  modify = 1101005038;
                                                                SInt32 modifyAllResults = 1101005038;
                                                                for(int i = 0;i < results.size();i++){
                                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                
                                                            }
                                                            
                                                        });
                                                        
                                                    }
                                                }
                                                
                                                    if(m161) {
                                                        if(skinsung){
                                                            static dispatch_once_t onceToken;
                                                            dispatch_once(&onceToken, ^{
                                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                int32_t search = 10100200;
                                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                SInt32 search1 = 8402;
                                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                
                                                                vector<void*>results = engine.getAllResults();
                                                                int32_t  modify = 1101002029;
                                                                SInt32 modifyAllResults = 1101002029;
                                                                for(int i = 0;i < results.size();i++){
                                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                    
                                                                }
                                                            });
                                                            
                                                        }
                                                    }
                                                   
                                                        if(m162) {
                                                            if(skinsung){
                                                                static dispatch_once_t onceToken;
                                                                dispatch_once(&onceToken, ^{
                                                                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                    int32_t search = 10100200;
                                                                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                    SInt32 search1 = 8402;
                                                                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                    
                                                                    vector<void*>results = engine.getAllResults();
                                                                    int32_t  modify = 1101002056;
                                                                    SInt32 modifyAllResults = 1101002056;
                                                                    for(int i = 0;i < results.size();i++){
                                                                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                        
                                                                        
                                                                    }
                                                                });
                                                                
                                                            }
                                                        }
                                                    
                                                        if(m163) {
                                                            if(skinsung){
                                                                static dispatch_once_t onceToken;
                                                                dispatch_once(&onceToken, ^{
                                                                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                    int32_t search = 10100200;
                                                                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                    SInt32 search1 = 8402;
                                                                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                    
                                                                    vector<void*>results = engine.getAllResults();
                                                                    int32_t  modify = 1101002068;
                                                                    SInt32 modifyAllResults = 1101002068;
                                                                    for(int i = 0;i < results.size();i++){
                                                                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                        
                                                                        
                                                                    }
                                                                });
                                                                
                                                            }
                                                        }
                                                            if(m164) {
                                                                if(skinsung){
                                                                    static dispatch_once_t onceToken;
                                                                    dispatch_once(&onceToken, ^{
                                                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                        int32_t search = 10100200;
                                                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                        SInt32 search1 = 8402;
                                                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                        
                                                                        vector<void*>results = engine.getAllResults();
                                                                        int32_t  modify = 1101002081;
                                                                        SInt32 modifyAllResults = 1101002081;
                                                                        for(int i = 0;i < results.size();i++){
                                                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                            
                                                                            
                                                                        }
                                                                    });
                                                                    
                                                                }
                                                            }
                                                                if(dp281) {
                                                                    if(skinsung){
                                                                        static dispatch_once_t onceToken;
                                                                        dispatch_once(&onceToken, ^{
                                                                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                            int32_t search = 10500200;
                                                                            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                            SInt32 search1 = 8452;
                                                                            engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                            
                                                                            vector<void*>results = engine.getAllResults();
                                                                            int32_t  modify = 1105002018;
                                                                            SInt32 modifyAllResults = 1105002018;
                                                                            for(int i = 0;i < results.size();i++){
                                                                                if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                            }
                                                                        });
                                                                        
                                                                    }
                                                                }
                                                               
                                                                    if(dp282) {
                                                                        if(skinsung){
                                                                            static dispatch_once_t onceToken;
                                                                            dispatch_once(&onceToken, ^{
                                                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                int32_t search = 10500200;
                                                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                SInt32 search1 = 88452;
                                                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                
                                                                                vector<void*>results = engine.getAllResults();
                                                                                int32_t  modify = 1105002035;
                                                                                SInt32 modifyAllResults = 1105002035;
                                                                                for(int i = 0;i < results.size();i++){
                                                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                    
                                                                                    
                                                                                }
                                                                            });
                                                                            
                                                                        }
                                                                    }
                                                                
                                                                    if(aug1) {
                                                                        if(skinsung){
                                                                            static dispatch_once_t onceToken;
                                                                            dispatch_once(&onceToken, ^{
                                                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                int32_t search = 10100600;
                                                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                SInt32 search1 = 8406;
                                                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                
                                                                                vector<void*>results = engine.getAllResults();
                                                                                int32_t  modify = 1101006033;
                                                                                SInt32 modifyAllResults = 1101006033;
                                                                                for(int i = 0;i < results.size();i++){
                                                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                    
                                                                                    
                                                                                }
                                                                            });
                                                                            
                                                                        }
                                                                    }
                                                                        if(m164) {
                                                                            if(skinsung){
                                                                                static dispatch_once_t onceToken;
                                                                                dispatch_once(&onceToken, ^{
                                                                                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                    int32_t search = 1011000;
                                                                                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                    SInt32 search1 = 8412;
                                                                                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                    
                                                                                    vector<void*>results = engine.getAllResults();
                                                                                    int32_t  modify = 1101006060;
                                                                                    SInt32 modifyAllResults = 1101006060;
                                                                                    for(int i = 0;i < results.size();i++){
                                                                                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                        
                                                                                        
                                                                                    }
                                                                                });
                                                                                
                                                                            }
                                                                        }
        if(ace1) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 10110200;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8412;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1101102007;
                    SInt32 modifyAllResults = 1101102007;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                    }
                });
            }
        }
        if(ace2) {
                                                                                                if(skinsung){
                                                                                                    static dispatch_once_t onceToken;
                                                                                                    dispatch_once(&onceToken, ^{
                                                                                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                                                                                                        AddrRange range = (AddrRange){0x100000000,0x200000000};
                                                                                                        SInt32 search = 10110200;
                                                                                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                                        SInt32 search1 = 8412;
                                                                                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                                        
                                                                                                        vector<void*>results = engine.getAllResults();
                                                                                                        SInt32 modify = 1101102017;
                                                                                                        //AK BĂNG
                                                                                                        SInt32 modifyAllResults = 1101102017;
                                                                                                        for(int i = 0;i < results.size();i++){
                                                                                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                                            
                                                                                                            
                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                            }
                                                                                                
                                                                                                    if(mini1) {
                                                                                                        if(skinsung){
                                                                                                            static dispatch_once_t onceToken;
                                                                                                            dispatch_once(&onceToken, ^{
                                                                                                                JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                                                AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                                                int32_t search = 10100700;
                                                                                                                engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                                                SInt32 search1 = 8407;
                                                                                                                engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                                                
                                                                                                                vector<void*>results = engine.getAllResults();
                                                                                                                int32_t  modify = 1101007025;
                                                                                                                SInt32 modifyAllResults = 1101007025;
                                                                                                                for(int i = 0;i < results.size();i++){
                                                                                                                    if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                                                    engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                                                    
                                                                                                                    
                                                                                                                }
                                                                                                                
                                                                                                            });
                                                                                                        }
                                                                                                    }
                                                                                                    
                                                                                                        if(qbz1) {
                                                                                                            if(skinsung){
                                                                                                                static dispatch_once_t onceToken;
                                                                                                                dispatch_once(&onceToken, ^{
                                                                                                                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                                                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                                                    int32_t search = 10100700;
                                                                                                                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                                                    SInt32 search1 = 8407;
                                                                                                                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                                                    
                                                                                                                    vector<void*>results = engine.getAllResults();
                                                                                                                    int32_t  modify = 1101007025;
                                                                                                                    SInt32 modifyAllResults = 1101007025;
                                                                                                                    for(int i = 0;i < results.size();i++){
                                                                                                                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                                                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                                                        
                                                                                                                        
                                                                                                                    }
                                                                                                                    
                                                                                                                });
                                                                                                                
                                                                                                            }
                                                                                                        }
                                                                                                        
                                                                                                            if(qbz2) {
                                                                                                                if(skinsung){
                                                                                                                    static dispatch_once_t onceToken;
                                                                                                                    dispatch_once(&onceToken, ^{
                                                                                                                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                                                                                                                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                                                                                                                        int32_t search = 10100700;
                                                                                                                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                                                                                                                        SInt32 search1 = 8407;
                                                                                                                        engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                                                                                                                        
                                                                                                                        vector<void*>results = engine.getAllResults();
                                                                                                                        int32_t  modify = 1101007036;
                                                                                                                        SInt32 modifyAllResults = 1101007036;
                                                                                                                        for(int i = 0;i < results.size();i++){
                                                                                                                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                                                                                                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                                                                                                            
                                                                                                                        }
                                                                                                                    });
                                                                                                                    
                                                                                                                }
                                                                                                            }
                                                                                                           
        if(qbz3) {
            if(skinsung){
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    int32_t search = 10100700;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    SInt32 search1 = 8407;
                    engine.JRNearBySearch(0x100,&search1, JR_Search_Type_SInt);
                    
                    vector<void*>results = engine.getAllResults();
                    int32_t  modify = 1101007046;
                    SInt32 modifyAllResults = 1101007046;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                  
                        
                  
            
                                                }
                                            });
                                        }
                                    }
                                }
                            }

    void *rsskin(void *) {
        usleep(1666);
        while (true) {
            
            if(skinm41) {
                if(m4rs){
                    
                    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x00000000,0x200000000};
                    SInt32 search = 1101004046;
                    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                    vector<void*>results = engine.getAllResults();
                    SInt32 modify = 10100400;
                    SInt32 modifyAllResults = 10100400;
                    for(int i = 0;i < results.size();i++){
                        if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                        engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                        
                    }
                }
                    
                
                if(m4rs){
                  
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040463;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                
                }
                if(m4rs){
                 
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040461;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
               
                    
                }
                if(m4rs){
              
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040462;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                 
                    
                }
                
            }
            
            
            
            if(skinm42) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004062;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040623;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040621;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040622;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
              
            }
            
            
            if(skinm43) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004086;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040863;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040861;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040862;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
            }
                
                if(skinm44) {
                    if(m4rs){
                        static dispatch_once_t onceToken;
                        dispatch_once(&onceToken, ^{
                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                            AddrRange range = (AddrRange){0x00000000,0x200000000};
                            SInt32 search = 1101004078;
                            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                   
                            
                            vector<void*>results = engine.getAllResults();
                            SInt32 modify = 10100400;
                            SInt32 modifyAllResults = 10100400;
                            for(int i = 0;i < results.size();i++){
                                if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                                
                            }
                        });
                        
                    }
                    
                    if(m4rs){
                        static dispatch_once_t onceToken;
                        dispatch_once(&onceToken, ^{
                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                            int32_t search = 1010040783;
                            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                            vector<void*>results = engine.getAllResults();
                            int32_t  modify = 20500500;
                            for(int i = 0;i < results.size();i++){
                                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                
                                
                            }
                            
                        });
                    }
                    if(m4rs){
                        static dispatch_once_t onceToken;
                        dispatch_once(&onceToken, ^{
                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                            int32_t search = 1010040781;
                            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                            vector<void*>results = engine.getAllResults();
                            int32_t  modify = 29100400;
                            for(int i = 0;i < results.size();i++){
                                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                
                                
                            }
                            
                        });
                        
                    }
                    if(m4rs){
                        static dispatch_once_t onceToken;
                        dispatch_once(&onceToken, ^{
                            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                            AddrRange range = (AddrRange){0x100000000,0x160000000};
                            int32_t search = 1010040782;
                            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                            vector<void*>results = engine.getAllResults();
                            int32_t  modify = 20300800;
                            for(int i = 0;i < results.size();i++){
                                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                                
                                
                            }
                            
                        });
                        
                    }

                
            }
            
            if(skinm45) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004098;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
               
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040983;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040981;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010040982;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }

            
        }
            if(skinm46) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004163;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
               
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041633;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041631;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041632;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }

            
        }
            if(skinm47) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004201;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
               
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010042013;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010042011;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010042012;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }

            
        }
            if(skinm48) {
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                        AddrRange range = (AddrRange){0x00000000,0x200000000};
                        SInt32 search = 1101004138;
                        engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
               
                        
                        vector<void*>results = engine.getAllResults();
                        SInt32 modify = 10100400;
                        SInt32 modifyAllResults = 10100400;
                        for(int i = 0;i < results.size();i++){
                            if(i == 2&&4&&6)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modifyAllResults,JR_Search_Type_SInt);
                            
                        }
                    });
                    
                }
                
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041383;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20500500;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041381;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 29100400;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }
                if(m4rs){
                    static dispatch_once_t onceToken;
                    dispatch_once(&onceToken, ^{
                        JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); //m4bang
                        AddrRange range = (AddrRange){0x100000000,0x160000000};
                        int32_t search = 1010041382;
                        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
                        vector<void*>results = engine.getAllResults();
                        int32_t  modify = 20300800;
                        for(int i = 0;i < results.size();i++){
                            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
                            
                            
                        }
                        
                    });
                    
                }

            
        }
            
            
            
            
        }
        
    }
#define hook GaYSSS9aAL
+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
  
        RTL_language();

     //start load but not means language
       });
    FName::GNames = GetGNames();
    while (!FName::GNames) {
        FName::GNames = GetGNames();
        sleep(10);
    }
    
    UObject::GUObjectArray = (FUObjectArray *) (obbbbl());
    
    
    
}






/*
 bool isEqual(NSString* st1, NSString* st2) {
 return (st1 == st2);
 }*/
@end
