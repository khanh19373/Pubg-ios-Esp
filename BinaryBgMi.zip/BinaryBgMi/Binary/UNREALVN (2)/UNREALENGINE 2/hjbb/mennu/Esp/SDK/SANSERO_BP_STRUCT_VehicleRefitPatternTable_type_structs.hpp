#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:17 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_VehicleRefitPatternTable_type.BP_STRUCT_VehicleRefitPatternTable_type
// 0x0058
struct FBP_STRUCT_VehicleRefitPatternTable_type
{
	int                                                IconScale2_0_46572E4071F9B3293BE305FF087656B2;            // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     IconPath2_1_024EF7804CE8216627C3CAFF038879F2;             // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IconScale1_2_46562E0071F9B3283BE305F8087656B1;            // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     IconPath1_3_024DF7404CE8216527C3CAFC038879F1;             // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_4_3B4768C07AEB475737EB9B560A7BEF14;                    // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FString                                     IconOffset_5_59F5A18037D665B02424026A0AB3EDF4;            // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PatternBPPath_6_4B5944C06FBA413D7EB727A808597AD8;         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

