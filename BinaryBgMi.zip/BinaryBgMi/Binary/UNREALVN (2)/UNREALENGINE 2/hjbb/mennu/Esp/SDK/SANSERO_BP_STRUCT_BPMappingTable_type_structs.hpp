#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:20 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_BPMappingTable_type.BP_STRUCT_BPMappingTable_type
// 0x0014
struct FBP_STRUCT_BPMappingTable_type
{
	struct FString                                     BPMapping_0_359D8E805EAA95B608F926810D8E6097;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_53343E0047BD3A720C3CF0DE04726144;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

