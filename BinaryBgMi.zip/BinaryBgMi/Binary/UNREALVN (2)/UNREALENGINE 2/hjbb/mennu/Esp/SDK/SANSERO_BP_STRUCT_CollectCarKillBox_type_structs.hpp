#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:21 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_CollectCarKillBox_type.BP_STRUCT_CollectCarKillBox_type
// 0x0020
struct FBP_STRUCT_CollectCarKillBox_type
{
	int                                                ID_0_7BFD6D002A9D688256CADB6A08E84E44;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ImagePath_1_1F4765C045721A135F59990A095E8F18;             // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                DiedBoxBattleID_5_641D8BC008D9DAD91AAFBA6B0DB8A624;       // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                DiedBoxLobbyID_6_7BD292C06841C35915E0295B060844D4;        // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

