#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:22 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_ReddotCategoryConfig_type.BP_STRUCT_ReddotCategoryConfig_type
// 0x005C
struct FBP_STRUCT_ReddotCategoryConfig_type
{
	int                                                ID_0_4C8BA6403419DB9F748D9B5808287634;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                InQueueLevel_1_44CE90005C383BE8671DC3D70DC96F0C;          // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                OutQueueLevel_2_0FC3B04025B5B1E50FA495CF03E9C00C;         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SubID_3_748F90C0419C7AFD433D84A507743454;                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SystemID_4_446DE7805572693A20E9AAA00882D684;              // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Weight_5_68CF3D001CE210B0618D61EC0733D584;                // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsInMessageCenter_6_447E094038DF26314190299A0D3033A2;     // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	int                                                Style1_29_258953806D4DAB764807E2630743EAF1;               // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Style2_33_258A53C06D4DAB774807E2620743EAF2;               // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Style3_28_258B54006D4DAB784807E2610743EAF3;               // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Style4_31_258C54406D4DAB794807E2600743EAF4;               // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                StyleInner_32_7F9C66401B6FAB4B31CAA92C0AE91722;           // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Category_13_54AA728026C4F47E0AE57AFA0083B0E9;             // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Style5OrInner_30_2A7EE3C0712F4F5D2DCBF8C60252FB32;        // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ValidHoursFromGen_18_636BCEC01742F9C13B4D499A0231D4BE;    // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ValidHoursFromSeen_19_350A2B007FDA5BE2238C7CF9031E0B9E;   // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ValidLevel_20_0ECD1D005B666450312BD31B0805FCBC;           // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FString                                     ValidUser_21_247846C05B6279095501CC4F007EBAC2;            // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                StyleOrientation1_34_1E1596804F29876A39832879059644E1;    // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

