#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:18 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// 0x0014
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString                                     TextValue_0_4D37165A410D67320AF278A1C1028E4F;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TextId_1_20B947934F165858A322E599888F816E;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

