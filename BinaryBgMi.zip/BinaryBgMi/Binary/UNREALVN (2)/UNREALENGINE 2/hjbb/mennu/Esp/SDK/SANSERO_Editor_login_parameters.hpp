#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:19 2024
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Parameters
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// Function Editor_login.Editor_login_C.SetFpsByIndex
struct AEditor_login_C_SetFpsByIndex_Params
{
	int                                                idx;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_10
struct AEditor_login_C_InpActEvt_Android_Back_K2Node_InputKeyEvent_10_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_E_K2Node_InputKeyEvent_9
struct AEditor_login_C_InpActEvt_E_K2Node_InputKeyEvent_9_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_8
struct AEditor_login_C_InpActEvt_BackSpace_K2Node_InputKeyEvent_8_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_B_K2Node_InputKeyEvent_7
struct AEditor_login_C_InpActEvt_B_K2Node_InputKeyEvent_7_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_G_K2Node_InputKeyEvent_6
struct AEditor_login_C_InpActEvt_G_K2Node_InputKeyEvent_6_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.ReceiveBeginPlay
struct AEditor_login_C_ReceiveBeginPlay_Params
{
};

// Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login
struct AEditor_login_C_ExecuteUbergraph_Editor_login_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

