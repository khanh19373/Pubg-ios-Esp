#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:16 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_TransSupportConfig_GLOBAL_type.BP_STRUCT_TransSupportConfig_GLOBAL_type
// 0x0040
struct FBP_STRUCT_TransSupportConfig_GLOBAL_type
{
	int                                                languageID_0_1D9BF4801A0CAF180454007A0E59BFB4;            // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     displayName_1_7B233E0045C681C6393652C80C537045;           // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     abbreviation_2_7270DDC045E369B7531E4D2001C2187E;          // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               isSupported_3_297FC8C037F3503F7D952DE609923274;           // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FString                                     languageCode_4_0C60B000517E13D413D2E28809C00BF5;          // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

